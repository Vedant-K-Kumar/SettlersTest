/* Harbor & Hearth V1.9 - Easy Mode AI.
   This is the V1.7 bot logic, kept deliberately simple, with its problems repaired:
   - Fair play: it no longer reads other players' hidden hands. Monopoly choices and trade requests
     use the same public card-tracking estimate the Normal bots use (HearthAI.Track).
   - Piece limits: V1.7 could loop forever trying to build a sixth settlement, fifth city or 16th road.
   - Turn guard: a turn ends after a bounded number of actions, so the bot can never stall.
   - Progress cards: Monopoly and Year of Plenty now use the resource the bot actually chose.
   - Statistics: harbor trades are recorded for the end-of-game screen.
   Generated from the V1.7 source; prefix E_ keeps it separate from the Normal AI in ai.js. */
function E_seen(x,q){if(q===x)return x.r;trackSync();const est=HearthAI.Track.view(game.ai,x.id);return {...empty(),...(est[q.id]||{})}}
function E_probability(number){return ({2:1,3:2,4:3,5:4,6:5,8:5,9:4,10:3,11:2,12:1})[number]||0}
function E_nodeValue(nodeId,bot){
  let node=n(nodeId),types=new Set(),value=0;
  node.tiles.forEach(tileId=>{let tile=game.board.tiles.find(q=>q.id===tileId);if(tile.terrain!=='desert'){let pip=tile.id===game.board.robber?0:E_probability(tile.number);value+=pip*(bot.r[tile.terrain]===0?1.35:1);types.add(tile.terrain)}});
  value+=types.size*2.5;
  value+=node.tiles.some(tileId=>game.board.ports.some(port=>{let z=e(port.edge);return z.a===nodeId||z.b===nodeId}))?1.5:0;
  value+=E_denialValue(nodeId,bot);
  return value;
}
function E_leaderScore(except){return Math.max(0,...game.players.filter(q=>q!==except).map(score))}
function E_denialValue(nodeId,bot){
  let bonus=0;
  game.players.forEach(q=>{
    if(q===bot)return;
    const gap=score(q)-score(bot);
    if(gap<1&&score(q)<7)return;
    if(adj(nodeId).some(z=>q.roads.includes(z.id)))bonus+=2.2+Math.max(0,gap)*1.7+(score(q)>=8?3.5:0);
  });
  return bonus;
}
function E_monopolyValue(x,k){return game.players.filter(q=>q!==x).reduce((n,q)=>{const s=score(q);return n+E_seen(x,q)[k]*(1+Math.max(0,s-4)*.15+(s>=8?.5:0))},0)*(E_botNeed(x)===k?1.25:1)}
function E_botBuildGoal(x){
  let settlement={wood:1,brick:1,wool:1,grain:1},cityCost={grain:2,ore:3};
  let cityNode=x.settlements.length?E_bestOf(x.settlements,id=>E_nodeValue(id,x)):null;
  let cityScore=cityNode?E_nodeValue(cityNode,x)+3:0;
  let setScore=E_bestOf(game.board.nodes.filter(q=>canSet(x,q.id)),q=>E_nodeValue(q.id,x));
  if(setScore)setScore=E_nodeValue(setScore.id,x)+4.5;
  if(cityNode&&cityScore>=setScore)return {kind:'city',cost:cityCost};
  return {kind:'settlement',cost:settlement};
}
function E_botNeed(x){
  let goal=E_botBuildGoal(x),missing=R.filter(k=>x.r[k]<(goal.cost[k]||0));
  return missing.sort((a,b)=>((goal.cost[a]||0)-x.r[a])-((goal.cost[b]||0)-x.r[b]) || E_resourceWorth(x,b)-E_resourceWorth(x,a))[0]||R.find(k=>x.r[k]===0&&game.bank[k]);
}
function E_resourceWorth(bot,resource){let need=E_botNeedShallow(bot),short=Math.max(0,(need.cost[resource]||0)-bot.r[resource]);return 3+short*2+(bot.r[resource]===0?1:0)-(bot.r[resource]>=4?1.5:0)}
function E_botNeedShallow(x){return E_botBuildGoalShallow(x)}
function E_botBuildGoalShallow(x){let settlement={wood:1,brick:1,wool:1,grain:1},city={grain:2,ore:3};return x.settlements.length&&x.cities.length<x.settlements.length?{cost:city}:{cost:settlement}}
function E_bestOf(items,scoreFn){return items.reduce((best,item)=>!best||scoreFn(item)>scoreFn(best)?item:best,null)}
function E_bestSettlement(x){return E_bestOf(game.board.nodes.filter(q=>canSet(x,q.id)),q=>E_nodeValue(q.id,x)+game.board.ports.filter(port=>{let z=e(port.edge);return z.a===q.id||z.b===q.id}).length*2+(score(x)>=7?2:0))}
function E_bestCity(x){return E_bestOf(x.settlements.filter(id=>paid(x,{grain:2,ore:3})),id=>E_nodeValue(id,x)+3)}
function E_bestRoadPlan(x){
  let starts=new Set([...x.settlements,...x.cities]);
  x.roads.forEach(id=>{let z=e(id);if(z){starts.add(z.a);starts.add(z.b)}});
  let queue=[...starts].filter(id=>{let o=owner(id);return !o||o===x}).map(id=>({node:id,first:null,distance:0}));
  let seen=new Map(queue.map(q=>[q.node,0])),best=null;
  while(queue.length){let cur=queue.shift();if(cur.distance>=8)continue;
    for(let edge of adj(cur.node)){
      if(x.roads.includes(edge.id)||game.players.some(q=>q!==x&&q.roads.includes(edge.id)))continue;
      let next=edge.a===cur.node?edge.b:edge.a,occupant=owner(next);if(occupant&&occupant!==x)continue;
      let first=cur.first||edge.id,dist=cur.distance+1;
      if(cur.distance===0&&!canRoad(x,edge.id))continue;
      if(freeNode(next)){
        let old=x.roads.length?roadLen(x):0;x.roads.push(first);let projected=roadLen(x);x.roads.pop();
        let roadGain=projected-old;let value=E_nodeValue(next,x)+4.5-dist*1.35+roadGain*1.4+(projected>=5&&game.longest!==x.id?3:0);
        if(!best||value>best.value)best={edge:first,target:next,distance:dist,value,roadGain};
      }
      if(!seen.has(next)||seen.get(next)>dist){seen.set(next,dist);queue.push({node:next,first,distance:dist})}
    }
  }
  return best&&canRoad(x,best.edge)?best:null;
}
function E_bestRobberTile(x){
  return E_bestOf(game.board.tiles.filter(t=>t.id!==game.board.robber),t=>{
    let bestEnemy=null,selfPain=0;
    game.players.forEach(q=>{
      let buildings=0;
      t.nodes.forEach(id=>{buildings+=q.settlements.includes(id)?1:q.cities.includes(id)?2:0});
      if(!buildings)return;
      const prod=E_probability(t.number)*buildings;
      if(q===x)selfPain+=prod*4+buildings;
      else{
        const s=score(q);
        const power=s*s*1.25+s*2+prod*1.4+Math.min(sum(q.r),8)*.25+(s>=8?8:0);
        if(!bestEnemy||power>bestEnemy.power)bestEnemy={power};
      }
    });
    return bestEnemy?bestEnemy.power-selfPain*.4:-500-selfPain;
  });
}
function E_shouldPlayKnight(x){
  if(!x.dev.includes('knight')||x.devPlayedTurn===game.turnCount)return false;
  const lead=E_leaderScore(x),tile=E_bestRobberTile(x);
  const hitsEnemy=tile&&tile.nodes.some(id=>{const q=owner(id);return q&&q!==x});
  if(!hitsEnemy)return false;
  if(x.knights>=2)return true;
  if(lead>=score(x)+2||lead>=8)return true;
  const blocked=game.board.tiles.find(t=>t.id===game.board.robber);
  return !!(blocked&&blocked.nodes.some(id=>x.settlements.includes(id)||x.cities.includes(id))&&lead>=score(x));
}
function E_wouldClaimLongest(x,plan){
  if(!plan)return false;
  x.roads.push(plan.edge);
  const mine=roadLen(x);
  x.roads.pop();
  const bestOther=Math.max(0,...game.players.filter(q=>q!==x).map(roadLen));
  const holder=game.longest&&game.longest!==x.id?game.players.find(q=>q.id===game.longest):null;
  if(holder&&mine<=roadLen(holder))return false;
  return mine>=5&&mine>bestOther;
}
function E_winningBuild(x){
  const options=[];
  const cityNode=E_bestCity(x);
  if(cityNode&&paid(x,{grain:2,ore:3})&&score(x)+1>=10)options.push({v:10,go(){city(cityNode)}});
  const spot=E_bestSettlement(x);
  if(spot&&paid(x,{wood:1,brick:1,wool:1,grain:1})&&score(x)+1>=10)options.push({v:9,go(){placeSet(spot.id)}});
  const plan=E_bestRoadPlan(x);
  if(plan&&(game.freeRoads||paid(x,{wood:1,brick:1}))&&game.longest!==x.id&&E_wouldClaimLongest(x,plan)&&score(x)+2>=10)options.push({v:12,go(){placeRoad(plan.edge)}});
  if(x.dev.includes('knight')&&x.devPlayedTurn!==game.turnCount&&x.knights===2&&game.largest!==x.id&&score(x)+2>=10)options.push({v:12,go(){play('knight')}});
  if(!options.length)return false;
  options.sort((a,b)=>b.v-a.v)[0].go();
  return true;
}
function E_botBankTrade(x){
  let wanted=E_botNeed(x);if(!wanted||!game.bank[wanted])return false;
  let candidates=R.filter(k=>k!==wanted).map(k=>({k,rate:x.ports.includes(k)?2:x.ports.includes('any')?3:4})).filter(q=>x.r[q.k]>=q.rate+1&&game.bank[wanted]>0).sort((a,b)=>(x.r[b.k]-b.rate)-(x.r[a.k]-a.rate));
  if(!candidates.length)return false;let {k,rate}=candidates[0];x.r[k]-=rate;game.bank[k]+=rate;x.r[wanted]++;game.bank[wanted]--;Stats.res(game,x.id,'bankOut',k,rate);Stats.res(game,x.id,'bankIn',wanted,1);Stats.count(game,x.id,'bankTrades');note(`${x.name} trades ${chip(k,rate)} for ${chip(wanted,1)} at the harbor.`);toast('trade','Harbor trade',[{who:x.name,lose:{[k]:rate},gain:{[wanted]:1}}]);return true;
}
function E_continueBot(){if(game&&game.winner==null&&p().bot&&!game.offer&&!botTimer)botTimer=setTimeout(()=>{botTimer=null;E_maybeBot()},BOT_DELAY)}
function E_maybeBot(){
  if(!game||game.winner!=null||!p().bot||game.offer||botTimer)return;
  botTimer=setTimeout(()=>{
    botTimer=null;let x=p();if(!x||!x.bot||game.winner!=null||game.offer)return;
    if(game.phase==='setup'){
      let nodes=game.board.nodes.filter(q=>canSet(x,q.id));
      if(!game.setupNode&&nodes.length){let best=E_bestOf(nodes,q=>E_nodeValue(q.id,x));placeSet(best.id)}
      else{let edges=game.board.edges.filter(q=>canRoad(x,q.id)),best=E_bestOf(edges,q=>E_nodeValue(q.a===game.setupNode?q.b:q.a,x));if(best)placeRoad(best.id)}
      return;
    }
    if(game.phase==='discard'){advanceDiscard();if(game.phase==='discard'){render();return}}
    if(game.phase==='roll'){roll();return;}
    if(game.phase==='robber'){
      let tile=E_bestRobberTile(x);if(tile)robber(tile.id);return;
    }
    if(game.phase!=='build')return;
    if(E_winningBuild(x)){E_continueBot();return;}

    // A bot takes multiple useful actions in one turn, rather than ending after its first purchase.
    if(E_shouldPlayKnight(x)){play('knight');E_continueBot();return;}
    if(x.dev.includes('monopoly')&&x.devPlayedTurn!==game.turnCount){
      let best=E_bestOf(R,k=>E_monopolyValue(x,k));
      if(best&&E_monopolyValue(x,best)>=3){play('monopoly',best);E_continueBot();return;}
    }
    if(x.dev.includes('plenty')&&x.devPlayedTurn!==game.turnCount){let goal=E_botBuildGoal(x),missing=R.filter(k=>x.r[k]<(goal.cost[k]||0)&&game.bank[k]);if(missing.length>=1){play('plenty',[missing[0],missing[1]||missing[0]]);E_continueBot();return;}}
    if(game.freeRoads>0){let plan=E_bestRoadPlan(x);if(plan){placeRoad(plan.edge);E_continueBot();return;}game.freeRoads=0;}
    let cityNode=E_bestCity(x),settlementNode=E_bestSettlement(x);
    let pressure=Math.max(0,E_leaderScore(x)-score(x));
    let cityScore=cityNode?E_nodeValue(cityNode,x)+3+pressure*1.4+(E_leaderScore(x)>=8?2:0):-Infinity;
    let settlementScore=settlementNode?E_nodeValue(settlementNode.id,x)+4.5+game.board.ports.filter(port=>{let z=e(port.edge);return z.a===settlementNode.id||z.b===settlementNode.id}).length*2:-Infinity;
    if(cityNode&&paid(x,{grain:2,ore:3})&&cityScore>=settlementScore-1){city(cityNode);E_continueBot();return;}
    if(settlementNode&&paid(x,{wood:1,brick:1,wool:1,grain:1})){placeSet(settlementNode.id);E_continueBot();return;}
    if(cityNode&&paid(x,{grain:2,ore:3})){city(cityNode);E_continueBot();return;}

    let roadPlan=E_bestRoadPlan(x);
    if(x.dev.includes('road')&&x.devPlayedTurn!==game.turnCount&&roadPlan){play('road');E_continueBot();return;}
    let currentRoad=roadLen(x),otherRoad=Math.max(0,...game.players.filter(q=>q!==x).map(roadLen));
    let roadRace=roadPlan&&roadPlan.roadGain>0&&currentRoad>=4&&(game.longest===x.id||otherRoad>=currentRoad-1);
    if(roadPlan&&paid(x,{wood:1,brick:1})&&((roadPlan.distance<=3&&roadPlan.value>9)||roadRace)){placeRoad(roadPlan.edge);E_continueBot();return;}

    let development=paid(x,{wool:1,grain:1,ore:1})&&game.deck.length>0;
    if(development&&(pressure>=2||score(x)>=4||!roadPlan||roadPlan.distance>3)){buy();E_continueBot();return;}
    if(E_botBankTrade(x)){E_continueBot();return;}

    let wanted=E_botNeed(x),extra=R.filter(k=>k!==wanted&&x.r[k]>=3).sort((a,b)=>x.r[b]-x.r[a])[0];
    if(extra&&wanted&&x.tradeDeclinedTurn!==game.turnCount&&x.tradeRequestedTurn!==game.turnCount&&game.players.some(q=>!q.bot&&score(q)<8&&E_seen(x,q)[wanted]>=0.75)){
      game.offer={from:x.id,give:{...empty(),[extra]:Math.min(2,x.r[extra]-1)},want:{...empty(),[wanted]:1}};
      x.tradeRequestedTurn=game.turnCount;note(`${x.name} requests ${goodsHtml(game.offer.want)} for ${goodsHtml(game.offer.give)}.`);render();return;
    }
    next();
  },BOT_DELAY);
}
// piece-limit guards (V1.7 never checked them)
const E__bestSettlement=E_bestSettlement;E_bestSettlement=function(x){return x.settlements.length>=5?null:E__bestSettlement(x)};
const E__bestCity=E_bestCity;E_bestCity=function(x){return x.cities.length>=4?null:E__bestCity(x)};
const E__bestRoadPlan=E_bestRoadPlan;E_bestRoadPlan=function(x){return x.roads.length>=15?null:E__bestRoadPlan(x)};
// bounded turns: count real actions (each continue) and end the turn after 40 of them
const E__continueBot=E_continueBot;E_continueBot=function(){const x=game&&p();if(x&&x.bot){if(x.__eTurn!==game.turnCount){x.__eTurn=game.turnCount;x.__eSteps=0}if(++x.__eSteps>40&&game.phase==='build'){game.freeRoads=0;x.__eSteps=0;return next()}}return E__continueBot()};
