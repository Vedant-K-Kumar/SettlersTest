/* Harbor & Hearth V1.9 - archetype registry.
   Every bot archetype is one entry here: display text (label, blurb, tooltip details, emblem)
   plus the strategy weights the AI reads (w = resource weights, cat = build category bias,
   army / lr / port / trade / aggro / diversity = strategic tendencies).
   To add an archetype in V2.0: call HearthArchetypes.register({...}) or add an entry below.
   Nothing else in the project lists archetypes by name. */
(function (root) {
  'use strict';
  const STYLES = {
    magnate: {
      id: 'magnate', label: 'Magnate', blurb: 'Cities and an ore-grain engine', emblem: '♜',
      details: 'Opens on ore and grain, upgrades to cities early, and turns a strong production engine into steady points. Expands only as far as it needs city spots.',
      w: { wood: 0.8, brick: 0.75, wool: 0.75, grain: 1.35, ore: 1.5 },
      cat: { city: 1.5, settlement: 0.95, dev: 0.95, road: 0.7 },
      army: 0.9, lr: 0.6, port: 1, trade: 1, aggro: 0.7, diversity: 0.9
    },
    warlord: {
      id: 'warlord', label: 'Warlord', blurb: 'Knights, the robber and Largest Army', emblem: '⚔',
      details: 'Buys progress cards for knights, plays them aggressively (often before rolling), and keeps the robber on the leader. Fights hard for Largest Army.',
      w: { wood: 0.7, brick: 0.7, wool: 1.3, grain: 1.2, ore: 1.35 },
      cat: { city: 1.05, settlement: 0.85, dev: 1.6, road: 0.65 },
      army: 2.3, lr: 0.5, port: 1, trade: 1, aggro: 1.7, diversity: 0.9
    },
    scholar: {
      id: 'scholar', label: 'Scholar', blurb: 'Development cards and hidden points', emblem: '✒',
      details: 'Invests in progress cards for hidden victory points and well-timed Monopoly, Year of Plenty and Road Building plays. Its true score is often higher than it looks.',
      w: { wood: 0.75, brick: 0.75, wool: 1.25, grain: 1.2, ore: 1.3 },
      cat: { city: 1.1, settlement: 0.9, dev: 1.6, road: 0.65 },
      army: 1.25, lr: 0.5, port: 1, trade: 1, aggro: 0.9, diversity: 1
    },
    roadrunner: {
      id: 'roadrunner', label: 'Roadrunner', blurb: 'Longest Road and fast lines', emblem: '➶',
      details: 'Opens on wood and brick, races roads into contested land, and plans settlements around holding Longest Road. Turns to cities late to close out the game.',
      w: { wood: 1.45, brick: 1.45, wool: 0.85, grain: 0.95, ore: 0.8 },
      cat: { city: 1.0, settlement: 1.2, dev: 0.7, road: 1.5 },
      army: 0.6, lr: 2.1, port: 1.4, trade: 0.9, aggro: 0.9, diversity: 1
    },
    pioneer: {
      id: 'pioneer', label: 'Pioneer', blurb: 'Expansion and resource diversity', emblem: '⚑',
      details: 'Spreads settlements quickly to collect every resource, grabs key junctions before rivals, and blocks expansion paths.',
      w: { wood: 1.2, brick: 1.2, wool: 1.05, grain: 1.15, ore: 0.85 },
      cat: { city: 0.95, settlement: 1.4, dev: 0.8, road: 1.05 },
      army: 0.8, lr: 1.1, port: 1.1, trade: 1, aggro: 1, diversity: 1.6
    },
    merchant: {
      id: 'merchant', label: 'Merchant', blurb: 'Harbors and trade leverage', emblem: '⚓',
      details: 'Settles on 2:1 harbors that match its strongest production, converts surplus at good rates, and trades often with other players.',
      w: { wood: 1, brick: 1, wool: 1, grain: 1.05, ore: 1.05 },
      cat: { city: 1.05, settlement: 1.05, dev: 1, road: 0.8 },
      army: 0.9, lr: 0.8, port: 2.4, trade: 0.55, aggro: 0.9, diversity: 1
    }
  };
  const BALANCED = {
    id: 'balanced', label: 'Balanced', blurb: 'No fixed plan', emblem: '◆', details: '',
    w: { wood: 1, brick: 1, wool: 0.9, grain: 1.05, ore: 1.05 },
    cat: { city: 1, settlement: 1, dev: 1, road: 1 }, army: 1, lr: 1, port: 1, trade: 1, aggro: 1, diversity: 1
  };
  // Order used when dealing archetypes to bots. register() appends.
  const ORDER = ['magnate', 'warlord', 'roadrunner', 'pioneer', 'scholar', 'merchant'];
  function register(def) {
    if (!def || !def.id) throw new Error('An archetype needs an id.');
    const full = Object.assign({}, BALANCED, def, { w: Object.assign({}, BALANCED.w, def.w), cat: Object.assign({}, BALANCED.cat, def.cat) });
    STYLES[def.id] = full; if (!ORDER.includes(def.id)) ORDER.push(def.id);
    return full;
  }
  function get(id) { return STYLES[id] || null; }
  function order() { return ORDER.slice(); }
  root.HearthArchetypes = { STYLES, BALANCED, register, get, order };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.HearthArchetypes;
})(typeof globalThis !== 'undefined' ? globalThis : this);
