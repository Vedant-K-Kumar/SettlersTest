/* Harbor & Hearth V1.9 - match recording, saved games, match history and full replays.
   Recording: after every action the recorder snapshots the public+private table state as a flat
   object and stores only what changed (plus the Chronicle text). A replay re-applies these changes,
   so it reproduces the real match exactly and does not depend on the rules engine.
   Files: gzip-compressed JSON (.hhmatch). Format documented in SAVE_FORMAT.md. */
(function (root) {
  'use strict';
  const RES = ['wood', 'brick', 'wool', 'grain', 'ore'];
  const FORMAT = 'harbor-hearth-match';
  const FORMAT_VERSION = 1;
  const APP_VERSION = root.HEARTH_VERSION || '1.9';
  const INDEX_KEY = 'hh.history.v1';
  const hasDoc = typeof document !== 'undefined' && !!document.createElement;
  const esc = (s) => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;');

  /* ---------------- recorder ---------------- */
  function toText(html) {
    return String(html)
      .replace(/<span class="chip (\w+)">[\s\S]*?<b>(\d+)<\/b><\/span>/g, (m, k, n) => `${n} ${k[0].toUpperCase() + k.slice(1)}`)
      .replace(/<[^>]+>/g, '').replace(/&rarr;/g, '→').replace(/&minus;/g, '−').replace(/&amp;/g, '&').replace(/\s+/g, ' ').trim();
  }
  function flatten(g) {
    const o = { robber: g.board.robber, bank: RES.map((k) => g.bank[k]), deck: g.deck.length, lr: g.longest, la: g.largest, dice: g.dice || null, turn: g.turn, tc: g.turnCount, ph: g.phase, win: g.winner == null ? null : g.winner };
    g.players.forEach((q, i) => {
      o[`p${i}.r`] = RES.map((k) => q.r[k]); o[`p${i}.ro`] = q.roads.slice(); o[`p${i}.s`] = q.settlements.slice(); o[`p${i}.c`] = q.cities.slice();
      o[`p${i}.d`] = q.dev.concat(q.newDev).concat(q.secretVp || []).slice().sort(); o[`p${i}.k`] = q.knights; o[`p${i}.v`] = q.vp; o[`p${i}.h`] = (q.secretVp || []).length; o[`p${i}.pt`] = q.ports.slice();
    });
    return o;
  }
  function kindOf(texts) {
    const t = texts.join(' ');
    if (/wins the island/.test(t)) return 'win';
    if (/rolls \d+/.test(t)) return 'roll';
    if (/Longest Road|Largest Army/.test(t)) return 'award';
    if (/robs|guard/.test(t)) return 'robber';
    if (/discards/.test(t)) return 'discard';
    if (/trade|accepts/.test(t)) return 'trade';
    if (/progress card|knight|claims every|from the bank|road deeds/i.test(t)) return 'dev';
    if (/settlement|road|city/.test(t)) return 'build';
    if (/turn begins/.test(t)) return 'turn';
    return 'note';
  }
  const Recorder = {
    start(game) { game.rec = { t0: Date.now(), initial: flatten(game), last: null, events: [], pending: [], fx: null, queued: false }; game.rec.last = game.rec.initial; },
    note(game, html) { if (!game || !game.rec || game.replay) return; game.rec.pending.push(toText(html)); Recorder.schedule(game); },
    fx(game, grants, tiles) { if (!game || !game.rec) return; game.rec.fx = { tiles: tiles || [], g: grants.map((x) => [game.players.findIndex((q) => q.id === x.playerId), x.resource, x.amount, +x.x.toFixed(3), +x.y.toFixed(3)]) }; Recorder.schedule(game); },
    schedule(game) { const r = game.rec; if (r.queued) return; r.queued = true; Promise.resolve().then(() => { r.queued = false; Recorder.flush(game); }); },
    flush(game) {
      const r = game && game.rec; if (!r || game.replay) return;
      const cur = flatten(game); const d = {};
      Object.keys(cur).forEach((k) => { if (JSON.stringify(cur[k]) !== JSON.stringify(r.last[k])) d[k] = cur[k]; });
      if (!Object.keys(d).length && !r.pending.length && !r.fx) return;
      const ev = { t: Date.now() - r.t0, k: kindOf(r.pending), tx: r.pending, d };
      if (r.fx) ev.fx = r.fx;
      r.events.push(ev); r.last = cur; r.pending = []; r.fx = null;
    }
  };
  root.Recorder = Recorder;

  /* ---------------- save object ---------------- */
  function buildSave(game, summary) {
    Recorder.flush(game);
    const b = game.board;
    const chronicle = []; (game.rec ? game.rec.events : []).forEach((ev) => ev.tx.forEach((t) => chronicle.push(t)));
    const id = 'm' + (summary.startedAt || Date.now()).toString(36) + Math.random().toString(36).slice(2, 7);
    const players = game.players.map((q, i) => ({ seat: i, id: q.id, name: q.name, color: q.color, bot: !!q.bot, style: q.style || null, styleLabel: q.styleLabel || null }));
    return {
      format: FORMAT, formatVersion: FORMAT_VERSION, app: 'Harbor & Hearth', appVersion: APP_VERSION, id, savedAt: Date.now(),
      meta: { startedAt: summary.startedAt, endedAt: summary.endedAt, durationMs: summary.durationMs, turns: summary.turns, winner: { id: game.winner, name: (game.players.find((q) => q.id === game.winner) || {}).name }, players: players.map((q) => ({ name: q.name, color: q.color, bot: q.bot, style: q.style })), difficulty: game.difficulty || 'normal', mapId: b.mapId || 'standard', rulesId: game.rulesId || 'standard' },
      rules: game.rules || null,
      board: { mapId: b.mapId || 'standard', tiles: b.tiles.map((t) => ({ id: t.id, q: t.q, r: t.r, terrain: t.terrain, number: t.number, center: { x: t.center.x, y: t.center.y }, nodes: t.nodes.slice() })), nodes: b.nodes.map((z) => ({ id: z.id, x: z.x, y: z.y, tiles: z.tiles.slice() })), edges: b.edges.map((z) => ({ id: z.id, a: z.a, b: z.b, tiles: z.tiles.slice() })), ports: b.ports.map((q) => ({ edge: q.edge, type: q.type })) },
      players,
      replay: { initial: game.rec ? game.rec.initial : flatten(game), events: game.rec ? game.rec.events : [] },
      chronicle,
      summary
    };
  }

  /* ---------------- compression + encoding ---------------- */
  async function gzip(str) {
    if (typeof CompressionStream === 'undefined') return null;
    const stream = new Blob([str]).stream().pipeThrough(new CompressionStream('gzip'));
    return new Uint8Array(await new Response(stream).arrayBuffer());
  }
  async function gunzip(bytes) {
    const stream = new Blob([bytes]).stream().pipeThrough(new DecompressionStream('gzip'));
    return await new Response(stream).text();
  }
  function b64(bytes) { let s = ''; for (let i = 0; i < bytes.length; i += 0x8000) s += String.fromCharCode.apply(null, bytes.subarray(i, i + 0x8000)); return btoa(s); }
  function unb64(str) { const bin = atob(str); const out = new Uint8Array(bin.length); for (let i = 0; i < bin.length; i++) out[i] = bin.charCodeAt(i); return out; }
  async function encodeFile(save) { const json = JSON.stringify(save); const gz = await gzip(json); return gz ? new Blob([gz], { type: 'application/gzip' }) : new Blob([json], { type: 'application/json' }); }
  async function decodeBytes(bytes) {
    const text = bytes[0] === 0x1f && bytes[1] === 0x8b ? await gunzip(bytes) : new TextDecoder().decode(bytes);
    return validate(JSON.parse(text));
  }
  function validate(save) {
    if (!save || save.format !== FORMAT) throw new Error('This file is not a Harbor & Hearth match.');
    if ((save.formatVersion || 0) > FORMAT_VERSION) throw new Error(`This match was saved by a newer version (format ${save.formatVersion}). Please update the game to open it.`);
    return migrate(save);
  }
  // Future versions add upgrade steps here (formatVersion 1 -> 2 -> ...). Old files are never rewritten.
  function migrate(save) { return save; }
  function fileName(save) {
    const d = new Date(save.meta.endedAt || save.savedAt); const pad = (n) => String(n).padStart(2, '0');
    const who = String((save.meta.winner && save.meta.winner.name) || 'match').replace(/[^A-Za-z0-9]+/g, '-').slice(0, 24);
    return `HH-${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}_${pad(d.getHours())}${pad(d.getMinutes())}_${who}.hhmatch`;
  }

  /* ---------------- storage: browser + optional save folder ---------------- */
  const session = new Map();
  function index() { try { return JSON.parse(root.localStorage.getItem(INDEX_KEY) || '[]'); } catch (err) { return []; } }
  function writeIndex(list) { try { root.localStorage.setItem(INDEX_KEY, JSON.stringify(list)); } catch (err) { /* ignore */ } }
  function metaEntry(save, where, file) { return { id: save.id, savedAt: save.savedAt, appVersion: save.appVersion, where, file: file || null, meta: save.meta }; }
  function idb() {
    return new Promise((res, rej) => {
      if (typeof indexedDB === 'undefined') return rej(new Error('no indexedDB'));
      const r = indexedDB.open('harbor-hearth', 1); r.onupgradeneeded = () => r.result.createObjectStore('kv'); r.onsuccess = () => res(r.result); r.onerror = () => rej(r.error);
    });
  }
  async function kvGet(k) { const db = await idb(); return new Promise((res) => { const t = db.transaction('kv').objectStore('kv').get(k); t.onsuccess = () => res(t.result); t.onerror = () => res(null); }); }
  async function kvSet(k, v) { const db = await idb(); return new Promise((res) => { const t = db.transaction('kv', 'readwrite').objectStore('kv').put(v, k); t.onsuccess = () => res(true); t.onerror = () => res(false); }); }
  const Saves = {
    folderSupported: hasDoc && typeof root.showDirectoryPicker === 'function',
    folderName: null, folderReady: false, lastError: '',
    list() { return index().concat([...session.values()].map((s) => metaEntry(s, 'session'))).sort((a, b) => (b.meta.endedAt || b.savedAt) - (a.meta.endedAt || a.savedAt)); },
    async store(save) {
      const list = index().filter((x) => x.id !== save.id); let where = 'session'; let file = null;
      try {
        const gz = await gzip(JSON.stringify(save));
        const value = gz ? 'gz:' + b64(gz) : 'js:' + JSON.stringify(save);
        root.localStorage.setItem('hh.match.' + save.id, value); where = 'local';
      } catch (err) { Saves.lastError = 'Browser storage is full, so this match is kept in the save folder or for this session only. Export it to keep a copy.'; }
      if (Saves.folderReady) { try { file = await Saves.writeFile(save); if (where === 'session') where = 'folder'; } catch (err) { /* folder unavailable */ } }
      if (where === 'session') session.set(save.id, save);
      else { list.push(metaEntry(save, where, file)); writeIndex(list); }
      return where;
    },
    async load(entry) {
      if (session.has(entry.id)) return session.get(entry.id);
      const raw = root.localStorage.getItem('hh.match.' + entry.id);
      if (raw) { if (raw.startsWith('gz:')) return validate(JSON.parse(await gunzip(unb64(raw.slice(3))))); return validate(JSON.parse(raw.slice(3))); }
      if (entry.file && Saves.handle) { const fh = await Saves.handle.getFileHandle(entry.file); const f = await fh.getFile(); return decodeBytes(new Uint8Array(await f.arrayBuffer())); }
      throw new Error('The saved data for this match could not be found.');
    },
    remove(entry) { session.delete(entry.id); try { root.localStorage.removeItem('hh.match.' + entry.id); } catch (err) { /* ignore */ } writeIndex(index().filter((x) => x.id !== entry.id)); },
    async export(entry) {
      const save = await Saves.load(entry); const blob = await encodeFile(save);
      const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = fileName(save); document.body.appendChild(a); a.click();
      setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000);
    },
    async importFiles(files) {
      let ok = 0; const errors = [];
      for (const f of files) {
        try { const save = await decodeBytes(new Uint8Array(await f.arrayBuffer())); if (!index().some((x) => x.id === save.id)) { await Saves.store(save); ok++; } } catch (err) { errors.push(`${f.name}: ${err.message}`); }
      }
      return { ok, errors };
    },
    async restoreFolder() {
      if (!Saves.folderSupported) return;
      try { const h = await kvGet('saveFolder'); if (!h) return; Saves.handle = h; Saves.folderName = h.name; Saves.folderReady = (await h.queryPermission({ mode: 'readwrite' })) === 'granted'; } catch (err) { /* ignore */ }
    },
    async pickFolder() {
      const h = await root.showDirectoryPicker({ id: 'hh-saves', mode: 'readwrite' });
      Saves.handle = h; Saves.folderName = h.name; Saves.folderReady = true; await kvSet('saveFolder', h);
      return Saves.scanFolder();
    },
    async reconnect() { if (!Saves.handle) return; Saves.folderReady = (await Saves.handle.requestPermission({ mode: 'readwrite' })) === 'granted'; if (Saves.folderReady) return Saves.scanFolder(); },
    async writeFile(save) {
      const name = fileName(save); const fh = await Saves.handle.getFileHandle(name, { create: true }); const w = await fh.createWritable();
      await w.write(await encodeFile(save)); await w.close(); return name;
    },
    // Copy every match in the folder into the history list, and every browser-only match into the folder.
    async scanFolder() {
      if (!Saves.handle || !Saves.folderReady) return { ok: 0, errors: [] };
      let ok = 0; const errors = []; const known = new Set(index().map((x) => x.id)); const inFolder = new Set();
      for await (const [name, fh] of Saves.handle.entries()) {
        if (fh.kind !== 'file' || !/\.(hhmatch|json)$/i.test(name)) continue;
        try {
          const save = await decodeBytes(new Uint8Array(await (await fh.getFile()).arrayBuffer())); inFolder.add(save.id);
          if (!known.has(save.id)) { const list = index(); list.push(metaEntry(save, 'folder', name)); writeIndex(list); known.add(save.id); ok++; }
        } catch (err) { errors.push(`${name}: ${err.message}`); }
      }
      for (const entry of index()) { if (!inFolder.has(entry.id) && entry.where === 'local') { try { await Saves.writeFile(await Saves.load(entry)); } catch (err) { /* skip */ } } }
      return { ok, errors };
    }
  };
  root.Saves = Saves;
  root.HearthSave = { FORMAT, FORMAT_VERSION, APP_VERSION, buildSave, encodeFile, decodeBytes, flatten, fileName };

  /* ---------------- replay ---------------- */
  const Replay = {
    save: null, idx: 0, playing: false, speed: 1, timer: null, keys: [], reveal: false,
    open(save) {
      Replay.save = save; Replay.idx = 0; Replay.playing = false; Replay.reveal = false; clearTimeout(Replay.timer);
      // keyframes every 30 events make scrubbing instant
      Replay.keys = []; let cur = Object.assign({}, save.replay.initial);
      Replay.keys[0] = cur;
      save.replay.events.forEach((ev, i) => { cur = Object.assign({}, cur, ev.d); if ((i + 1) % 30 === 0) Replay.keys[(i + 1) / 30] = cur; });
      Replay.show(null);
    },
    total() { return Replay.save ? Replay.save.replay.events.length : 0; },
    frame(i) {
      const k = Math.floor(i / 30); let cur = Object.assign({}, Replay.keys[k] || Replay.save.replay.initial);
      for (let j = k * 30; j < i; j++) Object.assign(cur, Replay.save.replay.events[j].d);
      return cur;
    },
    game(i) {
      const s = Replay.save; const f = Replay.frame(i);
      const board = { mapId: s.board.mapId, tiles: s.board.tiles.map((t) => Object.assign({}, t)), nodes: s.board.nodes, edges: s.board.edges, ports: s.board.ports, robber: f.robber };
      const toMap = (arr) => { const o = {}; RES.forEach((k, j) => { o[k] = (arr || [])[j] || 0; }); return o; };
      const players = s.players.map((pl, j) => {
        const d = f[`p${j}.d`] || []; const hidden = f[`p${j}.h`] || 0;
        return { id: pl.id, name: pl.name, color: pl.color, bot: pl.bot, style: pl.style, styleLabel: pl.styleLabel, r: toMap(f[`p${j}.r`]), roads: f[`p${j}.ro`] || [], settlements: f[`p${j}.s`] || [], cities: f[`p${j}.c`] || [], dev: d.filter((c) => c !== 'victory'), newDev: [], secretVp: Array(hidden).fill('victory'), knights: f[`p${j}.k`] || 0, vp: f[`p${j}.v`] || 0, ports: f[`p${j}.pt`] || [] };
      });
      const log = []; for (let j = 0; j < i; j++) s.replay.events[j].tx.forEach((t) => log.unshift(esc(t)));
      return { replay: true, board, players, bank: toMap(f.bank), deck: Array(f.deck || 0).fill('?'), longest: f.lr, largest: f.la, dice: f.dice, turn: f.turn || 0, turnCount: f.tc || 0, phase: 'replay', winner: f.win, log, offer: null, freeRoads: 0, discardQueue: [], stats: null, fx: null, rulesId: s.meta.rulesId };
    },
    show(fxEvent) {
      // `game` is the shared global table state declared in offline.js
      game = Replay.game(Replay.idx);
      if (fxEvent && fxEvent.fx) game.fx = { tiles: fxEvent.fx.tiles, grants: fxEvent.fx.g.map(([seat, resource, amount, x, y]) => ({ playerId: game.players[seat].id, resource, amount, x, y })) };
      if (root.render) root.render();
    },
    seek(i) { Replay.idx = Math.max(0, Math.min(Replay.total(), i | 0)); Replay.show(null); },
    step(d) {
      const ni = Math.max(0, Math.min(Replay.total(), Replay.idx + d));
      const ev = d === 1 && ni > Replay.idx ? Replay.save.replay.events[Replay.idx] : null;
      Replay.idx = ni; Replay.show(ev);
      if (Replay.idx >= Replay.total()) Replay.pause();
    },
    turn(d) {
      const evs = Replay.save.replay.events; let i = Replay.idx;
      if (d > 0) { i++; while (i < evs.length && evs[i - 1].k !== 'turn') i++; } else { i--; while (i > 0 && evs[i - 1].k !== 'turn') i--; if (i > 0) i--; while (i > 0 && evs[i - 1].k !== 'turn') i--; }
      Replay.seek(i);
    },
    play() {
      if (Replay.idx >= Replay.total()) Replay.idx = 0;
      Replay.playing = true; Replay.tick();
    },
    tick() {
      clearTimeout(Replay.timer); if (!Replay.playing) return;
      Replay.step(1); if (!Replay.playing) return;
      const ev = Replay.save.replay.events[Replay.idx]; const base = ev && ev.k === 'roll' ? 1500 : ev && ev.k === 'turn' ? 500 : 900;
      Replay.timer = setTimeout(Replay.tick, base / Replay.speed);
    },
    pause() { Replay.playing = false; clearTimeout(Replay.timer); if (root.render) root.render(); },
    toggle() { if (Replay.playing) Replay.pause(); else Replay.play(); },
    setSpeed(v) { Replay.speed = Number(v) || 1; if (Replay.playing) Replay.tick(); else if (root.render) root.render(); },
    exit() { Replay.pause(); Replay.save = null; game = null; if (root.ui) root.ui.screen = 'history'; if (root.render) root.render(); },
    caption() {
      if (!Replay.save) return '';
      if (Replay.idx === 0) return 'The island before the first settlement.';
      const ev = Replay.save.replay.events[Replay.idx - 1];
      return esc(ev.tx.join(' · ') || 'Board update.');
    },
    controls() {
      const n = Replay.total(); const i = Replay.idx; const ev = i ? Replay.save.replay.events[i - 1] : null;
      const t = ev ? root.fmtDuration(ev.t) : '0m 0s';
      return `<div class="replay-bar"><div class="rp-buttons">` +
        `<button onclick="Replay.seek(0)" ${tipAttrs('Restart', 'Back to the start of the match')}>⏮</button>` +
        `<button onclick="Replay.turn(-1)" ${tipAttrs('Previous turn', 'Jump to the start of the previous turn')}>⏪</button>` +
        `<button onclick="Replay.pause();Replay.step(-1)" ${tipAttrs('Previous event', 'Step back one event')}>◀</button>` +
        `<button class="rp-play" onclick="Replay.toggle()" ${tipAttrs(Replay.playing ? 'Pause' : 'Play', 'Play or pause the replay')}>${Replay.playing ? '❚❚' : '▶'}</button>` +
        `<button onclick="Replay.pause();Replay.step(1)" ${tipAttrs('Next event', 'Step forward one event')}>▶|</button>` +
        `<button onclick="Replay.turn(1)" ${tipAttrs('Next turn', 'Jump to the start of the next turn')}>⏩</button>` +
        `<label class="rp-speed" ${tipAttrs('Playback speed', 'How fast the replay advances')}>Speed <select onchange="Replay.setSpeed(this.value)">${[0.5, 1, 2, 4, 8].map((v) => `<option value="${v}" ${v === Replay.speed ? 'selected' : ''}>${v}×</option>`).join('')}</select></label>` +
        `<label class="rp-reveal"><input type="checkbox" ${Replay.reveal ? 'checked' : ''} onchange="Replay.reveal=this.checked;render()"> Show hands</label>` +
        `</div><div class="rp-timeline"><input type="range" min="0" max="${n}" value="${i}" oninput="Replay.pause();Replay.seek(this.value)" aria-label="Replay timeline"><span>Event ${i} / ${n} · ${t}</span></div>` +
        `<div class="rp-caption">${Replay.caption()}</div><div class="rp-exit"><button onclick="openSavedStats()">Statistics</button><button onclick="Replay.exit()">Exit replay</button></div></div>`;
    }
  };
  root.Replay = Replay;

  /* ---------------- match history screen ---------------- */
  const H = { busy: false, msg: '', view: null, openSave: null, statsTab: 'summary' };
  root.HistoryUI = H;
  function historyScreen() {
    const list = Saves.list();
    const folder = Saves.folderSupported
      ? (Saves.handle ? `<span>Save folder: <b>${esc(Saves.folderName)}</b>${Saves.folderReady ? '' : ' (needs permission)'}</span>${Saves.folderReady ? '<button onclick="historyAction(\'scan\')">Rescan folder</button>' : '<button onclick="historyAction(\'reconnect\')">Allow access</button>'}<button onclick="historyAction(\'folder\')">Change folder</button>` : '<button onclick="historyAction(\'folder\')" data-tip="Pick a folder; every finished match is also written there as a .hhmatch file. Point a future version at the same folder to keep your history.">Choose save folder</button>')
      : '<span class="muted">Folder saving needs Chrome or Edge. Use Export and Import to move matches.</span>';
    const rows = list.length ? list.map((x) => {
      const m = x.meta; const d = new Date(m.endedAt || x.savedAt);
      return `<li class="hist-row"><div class="hr-main"><b>${d.toLocaleDateString()} ${d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}</b><span class="hr-players">${m.players.map((q) => `<i class="sw" style="--color:${q.color}"></i>${esc(q.name)}${m.winner && q.name === m.winner.name ? ' ♛' : ''}`).join(' ')}</span><small>${m.turns} turns · ${root.fmtDuration(m.durationMs)} · ${esc(m.difficulty)} bots · saved by V${esc(x.appVersion)}${x.where === 'session' ? ' · this session only' : ''}</small></div>` +
        `<div class="hr-actions"><button onclick="historyAction('stats','${x.id}')">Statistics</button><button onclick="historyAction('chronicle','${x.id}')">Chronicle</button><button class="primary" onclick="historyAction('replay','${x.id}')">Watch replay</button><button onclick="historyAction('export','${x.id}')" data-tip="Download this match as a .hhmatch file">Export</button><button class="danger" onclick="historyAction('delete','${x.id}')">Delete</button></div></li>`;
    }).join('') : '<li class="hist-empty">No finished matches yet. Every completed game is saved here automatically.</li>';
    let overlay = '';
    if (H.view === 'stats' && H.openSave) overlay = root.statsScreen(H.openSave.summary, { tab: H.statsTab, tabCall: 'setHistoryStatsTab', close: "historyAction('close')", showStyles: root.HearthSettings.get('showArchetypes'), buttons: [{ label: 'Watch replay', on: `historyAction('replay','${H.openSave.id}')`, cls: 'primary' }, { label: 'Close', on: "historyAction('close')" }] });
    if (H.view === 'chronicle' && H.openSave) overlay = `<div class="overlay"><div class="stats-modal chron-modal"><header><h2>Chronicle</h2><button class="tm-x" onclick="historyAction('close')">✕</button></header><ol class="chron-full">${H.openSave.chronicle.map((t) => `<li>${esc(t)}</li>`).join('')}</ol></div></div>`;
    return `<section class="menu-screen history"><div class="menu-card wide"><header class="menu-head"><h1>Match History</h1><button onclick="ui.screen='main';render()">Back</button></header>` +
      `<div class="hist-tools">${folder}<label class="file-btn">Import files<input type="file" accept=".hhmatch,.json,application/gzip,application/json" multiple onchange="historyImport(this.files)"></label></div>` +
      `${H.msg ? `<p class="alert">${esc(H.msg)}</p>` : ''}${Saves.lastError ? `<p class="alert">${esc(Saves.lastError)}</p>` : ''}<ul class="hist-list">${rows}</ul></div>${overlay}</section>`;
  }
  root.historyScreen = historyScreen;
  root.setHistoryStatsTab = (t) => { H.statsTab = t; root.render(); };
  root.historyImport = async (files) => { H.msg = 'Importing…'; root.render(); const r = await Saves.importFiles([...files]); H.msg = `Imported ${r.ok} match${r.ok === 1 ? '' : 'es'}.${r.errors.length ? ' Problems: ' + r.errors.join('; ') : ''}`; root.render(); };
  root.historyAction = async (what, id) => {
    const entry = id ? Saves.list().find((x) => x.id === id) : null;
    try {
      if (what === 'close') { H.view = null; H.openSave = null; }
      if (what === 'folder') { const r = await Saves.pickFolder(); H.msg = `Save folder set. ${r.ok} match${r.ok === 1 ? '' : 'es'} found in it.`; }
      if (what === 'reconnect') { const r = await Saves.reconnect(); H.msg = r ? `Folder connected. ${r.ok} new match${r.ok === 1 ? '' : 'es'} found.` : 'Folder access was not granted.'; }
      if (what === 'scan') { const r = await Saves.scanFolder(); H.msg = `${r.ok} new match${r.ok === 1 ? '' : 'es'} found.${r.errors.length ? ' Problems: ' + r.errors.join('; ') : ''}`; }
      if (what === 'stats' || what === 'chronicle') { H.openSave = await Saves.load(entry); H.view = what; H.statsTab = 'summary'; }
      if (what === 'replay') { const save = H.openSave && H.openSave.id === id ? H.openSave : await Saves.load(entry); H.view = null; H.openSave = save; root.ui.screen = 'replay'; Replay.open(save); return; }
      if (what === 'export') await Saves.export(entry);
      if (what === 'delete') { if (root.confirm && !root.confirm('Delete this match from your history? Exported files and files in your save folder are not affected.')) return; Saves.remove(entry); }
    } catch (err) { if (err && err.name === 'AbortError') return; H.msg = err.message || String(err); }
    root.render();
  };
  root.openSavedStats = () => { if (!Replay.save) return; Replay.pause(); H.openSave = Replay.save; H.view = 'stats'; root.ui.replayStats = true; root.render(); };
})(typeof globalThis !== 'undefined' ? globalThis : this);
