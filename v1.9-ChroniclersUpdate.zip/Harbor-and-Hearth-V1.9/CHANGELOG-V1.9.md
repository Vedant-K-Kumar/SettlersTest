# Harbor & Hearth V1.9

## Interface
- New medieval typography, bundled with the game so it works offline on Chromebooks: Pirata One (titles), MedievalSharp (buttons and labels), Alegreya (text and numbers, with even-height digits for dice, tokens and counts). All three fonts are under the SIL Open Font License (`public/fonts/LICENSE.txt`).
- New layout that fits the window with no scrolling:
  - Chronicle (collapsible) and notifications on the left; every notification has a ✕.
  - Bank and player profiles on the right.
  - Hand, progress cards, building and trading in a bottom bar. The old right-side action panel is gone.
- Player profiles have card-style indicators for Goods, Progress and Renown. Longest Road and Largest Army badges light up the moment ownership changes, and a highlighted notification announces it.
- Your own profile shows hidden points as `2 (+3)`.
- Bank panel: remaining cards of each resource and the progress deck.
- Resource cards have much larger numbers. During production, larger cards fly to the player who receives them.
- The Chronicle lists exactly what each player collected on every roll, and explains any bank shortage.
- Medieval tooltips throughout. Hover shows the short text; holding Shift or hovering longer shows details.
- When building, the cost and any missing cards follow the cursor and appear in the prompt.

## Settings (main menu and in-game ⚙)
- 2.5D or new clean 2D map, switchable at any time.
- Show or hide bot archetypes, including their tooltips.
- Preferred player colour.
- Animations: slower / normal / faster, reduced animations, or no decorative animations. These are saved.
- Keyboard shortcuts for 12 actions, all unbound by default; ✕ removes a binding.

## Rules
- Finite bank: 19 of each resource and a 25-card progress deck, configurable in `rules.js`. Standard shortage rule on production.
- Victory point cards count immediately, stay hidden from opponents and bots, and are all revealed automatically on the winning turn (even after another progress card that turn).
- Road Building goes straight into road placement and handles cases where only one road is possible.
- The Monopoly dialog no longer shows how many cards opponents hold.

## Bots
- **Easy:** the V1.7 bots, repaired (fair play, piece limits, bounded turns).
- **Normal:** the V1.8 strategic bots.
- **Hard:** shown, but crossed out (Not Implemented).

## Statistics, saving and replays
- End-of-game summary: standings (visible and hidden points), MVP awards, dice distribution against expected, a full resource ledger, progress cards, and match duration.
- Finished matches are saved automatically as compressed `.hhmatch` files (see `SAVE_FORMAT.md`).
- Match History offers statistics, the full Chronicle, export/import, and an optional save folder.
- Full replays: play/pause, step, previous/next turn, speed, timeline scrubbing, restart, and show-hands. They use either map style.

## For V2.0
- Archetypes are defined only in `public/archetypes.js`; add one with `HearthArchetypes.register()`.
- Maps are data in `public/maps.js`, with `HearthMaps.build()` and `register()`. A fixed layout (`fixed`, `fixedPorts`) is supported for a map maker.
- Board renderers register in `public/renderers.js`.
- **Map/AI note:** the new map system and 2D/2.5D switching caused **no AI problems in testing**. Both AIs read only board data, never the renderer. The Normal AI still assumes the standard hex geometry (any map built by `HearthMaps.build` works). Unusual custom maps from a future map maker have not been tested with the bots.

## Not changed
- Hosted multiplayer mode (`npm start`) keeps its V1.8 interface. It gained the bank shortage rule; the redesign covers the offline game.
