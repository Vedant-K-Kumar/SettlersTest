const app = document.querySelector('#app');
const R = ['wood', 'brick', 'wool', 'grain', 'ore'];
const NAME = { wood:'Wood', brick:'Brick', wool:'Wool', grain:'Grain', ore:'Ore' };
const COLORS = ['#b73d2e', '#236f93', '#d69b27', '#5a7f43'];
const TERRAINS = ['wood','wood','wood','wood','grain','grain','grain','grain','wool','wool','wool','wool','brick','brick','brick','ore','ore','ore','desert'];
const NUMBERS = [2,3,3,4,4,5,5,6,6,8,8,9,9,10,10,11,11,12];
let game = null, tool = null, message = '', botTimer = null, audio = null, tradeSelection = { give: {wood:0,brick:0,wool:0,grain:0,ore:0}, want: {wood:0,brick:0,wool:0,grain:0,ore:0} };
const BOT_DELAY = 1250;
const empty = () => ({wood:0,brick:0,wool:0,grain:0,ore:0});
const sum = x => R.reduce((n,k)=>n+(x[k]||0),0);
const goods = x => R.filter(k=>x[k]).map(k=>`${x[k]} ${NAME[k]}`).join(', ') || 'nothing';
const rand = () => { try { const a = new Uint32Array(1); globalThis.crypto.getRandomValues(a); return a[0] / 4294967296; } catch (err) { return Math.random(); } };
// Fisher-Yates. v7 used sort(()=>Math.random()-.5), which is biased: in Chrome it tends to leave items near
// their starting positions, so boards, the progress deck, and any ordering built with it were not truly random.
const shuffle = x => { const a = [...x]; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const key = (x,y) => `${Math.round(x*100)/100},${Math.round(y*100)/100}`;
const edgeKey = (a,b) => [a,b].sort().join('|');
const px = (q,r) => ({x:Math.sqrt(3)*(q+r/2),y:1.5*r});
function prepareSound(){try{audio=new (window.AudioContext||window.webkitAudioContext)();audio.resume()}catch{audio=null}}
function sound(kind){if(!audio)return;let now=audio.currentTime,notes=kind==='road'?[160,205]:kind==='settlement'?[392,523,659]:[130,165,210,260];notes.forEach((frequency,index)=>{let oscillator=audio.createOscillator(),gain=audio.createGain();oscillator.type=kind==='dice'?'square':'triangle';oscillator.frequency.setValueAtTime(frequency,now+index*.06);gain.gain.setValueAtTime(.0001,now+index*.06);gain.gain.exponentialRampToValueAtTime(kind==='dice'?.035:.06,now+index*.06+.01);gain.gain.exponentialRampToValueAtTime(.0001,now+index*.06+.11);oscillator.connect(gain).connect(audio.destination);oscillator.start(now+index*.06);oscillator.stop(now+index*.06+.13)})}
function createBoard(){
  const coords=[]; for(let q=-2;q<=2;q++)for(let r=-2;r<=2;r++)if(Math.abs(q+r)<=2)coords.push({q,r});
  let tiles;
  do { let nums=shuffle(NUMBERS), ni=0, ts=shuffle(TERRAINS); tiles=coords.map((c,i)=>({...c,id:String(i),terrain:ts[i],number:ts[i]==='desert'?null:nums[ni++],center:px(c.q,c.r)})); }
  while(tiles.some(t=>(t.number===6||t.number===8)&&tiles.some(o=>o!==t&&(o.number===6||o.number===8)&&Math.abs(t.q-o.q)+Math.abs(t.r-o.r)+Math.abs(t.q+t.r-o.q-o.r)===2)));
  const nodes=new Map(), edges=new Map();
  tiles.forEach(t=>{t.nodes=[];for(let i=0;i<6;i++){let a=(60*i-30)*Math.PI/180,p={x:t.center.x+Math.cos(a),y:t.center.y+Math.sin(a)},k=key(p.x,p.y);if(!nodes.has(k))nodes.set(k,{id:`n${nodes.size}`,x:p.x,y:p.y,tiles:[]});let n=nodes.get(k);n.tiles.push(t.id);t.nodes.push(n.id)}for(let i=0;i<6;i++){let a=t.nodes[i],b=t.nodes[(i+1)%6],k=edgeKey(a,b);if(!edges.has(k))edges.set(k,{id:`e${edges.size}`,a,b,tiles:[]});edges.get(k).tiles.push(t.id)}});
  const edgeList=[...edges.values()], coast=edgeList.filter(e=>e.tiles.length===1), nm=new Map([...nodes.values()].map(z=>[z.id,z])), ang=e=>{let u=nm.get(e.a),v=nm.get(e.b);return Math.atan2((u.y+v.y)/2,(u.x+v.x)/2)}, sorted=coast.sort((u,v)=>ang(u)-ang(v)), types=shuffle(['any','any','any','any','wood','brick','wool','grain','ore']);
  return {tiles,nodes:[...nodes.values()],edges:edgeList,ports:Array.from({length:9},(_,i)=>coast[Math.floor((i+.5)*coast.length/9)]).map((e,i)=>({edge:e.id,type:types[i]})),robber:tiles.find(t=>t.terrain==='desert').id};
}
function start(){
  prepareSound();
  const names=[...document.querySelectorAll('[data-name]')].map((input,index)=>input.value.trim()||`Hearthkeeper ${index+1}`);
  const seats=names.slice(0,4).map((name,i)=>({id:i,name,bot:name.startsWith('Hearthkeeper'),color:COLORS[i],r:empty(),roads:[],settlements:[],cities:[],ports:[],dev:[],newDev:[],secretVp:[],knights:0,vp:0}));
  const bots=seats.filter(q=>q.bot),styles=HearthAI.assignStyles(bots.length,rand);
  bots.forEach((q,i)=>{q.style=styles[i];q.styleLabel=HearthAI.STYLES[styles[i]].label});
  // Turn order fix: v7 never randomized seating, so seat one always placed first and always rolled first
  // (game.turn was hard-reset to 0 after setup). Seats are now shuffled without bias; players[0] places
  // first, places last in the reverse setup round, and takes the first roll.
  const players=shuffle(seats);
  game={board:createBoard(),players,turn:0,phase:'setup',setup:[...players.keys(),...players.keys()].map((x,i)=>i<players.length?x:players.length*2-1-i),step:0,setupNode:null,bank:{wood:19,brick:19,wool:19,grain:19,ore:19},deck:shuffle(['knight','knight','knight','knight','knight','knight','knight','knight','knight','knight','knight','knight','knight','knight','road','road','plenty','plenty','monopoly','monopoly','victory','victory','victory','victory','victory']),log:['The first settlement awaits.'],longest:null,largest:null,freeRoads:0,winner:null,offer:null,turnCount:0,discardQueue:[],discardPick:empty(),pick:null,devUsed:{road:0,plenty:0,monopoly:0},ai:{snap:{},est:{}}};
  game.turn=game.setup[0];
  note(`Turn order: ${players.map(q=>q.name).join(' &rarr; ')}. ${players[0].name} places first.`);
  maybeBot(); render();
}
function p(){return game.players[game.turn]}; function n(id){return game.board.nodes.find(x=>x.id===id)}; function e(id){return game.board.edges.find(x=>x.id===id)};
function owner(node){return game.players.find(x=>x.settlements.includes(node)||x.cities.includes(node))};
function adj(node){return game.board.edges.filter(x=>x.a===node||x.b===node)}; function near(node){return adj(node).map(x=>x.a===node?x.b:x.a)};
function note(x){game.log.unshift(x);game.log=game.log.slice(0,24)}; function paid(x,c){return R.every(k=>x.r[k]>=(c[k]||0))}; function take(x,c){R.forEach(k=>x.r[k]-=c[k]||0)}; function give(x,c){R.forEach(k=>x.r[k]+=c[k]||0)};
function freeNode(id){return !owner(id)&&near(id).every(x=>!owner(x))}; function canSet(x,id){return freeNode(id)&&(game.phase==='setup'?!game.setupNode:adj(id).some(z=>x.roads.includes(z.id)))};
function canRoad(x,id){let z=e(id);if(!z||game.players.some(q=>q.roads.includes(id)))return false;if(game.phase==='setup')return game.setupNode&&(z.a===game.setupNode||z.b===game.setupNode);return [z.a,z.b].some(a=>{let o=owner(a);return (!o||o===x)&&(x.settlements.includes(a)||x.cities.includes(a)||adj(a).some(q=>x.roads.includes(q.id)))});}
function score(x){return x.settlements.length+x.cities.length*2+x.vp+(game.longest===x.id?2:0)+(game.largest===x.id?2:0)};
function ports(x,id){game.board.ports.forEach(q=>{let z=e(q.edge);if((z.a===id||z.b===id)&&!x.ports.includes(q.type))x.ports.push(q.type)})}
function placeSet(id){let x=p();if(game.phase==='setup'&&game.setupNode)return say('Place the road that leaves this settlement.');if(game.phase!=='setup'&&x.settlements.length>=5)return say('All five houses are on the board. Upgrade one to a city to free a house.');if(!canSet(x,id))return say('Settlements require an empty junction, clear of neighboring settlements, and connected to your road after setup.');let c={wood:1,brick:1,wool:1,grain:1};if(game.phase!=='setup'){if(!paid(x,c))return say('A settlement costs 1 Wood, 1 Brick, 1 Wool, and 1 Grain.');take(x,c);give({r:game.bank},c)}x.settlements.push(id);ports(x,id);game.setupNode=id;if(game.phase==='setup'&&x.settlements.length===2){n(id).tiles.forEach(tid=>{let t=game.board.tiles.find(q=>q.id===tid);if(t.terrain!=='desert'&&game.bank[t.terrain]){x.r[t.terrain]++;game.bank[t.terrain]--}})}sound('settlement');note(`${x.name} raises a settlement.`);tool=null;awards();if(game.phase!=='setup')win(x);render();if(game.phase==='setup'&&x.bot)maybeBot()}
function placeRoad(id){let x=p();if(x.roads.length>=15)return say('All fifteen roads are on the board.');if(!canRoad(x,id))return say('Roads must join your network and may not pass through another settlement.');let c={wood:1,brick:1};if(!game.freeRoads&&game.phase!=='setup'){if(!paid(x,c))return say('A road costs 1 Wood and 1 Brick.');take(x,c);give({r:game.bank},c)}x.roads.push(id);if(game.freeRoads)game.freeRoads--;sound('road');note(`${x.name} lays a road.`);tool=null;let wasSetup=game.phase==='setup';if(wasSetup){game.step++;if(game.step===game.setup.length){game.phase='roll';game.turn=game.setup[0];note(`${p().name} begins the first harvest.`)}else{game.turn=game.setup[game.step];game.setupNode=null;note(`${p().name} places a settlement.`)}}else{awards();win(x)}render();if(wasSetup&&p().bot)maybeBot()}
function city(id){let x=p(),c={grain:2,ore:3};if(x.cities.length>=4)return say('All four cities are on the board.');if(!x.settlements.includes(id)||!paid(x,c))return say('A city upgrades your settlement for 2 grain and 3 ore.');take(x,c);give({r:game.bank},c);x.settlements=x.settlements.filter(q=>q!==id);x.cities.push(id);note(`${x.name} builds a city.`);win(x);tool=null;render()}
function roll(){if(game.phase!=='roll'||game.rolling)return;let one=1+Math.floor(rand()*6),two=1+Math.floor(rand()*6),v=one+two;game.rolling=true;game.dice=[one,two];sound('dice');render();setTimeout(()=>{game.last=v;game.rolling=false;note(`${p().name} rolls ${v}.`);if(v===7){let order=game.players.map(q=>q.id);order=[...order.slice(game.turn),...order.slice(0,game.turn)];game.discardQueue=order.filter(id=>sum(game.players.find(q=>q.id===id).r)>7);game.discardPick=empty();if(game.discardQueue.length){game.phase='discard';note('A seven: anyone with more than seven cards discards half.');advanceDiscard()}else{game.phase='robber';tool='robber'}}else{
        const flashed=game.board.tiles.filter(t=>t.number===v).map(t=>t.id),grants=[];
        game.board.tiles.filter(t=>t.number===v&&t.id!==game.board.robber).forEach(t=>game.players.forEach(x=>t.nodes.forEach(id=>{let amount=x.settlements.includes(id)?1:x.cities.includes(id)?2:0;if(amount&&game.bank[t.terrain]>=amount){x.r[t.terrain]+=amount;game.bank[t.terrain]-=amount;grants.push({playerId:x.id,resource:t.terrain,amount,x:t.center.x,y:t.center.y})}})));
        game.fx={tiles:flashed,grants};game.phase='build'}render();maybeBot()},720)}
function discarder(){return game.players.find(x=>x.id===(game.discardQueue||[])[0])}
function advanceDiscard(){if(!game||game.phase!=='discard')return;while(game.discardQueue.length){let x=discarder();if(!x||!x.bot)return;let amount=Math.floor(sum(x.r)/2),pick=botDiscard(x,amount);R.forEach(k=>{x.r[k]-=pick[k];game.bank[k]+=pick[k]});note(`${x.name} discards ${goodsHtml(pick)}.`);game.discardQueue.shift()}game.phase='robber';tool='robber';game.discardPick=empty()}
function adjustDiscard(k,d){let x=discarder();if(!x||x.bot||game.phase!=='discard')return;if(!game.discardPick)game.discardPick=empty();let need=Math.floor(sum(x.r)/2),next=(game.discardPick[k]||0)+d;if(next<0||next>x.r[k])return;if(sum(game.discardPick)-(game.discardPick[k]||0)+next>need)return;game.discardPick[k]=next;render()}
function confirmDiscard(){let x=discarder();if(!x||x.bot)return;let need=Math.floor(sum(x.r)/2);if(sum(game.discardPick)!==need||!canPayMap(x,game.discardPick))return say(`Discard exactly ${need} cards you hold.`);R.forEach(k=>{x.r[k]-=game.discardPick[k];game.bank[k]+=game.discardPick[k]});note(`${x.name} discards ${goodsHtml(game.discardPick)}.`);game.discardQueue.shift();game.discardPick=empty();advanceDiscard();render();maybeBot()}
function discardPanel(){let who=discarder();if(!who)return '';let need=Math.floor(sum(who.r)/2),got=sum(game.discardPick||empty());if(who.bot)return `<section><h2>Discard</h2><div class="status"><strong>${who.name}</strong>is returning ${need} cards.</div></section>`;return `<section><h2>Discard</h2><div class="status"><strong>${who.name}</strong>Choose exactly ${need} cards. ${got} of ${need} selected. Use + and − under each resource to decide how many of that good to give up.</div><div class="actions"><button class="wide" onclick="confirmDiscard()" ${got===need?'':'disabled'}>Discard ${need} cards</button></div></section>`}
function finishRobber(tileId,victimId){let actor=p(),victim=game.players.find(x=>x.id===victimId);game.board.robber=tileId;if(victim&&victim!==actor){trackSync();let cards=R.flatMap(k=>Array(victim.r[k]).fill(k)),taken=cards[Math.floor(rand()*cards.length)];if(taken){victim.r[taken]--;actor.r[taken]++;trackSteal(actor,victim,taken);note(`${actor.name} robs ${victim.name}.`);toast('steal','Robber strikes!',[{who:actor.name,text:`Took a card from ${victim.name}.`}])}}else note(`${actor.name} moves the guard without a theft.`);game.phase=game.afterRobber||'build';game.afterRobber=null;tool=null;game.robberTile=null;render();maybeBot()}
function robber(id){if(game.phase!=='robber'||id===game.board.robber)return;let t=game.board.tiles.find(x=>x.id===id),victims=game.players.filter(x=>x!==p()&&sum(x.r)&&t.nodes.some(a=>x.settlements.includes(a)||x.cities.includes(a)));if(!p().bot&&victims.length){game.robberTile=id;tool='robber-victim';render();return}let victim=victims.sort((a,b)=>sum(b.r)-sum(a.r))[0];finishRobber(id,victim?victim.id:null)}
function buy(){let x=p(),c={wool:1,grain:1,ore:1};if(game.phase!=='build')return say('Buy a progress card after you roll.');if(!paid(x,c)||!game.deck.length)return say('A progress card costs wool, grain, and ore.');take(x,c);give({r:game.bank},c);x.newDev.push(game.deck.pop());note(`${x.name} draws a progress card.`);win(x);render()}
function revealVp(){let x=p();if(!x||x.bot)return;let i=x.newDev.indexOf('victory');if(i>=0)x.newDev.splice(i,1);else if(x.secretVp&&x.secretVp.length)x.secretVp.pop();else return;x.vp++;note(`${x.name} reveals a victory point.`);win(x);render()}
function beginTrade(kind){if(game.pick)return;tool=kind;tradeSelection={give:empty(),want:empty()};bankSel={give:null,qty:1,want:empty()};render()}
function chooseTrade(side,resource){if(!['bank','offer'].includes(tool))return;let ceiling=side==='give'?p().r[resource]:4;tradeSelection[side][resource]=tradeSelection[side][resource]>=ceiling?0:tradeSelection[side][resource]+1;render()}
function bank(){let x=p(),g=bankSel.give,q=bankSel.qty,want=bankSel.want,rate=bankRate(x,g);if(!g||sum(want)!==q||want[g]||x.r[g]<rate*q||R.some(k=>(want[k]||0)>game.bank[k]))return say('Choose a resource to give and exactly that many different or matching cards to receive.');x.r[g]-=rate*q;game.bank[g]+=rate*q;R.forEach(k=>{x.r[k]+=want[k]||0;game.bank[k]-=want[k]||0});note(`${x.name} trades ${chip(g,rate*q)} for ${goodsHtml(want)} at the bank.`);toast('trade','Bank trade complete',[{who:x.name,lose:{[g]:rate*q},gain:want}]);tool=null;render()}
function canPayMap(player, map){return R.every(k=>player.r[k]>=(map[k]||0))}
function acceptOffer(playerId){let offer=game.offer,buyer=game.players.find(x=>x.id===playerId),seller=game.players.find(x=>x.id===offer?.from);if(!offer||!buyer||!seller)return;if(!canPayMap(buyer,offer.want)||!canPayMap(seller,offer.give))return toast('fail','Trade failed',[{who:seller.name+' & '+buyer.name,text:'One side no longer has the cards for this deal.'}]);R.forEach(k=>{seller.r[k]-=offer.give[k]||0;buyer.r[k]+=offer.give[k]||0;buyer.r[k]-=offer.want[k]||0;seller.r[k]+=offer.want[k]||0});note(`${buyer.name} accepts ${seller.name}'s trade: ${goodsHtml(offer.give)} for ${goodsHtml(offer.want)}.`);toast('trade','Trade complete',[{who:seller.name,lose:offer.give,gain:offer.want},{who:buyer.name,lose:offer.want,gain:offer.give}]);game.offer=null;render();maybeBot()}
function declineOffer(){if(!game.offer)return;let offer=game.offer,seller=game.players.find(x=>x.id===offer.from);note(`${seller.name}'s trade offer goes unanswered.`);toast('fail','Offer declined',[{who:seller.name,text:`${goodsHtml(offer.give)} for ${goodsHtml(offer.want)} was not accepted.`}]);if(seller.bot)seller.tradeDeclinedTurn=game.turnCount;game.offer=null;render();maybeBot()}
function submitOffer(){let give={...tradeSelection.give},want={...tradeSelection.want},seller=p();if(!sum(give)||!sum(want)||!canPayMap(seller,give)||R.some(k=>give[k]&&want[k]))return say('Choose cards to give and different cards to ask for, and only offer cards you hold.');game.offer={from:seller.id,give,want};let best=null;game.players.forEach(b=>{if(!b.bot||b===seller||!canPayMap(b,want))return;let s=HearthAI.acceptTrade(aiState(b),{give,want},game.players.indexOf(seller));if(s>0&&(!best||s>best.s))best={b,s}});if(best){tool=null;tradeSelection={give:empty(),want:empty()};acceptOffer(best.b.id)}else{note(`${seller.name}'s trade is declined: no bot can afford it or wants it.`);toast('fail','No deal',[{who:seller.name,text:`${goodsHtml(give)} for ${goodsHtml(want)}: no bot could afford it or saw value in it.`}]);game.offer=null;tool=null;render()}}
function next(){if(game.freeRoads&&game.phase==='build'&&(p().roads.length>=15||!game.board.edges.some(z=>canRoad(p(),z.id))))game.freeRoads=0;if(game.phase!=='build'||game.freeRoads)return say(game.freeRoads?'Place the remaining free roads.':'Roll before ending your turn.');let x=p();x.newDev.forEach(card=>{if(card==='victory')x.secretVp.push(card);else x.dev.push(card)});x.newDev=[];tool=null;game.turn=(game.turn+1)%game.players.length;game.turnCount++;game.phase='roll';note(`${p().name}'s turn begins.`);render();maybeBot()}
function play(card,choice){
  let x=p();
  if(!x.dev.includes(card)||card==='victory'||['setup','discard','robber','done'].includes(game.phase))return;
  // v7 only stopped bots from playing several progress cards in one turn; the rule now applies to everyone.
  if(x.devPlayedTurn===game.turnCount)return say('Only one progress card may be played each turn.');
  if(!x.bot&&card==='plenty'){game.pick={card:'plenty',chosen:[]};tool=null;render();return}
  if(!x.bot&&card==='monopoly'){game.pick={card:'monopoly',chosen:[]};tool=null;render();return}
  x.dev.splice(x.dev.indexOf(card),1);
  x.devPlayedTurn=game.turnCount;
  if(card==='knight'){
    x.knights++;game.afterRobber=game.phase==='roll'?'roll':'build';game.phase='robber';tool='robber';note(`${x.name} sends the guard.`);awards();
  }
  if(card==='road'){game.devUsed.road++;game.freeRoads=Math.max(0,Math.min(2,15-x.roads.length));note(`${x.name} receives two road deeds.`)}
  if(card==='plenty'){
    game.devUsed.plenty++;
    let picks=Array.isArray(choice)&&choice.length===2?choice:(HearthAI.plentyPick(aiState(x))||['grain','ore']),got=empty();
    picks.forEach(k=>{if(R.includes(k)&&game.bank[k]>0){x.r[k]++;game.bank[k]--;got[k]++}});
    note(`${x.name} takes ${goodsHtml(got)} from the bank.`);
  }
  if(card==='monopoly'){
    game.devUsed.monopoly++;
    let k=R.includes(choice)?choice:(HearthAI.monopolyPick(aiState(x))||'ore'),got=0;
    game.players.forEach(q=>{if(q!==x){got+=q.r[k];q.r[k]=0}});x.r[k]+=got;note(`${x.name} claims every ${NAME[k]} (${got}).`);
  }
  awards();win(x);render();
}
function cancelDev(){game.pick=null;render()}
function pickBank(k){if(!game.pick||game.pick.card!=='plenty'||game.pick.chosen.length>=2)return;let used=empty();game.pick.chosen.forEach(q=>used[q]++);if(game.bank[k]-used[k]<1)return say('The bank has no more of that card.');game.pick.chosen.push(k);render()}
function unpickDev(){if(game.pick&&game.pick.chosen.length){game.pick.chosen.pop();render()}}
function confirmPlenty(){let x=p();if(!game.pick||game.pick.card!=='plenty'||!x.dev.includes('plenty'))return;if(x.devPlayedTurn===game.turnCount)return say('Only one progress card may be played each turn.');let chosen=game.pick.chosen;if(chosen.length!==2)return say('Choose two cards from the bank.');let need=empty();chosen.forEach(k=>need[k]++);if(R.some(k=>game.bank[k]<need[k]))return say('The bank does not have those cards.');x.dev.splice(x.dev.indexOf('plenty'),1);x.devPlayedTurn=game.turnCount;game.devUsed.plenty++;R.forEach(k=>{x.r[k]+=need[k];game.bank[k]-=need[k]});note(`${x.name} takes ${goodsHtml(need)} from the bank.`);game.pick=null;awards();win(x);render()}
function confirmMonopoly(k){let x=p();if(!game.pick||game.pick.card!=='monopoly'||!x.dev.includes('monopoly')||!R.includes(k))return;if(x.devPlayedTurn===game.turnCount)return say('Only one progress card may be played each turn.');x.dev.splice(x.dev.indexOf('monopoly'),1);x.devPlayedTurn=game.turnCount;game.devUsed.monopoly++;let got=0;game.players.forEach(q=>{if(q!==x){got+=q.r[k];q.r[k]=0}});x.r[k]+=got;note(`${x.name} claims every ${NAME[k]} (${got}).`);game.pick=null;awards();win(x);render()}
function roadLen(x){let best=0,owned=new Set(x.roads);function walk(node,used){let o=owner(node);if(o&&o!==x&&used.size)return used.size;let r=used.size;adj(node).forEach(z=>{if(owned.has(z.id)&&!used.has(z.id)){let u=new Set(used);u.add(z.id);r=Math.max(r,walk(z.a===node?z.b:z.a,u))}});return r}x.roads.forEach(id=>{let z=e(id);best=Math.max(best,walk(z.a,new Set),walk(z.b,new Set))});return best}
function awards(){
  if(!game.players.length)return;
  let roads=game.players.map(x=>({id:x.id,length:roadLen(x)})),top=Math.max(...roads.map(x=>x.length)),leaders=roads.filter(x=>x.length===top);
  if(top<5)game.longest=null;
  else if(leaders.some(x=>x.id===game.longest)){} // The incumbent keeps the award on a tie.
  else if(leaders.length===1)game.longest=leaders[0].id;
  else game.longest=null;
  let armies=game.players.map(x=>({id:x.id,knights:x.knights})),maxArmy=Math.max(...armies.map(x=>x.knights)),armyLeaders=armies.filter(x=>x.knights===maxArmy);
  if(maxArmy<3)game.largest=null;
  else if(armyLeaders.some(x=>x.id===game.largest)){} // The incumbent keeps the award on a tie.
  else if(armyLeaders.length===1)game.largest=armyLeaders[0].id;
  else game.largest=null;
}
function hiddenVp(x){return (x.secretVp||[]).length+x.newDev.filter(card=>card==='victory').length}
function win(x){awards();if(x.bot&&score(x)<10&&score(x)+hiddenVp(x)>=10){let revealed=x.newDev.filter(card=>card==='victory').length+x.secretVp.length;x.newDev=x.newDev.filter(card=>card!=='victory');x.secretVp=[];x.vp+=revealed;note(`${x.name} reveals ${revealed} victory point${revealed>1?'s':''}.`)}if(score(x)>=10){game.winner=x.id;game.phase='done';note(`${x.name} wins the island!`)}}
/* ---------- v8 strategic bots: the brain lives in ai.js (HearthAI); this layer adapts and executes ---------- */
function trackPlayers(){return game.players.map(q=>({id:q.id,hand:q.r}))}
function trackSync(){if(!game.ai)game.ai={snap:{},est:{}};HearthAI.Track.sync(game.ai,trackPlayers())}
function trackSteal(thief,victim,res){HearthAI.Track.steal(game.ai,trackPlayers(),thief.id,victim.id,res)}
function devPoolFor(x){
  const mine={};[...x.dev,...x.newDev,...(x.secretVp||[])].forEach(c=>{mine[c]=(mine[c]||0)+1});
  const used=game.devUsed||{road:0,plenty:0,monopoly:0};
  return HearthAI.devPool({knightsPlayed:game.players.reduce((t,q)=>t+q.knights,0),roadPlayed:used.road,plentyPlayed:used.plenty,monopolyPlayed:used.monopoly,victoryShown:game.players.reduce((t,q)=>t+q.vp,0),mine});
}
function seatIndex(id){return id==null?null:game.players.findIndex(q=>q.id===id)}
// What a bot is allowed to know: its own hand, public board state, card counts, and its card-tracking
// estimate of every opponent hand (built only from public events plus its own thefts).
function aiState(x){
  trackSync();
  const est=HearthAI.Track.view(game.ai,x.id),flags=x.aiTurn&&x.aiTurn.turn===game.turnCount?x.aiTurn:{};
  return {board:game.board,bank:{...game.bank},meIndex:game.players.indexOf(x),longest:seatIndex(game.longest),largest:seatIndex(game.largest),phase:game.phase,freeRoads:game.freeRoads||0,deckCount:game.deck.length,devPlayed:x.devPlayedTurn===game.turnCount,setupOrder:game.setup,setupStep:game.step,setupNode:game.setupNode,flags,devPool:devPoolFor(x),
    players:game.players.map(q=>({id:q.id,bot:q.bot,style:q.style,r:q===x?{...q.r}:{...empty(),...(est[q.id]||{})},cards:sum(q.r),roads:[...q.roads],settlements:[...q.settlements],cities:[...q.cities],ports:[...q.ports],knights:q.knights,vp:score(q),devHidden:q===x?0:devCount(q),dev:q===x?[...q.dev]:[],newDev:q===x?[...q.newDev]:[],hiddenVp:q===x?hiddenVp(q):0}))};
}
function botDiscard(x,amount){
  let pick=null;try{pick=HearthAI.discard(aiState(x),amount)}catch(err){pick=null}
  if(!pick||sum(pick)!==amount||R.some(k=>(pick[k]||0)>x.r[k]||(pick[k]||0)<0)){pick=empty();let left=amount;while(left){let k=R.filter(q=>x.r[q]>pick[q]).sort((a,b)=>(x.r[b]-pick[b])-(x.r[a]-pick[a]))[0];pick[k]++;left--}}
  return {...empty(),...pick};
}
function botFlags(x){if(!x.aiTurn||x.aiTurn.turn!==game.turnCount)x.aiTurn={turn:game.turnCount,bankTrades:0,proposals:0,steps:0,humanAsked:false};return x.aiTurn}
function botBank(x,giveK,getK){
  const rate=bankRate(x,giveK);
  if(!R.includes(giveK)||!R.includes(getK)||giveK===getK||x.r[giveK]<rate||game.bank[getK]<1)return false;
  x.r[giveK]-=rate;game.bank[giveK]+=rate;x.r[getK]++;game.bank[getK]--;
  note(`${x.name} trades ${chip(giveK,rate)} for ${chip(getK,1)} at the harbor.`);toast('trade','Harbor trade',[{who:x.name,lose:{[giveK]:rate},gain:{[getK]:1}}]);
  return true;
}
function swapGoods(a,b,give,want){R.forEach(k=>{a.r[k]-=give[k]||0;b.r[k]+=give[k]||0;b.r[k]-=want[k]||0;a.r[k]+=want[k]||0})}
// Returns true when the bot is now waiting on a human's answer.
function botPropose(x,offers,f){
  const me=game.players.indexOf(x);
  for(const o of offers){
    let best=null;
    game.players.forEach(b=>{if(b===x||!b.bot||!canPayMap(b,o.want)||score(b)>=8)return;const s=HearthAI.acceptTrade(aiState(b),o,me);if(s>0&&(!best||s>best.s))best={b,s}});
    if(best&&canPayMap(x,o.give)){
      swapGoods(x,best.b,o.give,o.want);
      note(`${best.b.name} accepts ${x.name}'s trade: ${goodsHtml(o.give)} for ${goodsHtml(o.want)}.`);
      toast('trade','Trade complete',[{who:x.name,lose:o.give,gain:o.want},{who:best.b.name,lose:o.want,gain:o.give}]);
      return false;
    }
  }
  if(f.humanAsked)return false;
  const est=HearthAI.Track.view(game.ai,x.id),humans=game.players.filter(q=>!q.bot&&score(q)<8&&sum(q.r)>0);
  for(const o of offers){
    const k=R.find(r=>o.want[r]);
    if(humans.some(h=>((est[h.id]||{})[k]||0)>=0.75)){
      f.humanAsked=true;game.offer={from:x.id,give:o.give,want:o.want};x.tradeRequestedTurn=game.turnCount;
      note(`${x.name} requests ${goodsHtml(o.want)} for ${goodsHtml(o.give)}.`);render();return true;
    }
  }
  return false;
}
function continueBot(){if(game&&!game.winner&&p().bot&&!game.offer&&!botTimer)botTimer=setTimeout(()=>{botTimer=null;maybeBot()},BOT_DELAY)}
function maybeBot(){
  if(!game||game.winner||!p().bot||game.offer||botTimer)return;
  botTimer=setTimeout(()=>{
    botTimer=null;let x=p();if(!x||!x.bot||game.winner||game.offer)return;
    try{botStep(x)}catch(err){if(typeof console!=='undefined')console.error(err);note(`${x.name} pauses to think.`);if(game.phase==='build'&&!game.winner){game.freeRoads=0;next()}}
  },BOT_DELAY);
}
function botStep(x){
  if(game.phase==='setup'){
    if(!game.setupNode){
      let node=HearthAI.setupSettlement(aiState(x));
      if(!node||!canSet(x,node))node=(game.board.nodes.find(q=>canSet(x,q.id))||{}).id;
      placeSet(node);
    }else{
      let edge=HearthAI.setupRoad(aiState(x));
      if(!edge||!canRoad(x,edge))edge=(game.board.edges.find(q=>canRoad(x,q.id))||{}).id;
      placeRoad(edge);
    }
    return;
  }
  if(game.phase==='discard'){advanceDiscard();if(game.phase==='discard'){render();return}}
  if(game.phase==='roll'){
    const a=HearthAI.decide(aiState(x));
    if(a.type==='play'&&a.card==='knight'&&x.dev.includes('knight')&&x.devPlayedTurn!==game.turnCount){play('knight');continueBot();return}
    roll();return;
  }
  if(game.phase==='robber'){
    const r=HearthAI.robber(aiState(x));
    if(r&&r.tile!==game.board.robber){const v=r.victim==null?null:game.players[r.victim];finishRobber(r.tile,v&&sum(v.r)?v.id:null)}
    else{const t=game.board.tiles.find(q=>q.id!==game.board.robber&&q.terrain==='desert')||game.board.tiles.find(q=>q.id!==game.board.robber);finishRobber(t.id,null)}
    return;
  }
  if(game.phase!=='build')return;
  const f=botFlags(x);
  if(++f.steps>45){game.freeRoads=0;next();return}
  const a=HearthAI.decide(aiState(x));
  x.lastPlan=a.why||a.type;
  switch(a.type){
    case 'road':placeRoad(a.edge);break;
    case 'settlement':placeSet(a.node);break;
    case 'city':city(a.node);break;
    case 'buyDev':buy();break;
    case 'play':play(a.card,a.pick);break;
    case 'bank':if(botBank(x,a.give,a.get))f.bankTrades++;else f.bankTrades=99;break;
    case 'propose':f.proposals++;if(botPropose(x,a.offers,f))return;break;
    case 'skipFree':game.freeRoads=0;break;
    default:next();return;
  }
  if(!game.winner)continueBot();
}

function shape(t){let a=[];for(let i=0;i<6;i++){let z=(60*i-30)*Math.PI/180;a.push(`${t.center.x+Math.cos(z)},${t.center.y+Math.sin(z)}`)}return a.join(' ')}
function bounds(){let xs=game.board.nodes.map(x=>x.x),ys=game.board.nodes.map(x=>x.y);return `${Math.min(...xs)-1.1} ${Math.min(...ys)-1.1} ${Math.max(...xs)-Math.min(...xs)+2.2} ${Math.max(...ys)-Math.min(...ys)+2.2}`}

function terrainArt(type,x,y){
  const common=`stroke="#39291d" stroke-width=".035" stroke-linejoin="round"`;
  const art={
    wood:`<g transform="translate(${x} ${y-.24}) scale(.78)" ${common}><path d="M-.34 .22 Q-.22 .08 -.1 .22 Q.03 .04 .16 .2 Q.29 .08 .38 .22" fill="#31583b"/><path d="M-.27 .08l.13-.28 .13.28z M-.04 .04l.16-.36 .16.36z M.17 .1l.12-.25 .12.25z" fill="#527b48"/><path d="M-.14 .1v.2 M.12 .02v.28 M.31 .12v.18" stroke="#76502f" stroke-width=".055" fill="none"/><circle cx="-.22" cy="-.04" r=".035" fill="#b7c77a" stroke="none"/><circle cx=".18" cy="-.19" r=".03" fill="#c3cf87" stroke="none"/></g>`,
    brick:`<g transform="translate(${x} ${y-.24}) scale(.78)" ${common}><path d="M-.34 .2l.1-.15h.25l.1.15v.13h-.45z" fill="#b65b3c"/><path d="M-.2 .03l.1-.15h.25l.1.15v.13h-.45z" fill="#d17a4c"/><path d="M-.12-.13l.1-.14h.25l.1.14v.13h-.45z" fill="#a94732"/><path d="M-.28 .2h.34 M-.12 .03h.34 M.04-.13h.34" stroke="#f0b17a" stroke-width=".025"/></g>`,
    wool:`<g transform="translate(${x} ${y-.24}) scale(.78)" ${common}><path d="M-.4 .22Q-.34-.03-.13 .02Q-.03-.2 .12-.03Q.34-.08 .39 .22Z" fill="#66804a"/><path d="M-.24 .1q-.1-.18 .04-.23q.12-.05 .17 .08q.16-.1 .23 .05q.11 .16-.07 .23h-.3q-.17 0-.17-.13z" fill="#f1e8c9"/><circle cx="-.05" cy="-.08" r=".025" fill="#49372b" stroke="none"/><path d="M-.23 .19l-.02 .1 M.1 .18l.02 .11" fill="none" stroke="#49372b" stroke-width=".025"/></g>`,
    grain:`<g transform="translate(${x} ${y-.24}) scale(.78)" ${common}><path d="M0 .3V-.2 M-.16 .25l.04-.32 M.16 .25l-.04-.32" fill="none" stroke="#80602b" stroke-width=".045"/><path d="M0-.16q-.19-.03-.16-.17q.16-.03 .16 .17 M0-.05q.19-.03 .16-.17q-.16-.03-.16 .17 M-.12-.03q-.17-.04-.15-.17q.14-.02 .15 .17 M.12 .03q.17-.04 .15-.17q-.14-.02-.15 .17" fill="#e7bd52" stroke="#9a722f" stroke-width=".025"/><path d="M-.34 .22Q0 .08 .34 .22" fill="none" stroke="#67804a" stroke-width=".04"/></g>`,
    ore:`<g transform="translate(${x} ${y-.24}) scale(.78)" ${common}><path d="M-.38 .22l.13-.29 .12 .1 .15-.25 .15 .19 .13-.1 .12 .35z" fill="#777b79"/><path d="M-.25-.04l.12 .07 .15-.25 .1 .18-.12 .16-.12-.04z" fill="#b7b9ad"/><path d="M-.02 .03l.14-.18 .11 .13-.12 .14z" fill="#d4c8a1"/><path d="M-.36 .22h.76" stroke="#3e4745" stroke-width=".04"/></g>`,
    desert:`<g transform="translate(${x} ${y-.24}) scale(.78)" ${common}><path d="M-.4 .2Q-.18-.02 .03 .16Q.22-.04 .4 .2" fill="#e2bd79" stroke="none"/><path d="M-.12 .2V-.14q0-.12 .09-.12q.09 0 .09 .12v.34 M.06 .01q.17 0 .17-.13 M-.1 .04q-.16 0-.16-.12" fill="none" stroke="#47704a" stroke-width=".075" stroke-linecap="round"/><path d="M-.3 .25h.6" stroke="#b88e51" stroke-width=".025"/></g>`
  };
  return `<g pointer-events="none">${art[type]||''}</g>`;
}

function humanMayAct(){return game&&!game.winner&&!game.rolling&&p()&&!p().bot}
function clickNode(id){if(!humanMayAct())return;if(tool==='city')city(id);else if(tool==='settlement'||(game.phase==='setup'&&!game.setupNode))placeSet(id)}
function clickRoad(id){if(!humanMayAct())return;if(tool==='road'||game.phase==='setup')placeRoad(id)}
function clickTile(id){if(!humanMayAct())return;if(tool==='robber')robber(id)}
function stores(x){return `<div class="resource-grid">${R.map(k=>rcard(k,{n:x.r[k],cls:'mini'})).join('')}</div>`}
function dice(){return game.dice?`<span class="dice"><i class="die d${game.dice[0]}">${game.dice[0]}</i><i class="die d${game.dice[1]}">${game.dice[1]}</i></span>`:''}
function controls(){let x=p();if(game.phase==='discard'&&!game.winner)return discardPanel();if(game.winner)return `<section><h2>A new legend</h2><p><b>${game.players.find(x=>x.id===game.winner).name}</b> reaches ten renown.</p><button onclick="game=null;render()">New table</button></section>`;if(game.offer){let seller=game.players.find(q=>q.id===game.offer.from),people=game.players.filter(q=>!q.bot&&canPayMap(q,game.offer.want));return `<section><h2>Trade offer</h2><div class="status"><strong>${seller.name}</strong>offers ${goodsHtml(game.offer.give)} for ${goodsHtml(game.offer.want)}.</div><div class="actions">${people.map(q=>`<button onclick="acceptOffer(${q.id})">Accept as ${q.name}</button>`).join('')}<button class="wide" onclick="declineOffer()">Decline</button></div></section>`}if(tool==='robber-victim'){let tile=game.board.tiles.find(q=>q.id===game.robberTile),victims=game.players.filter(q=>q!==x&&sum(q.r)&&tile.nodes.some(id=>q.settlements.includes(id)||q.cities.includes(id)));return `<section><h2>Choose a victim</h2><div class="status"><strong>Guard on ${tile.terrain}</strong>Choose a settlement owner adjacent to this tile. The stolen resource is selected at random.</div><div class="actions">${victims.map(q=>`<button onclick="finishRobber('${tile.id}',${q.id})">Rob ${q.name}</button>`).join('')}<button class="wide" onclick="finishRobber('${tile.id}',null)">Rob nobody</button></div></section>`}let text=game.phase==='setup'?'Gold markers show your legal settlement and road locations.':game.phase==='roll'?'Roll the two dice to begin your turn.':game.phase==='robber'?'Gold hexes are valid guard destinations.':`${x.name} may trade, build, or end the turn.`;let buttons='';if(!x.bot&&game.phase==='roll')buttons='<button class="wide" onclick="roll()">Roll dice</button>';if(!x.bot&&game.phase==='build')buttons=`<button onclick="tool='settlement';render()">Build house</button><button onclick="tool='road';render()">Build road</button><button onclick="tool='city';render()">Build city</button><button onclick="buy()">Progress card</button><button onclick="beginTrade('bank')">Bank trade</button><button onclick="beginTrade('offer')">Player trade</button><button class="wide" onclick="next()">Pass turn</button>`;let extra=(tool==='bank'||tool==='offer')?'':tool==='city'?'<div class="panel-form">Gold outlined houses are yours. Click one to raise a city.</div>':'';return `<section><h2>Turn</h2><div class="status"><strong>${x.name}${x.bot?' is considering their options...':''}</strong>${text}<br>${dice()}</div><div class="actions">${buttons}</div>${extra}</section>`}
function cardFace(card, playable){let title={knight:'Knight',road:'Road Craft',plenty:'Year of Plenty',monopoly:'Monopoly'}[card]||card,mark={knight:'♞',road:'╋',plenty:'✦',monopoly:'♜'}[card]||'◆';return `<button class="card card-${card}" ${playable?`onclick="play('${card}')"`:'disabled'}><b>${mark}</b><span>${title}</span></button>`}
function resourceCard(resource,count,viewer){if(game.phase==='discard'&&discarder()===viewer&&!viewer.bot){let sel=(game.discardPick&&game.discardPick[resource])||0,need=Math.floor(sum(viewer.r)/2),full=sum(game.discardPick||empty())>=need;return `<div class="discard-cell">${rcard(resource,{n:count,cls:'dock'+(sel?' sel':''),tag:sel?`Give ${sel}`:'In hand'})}<div class="discard-step"><button type="button" onclick="adjustDiscard('${resource}',-1)" ${sel<=0?'disabled':''} aria-label="Discard fewer ${NAME[resource]}">−</button><b>${sel}</b><button type="button" onclick="adjustDiscard('${resource}',1)" ${sel>=count||full?'disabled':''} aria-label="Discard more ${NAME[resource]}">+</button></div></div>`}return rcard(resource,{n:count,cls:'dock'})}
function progressCards(viewer,playable){let html='';viewer.dev.forEach(card=>{html+=dcard(card,{cls:'dock',on:playable?`play('${card}')`:'',dis:!playable,tag:playable?'Play':''})});viewer.newDev.forEach(card=>{html+=card==='victory'?dcard(card,{cls:'dock dev-secret',on:playable?'revealVp()':'',tag:'Secret'}):dcard(card,{cls:'dock held',tag:'Next turn'})});(viewer.secretVp||[]).forEach(()=>{html+=dcard('victory',{cls:'dock dev-secret',on:playable?'revealVp()':'',tag:'Show'})});for(let i=0;i<viewer.vp;i++)html+=dcard('victory',{cls:'dock',tag:'Shown'});return html||'<span class="empty-hand">No progress cards</span>'}
function buildDock(x){let house=paid(x,{wood:1,brick:1,wool:1,grain:1}),city=paid(x,{grain:2,ore:3})&&x.settlements.length,dev=paid(x,{wool:1,grain:1,ore:1})&&game.deck.length;let items=[{id:'house',name:'House',icon:'house',tag:'1 of each',ok:house,action:"tool=tool==='settlement'?null:'settlement';render()",on:tool==='settlement'},{id:'city',name:'City',icon:'city',tag:x.settlements.length?'2 grain, 3 ore':'Need a house',ok:city,action:"tool=tool==='city'?null:'city';render()",on:tool==='city'},{id:'dev',name:'Progress',icon:'dev',tag:game.deck.length?'Wool, grain, ore':'Deck empty',ok:dev,action:'buy()',on:false}];return items.map(item=>`<button type="button" class="rcard build build-${item.id} ${item.on?'sel':''} ${item.ok?'ready':''}" ${item.ok?'':'disabled'} onclick="${item.action}"><span class="rc-art">${buildIcon(item.icon)}</span><span class="rc-name">${item.name}</span><small class="rc-tag">${item.tag}</small></button>`).join('')}
function devCount(q){return q.dev.length+q.newDev.length+(q.secretVp||[]).length}
function dock(viewer,show){if(!show)return '';let mine=viewer===p()&&!viewer.bot,playable=mine&&(game.phase==='build'||game.phase==='roll')&&viewer.devPlayedTurn!==game.turnCount,building=mine&&game.phase==='build';return `<footer class="card-dock" data-owner="${viewer.id}"><div><h3>Your resource cards</h3><div class="hand-row">${R.map(k=>resourceCard(k,viewer.r[k],viewer)).join('')}</div></div><div><h3>Progress cards</h3><div class="hand-row">${progressCards(viewer,playable)}</div></div>${building?`<div><h3>Build</h3><div class="hand-row">${buildDock(viewer)}</div></div>`:''}</footer>`}
function render(){if(!game){app.innerHTML=`<section class="welcome"><div class="crest"></div><h1>Harbor & Hearth</h1><p class="subtitle">Enter a name only for a human seat. Every blank seat becomes a Hearthkeeper bot with its own strategy. Turn order is drawn at random.</p><div class="entry"><label>Seat one<input data-name placeholder="Human name (optional)"></label><label>Seat two<input data-name placeholder="Human name (optional)"></label><label>Seat three<input data-name placeholder="Human name (optional)"></label><label>Seat four<input data-name placeholder="Human name (optional)"></label><button onclick="start()">Begin table</button></div><p class="tiny">Runs directly in Chrome. No install or account required.</p>${message?`<p class="alert">${message}</p>`:''}</section>`;return}let active=p(),humans=game.players.filter(q=>!q.bot),discarding=game.phase==='discard'?discarder():null,viewer=discarding&&!discarding.bot?discarding:(humans.length===1?humans[0]:active),canPlay=viewer===active&&!active.bot,showHand=canPlay||discarding===viewer;app.innerHTML=`<div class="game"><header class="topbar"><h1>Harbor & Hearth</h1><span>Offline table</span><span>First to 10 renown</span></header><div class="board-wrap">${board()}${game.dice?`<div class="board-dice ${game.rolling?'rolling':''}">${dice()}</div>`:''}</div><aside class="side">${controls()}<section><h2>${humans.length===1?'Your':'Active player\'s'} stores</h2>${stores(viewer)}${viewer.ports.length?`<p class="tiny">Your harbors: ${viewer.ports.map(k=>k==='any'?'Any 3:1':`${NAME[k]} 2:1`).join(', ')}</p>`:''}</section><section><h2>Houses & halls</h2><div class="players">${game.players.map((q,i)=>`<div class="player ${i===game.turn?'current':''}" data-seat="${q.id}"><i style="--color:${q.color}"></i><span>${q.name}${q.bot?` <em class="style-tag" title="${(HearthAI.STYLES[q.style]||{}).blurb||'Bot'}">${q.styleLabel||'Bot'}</em>`:''}</span><span class="seat-meta"><span class="hand-count">${sum(q.r)} goods</span><span class="dev-count" title="Progress cards in hand">${devCount(q)} dev</span></span><span class="points">${score(q)} renown</span></div>`).join('')}</div></section><section><h2>Chronicle</h2><ul class="log">${game.log.map(q=>`<li>${q}</li>`).join('')}</ul></section>${message?`<p class="alert">${message}</p>`:''}</aside>${dock(viewer,showHand)}${tradeModal()}${devModal()}</div>`;launchFx()}
function launchFx(){if(!game||!game.fx)return;const fx=game.fx;game.fx=null;requestAnimationFrame(()=>requestAnimationFrame(()=>spawnHarvestFx(fx)))}
function spawnHarvestFx(fx){
  const svg=document.querySelector('svg.board');
  if(!svg||!fx||!fx.grants||!fx.grants.length)return;
  const box=svg.getBoundingClientRect(),vb=svg.viewBox.baseVal;
  const toScreen=(x,y)=>{const [ix,iy]=iso(x,y);return {x:box.left+(ix-vb.x)/vb.width*box.width,y:box.top+(iy-vb.y)/vb.height*box.height}};
  let i=0;
  fx.grants.forEach(g=>{
    for(let c=0;c<g.amount;c++){
      const start=toScreen(g.x,g.y+(c-(g.amount-1)/2)*.12);
      const delay=i++*80;
      const el=document.createElement('div');
      el.className='fly-card '+g.resource;
      el.innerHTML=resIcon(g.resource);
      const dockCard=document.querySelector(`.card-dock[data-owner="${g.playerId}"] .rcard.${g.resource}`);
      const seat=document.querySelector(`.player[data-seat="${g.playerId}"]`);
      const target=dockCard||seat;
      const tb=target?target.getBoundingClientRect():{left:start.x,top:start.y+40,width:0,height:0};
      el.style.left=(start.x-18)+'px';
      el.style.top=(start.y-24)+'px';
      el.style.setProperty('--dx',(tb.left+tb.width/2-start.x)+'px');
      el.style.setProperty('--dy',(tb.top+tb.height/2-start.y)+'px');
      el.style.animationDelay=delay+'ms';
      document.body.appendChild(el);
      setTimeout(()=>el.remove(),1500+delay);
    }
  });
}
function say(x){message=x;render();setTimeout(()=>{if(message===x){message='';render()}},3500)}render();
