# Harbor & Hearth

An original, self-hosted browser game inspired by classic island-settlement games. It contains the base-game rules: setup placement, production, the robber, building, development cards, domestic and maritime trade, ports, largest army, longest road, and ten-point victory.

## Play Offline on a Chromebook

1. Extract the zip file in ChromeOS Files.
2. Open `Play-Harbor-and-Hearth.html` from the extracted folder in Chrome.
3. Add human names for pass-and-play or leave the Hearthkeeper names for bots.

No Linux environment, Node.js, browser extension, account, or internet connection is needed for offline play.

## Optional Hosted Multiplayer

1. Install the Linux development environment and Node.js 18+ on the Chromebook.
2. Extract this folder, open the Linux Terminal in the extracted directory, and run `npm start`.
3. Open `http://localhost:8080` in Chrome. Use **Create table** for a bot game or invite people to the lobby.
4. For people on the same Wi-Fi, share the host Chromebook's local network address shown in the terminal, followed by `:8080`. The lobby code is shared inside the game.

For internet play beyond the same Wi-Fi, run this exact folder on any Node-capable host and share that host's URL. A zip file by itself cannot provide an internet lobby service after it is downloaded; the included server is what keeps the shared table synchronized.

## Make a zip

Run `npm run bundle`. This creates `Harbor-and-Hearth.zip` beside the project files, ready to attach to Gmail.

## Notes

The game is original software and does not include artwork, branding, or content from any commercial board game. A game supports 2-4 total seats; fill unused seats with Hearthkeeper bots from the lobby.
