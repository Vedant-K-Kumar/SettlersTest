const app = document.querySelector('#app');
const R = ['wood', 'brick', 'wool', 'grain', 'ore'];
const NAME = { wood:'Wood', brick:'Brick', wool:'Wool', grain:'Grain', ore:'Ore' };
const COLORS = ['#b73d2e', '#236f93', '#d69b27', '#5a7f43'];
const TERRAINS = ['wood','wood','wood','wood','grain','grain','grain','grain','wool','wool','wool','wool','brick','brick','brick','ore','ore','ore','desert'];
const NUMBERS = [2,3,3,4,4,5,5,6,6,8,8,9,9,10,10,11,11,12];
let game = null, tool = null, message = '', botTimer = null, audio = null, tradeSelection = { give: {wood:0,brick:0,wool:0,grain:0,ore:0}, want: {wood:0,brick:0,wool:0,grain:0,ore:0} };
const BOT_DELAY = 1250;
const empty = () => ({wood:0,brick:0,wool:0,grain:0,ore:0});
const sum = x => R.reduce((n,k)=>n+(x[k]||0),0);
const goods = x => R.filter(k=>x[k]).map(k=>`${x[k]} ${NAME[k]}`).join(', ') || 'nothing';
const shuffle = x => [...x].sort(()=>Math.random()-.5);
const key = (x,y) => `${Math.round(x*100)/100},${Math.round(y*100)/100}`;
const edgeKey = (a,b) => [a,b].sort().join('|');
const px = (q,r) => ({x:Math.sqrt(3)*(q+r/2),y:1.5*r});
function prepareSound(){try{audio=new (window.AudioContext||window.webkitAudioContext)();audio.resume()}catch{audio=null}}
function sound(kind){if(!audio)return;let now=audio.currentTime,notes=kind==='road'?[160,205]:kind==='settlement'?[392,523,659]:[130,165,210,260];notes.forEach((frequency,index)=>{let oscillator=audio.createOscillator(),gain=audio.createGain();oscillator.type=kind==='dice'?'square':'triangle';oscillator.frequency.setValueAtTime(frequency,now+index*.06);gain.gain.setValueAtTime(.0001,now+index*.06);gain.gain.exponentialRampToValueAtTime(kind==='dice'?.035:.06,now+index*.06+.01);gain.gain.exponentialRampToValueAtTime(.0001,now+index*.06+.11);oscillator.connect(gain).connect(audio.destination);oscillator.start(now+index*.06);oscillator.stop(now+index*.06+.13)})}
function createBoard(){
  const coords=[]; for(let q=-2;q<=2;q++)for(let r=-2;r<=2;r++)if(Math.abs(q+r)<=2)coords.push({q,r});
  let tiles;
  do { let nums=shuffle(NUMBERS), ni=0, ts=shuffle(TERRAINS); tiles=coords.map((c,i)=>({...c,id:String(i),terrain:ts[i],number:ts[i]==='desert'?null:nums[ni++],center:px(c.q,c.r)})); }
  while(tiles.some(t=>(t.number===6||t.number===8)&&tiles.some(o=>o!==t&&(o.number===6||o.number===8)&&Math.abs(t.q-o.q)+Math.abs(t.r-o.r)+Math.abs(t.q+t.r-o.q-o.r)===2)));
  const nodes=new Map(), edges=new Map();
  tiles.forEach(t=>{t.nodes=[];for(let i=0;i<6;i++){let a=(60*i-30)*Math.PI/180,p={x:t.center.x+Math.cos(a),y:t.center.y+Math.sin(a)},k=key(p.x,p.y);if(!nodes.has(k))nodes.set(k,{id:`n${nodes.size}`,x:p.x,y:p.y,tiles:[]});let n=nodes.get(k);n.tiles.push(t.id);t.nodes.push(n.id)}for(let i=0;i<6;i++){let a=t.nodes[i],b=t.nodes[(i+1)%6],k=edgeKey(a,b);if(!edges.has(k))edges.set(k,{id:`e${edges.size}`,a,b,tiles:[]});edges.get(k).tiles.push(t.id)}});
  const edgeList=[...edges.values()], coast=edgeList.filter(e=>e.tiles.length===1), types=shuffle(['any','any','any','any','wood','brick','wool','grain','ore']);
  return {tiles,nodes:[...nodes.values()],edges:edgeList,ports:coast.filter((_,i)=>i%2===0).slice(0,9).map((e,i)=>({edge:e.id,type:types[i]}),),robber:tiles.find(t=>t.terrain==='desert').id};
}
function start(){
  prepareSound();
  const names=[...document.querySelectorAll('[data-name]')].map((input,index)=>input.value.trim()||`Hearthkeeper ${index+1}`);
  const players=names.slice(0,4).map((name,i)=>({id:i,name,bot:name.startsWith('Hearthkeeper'),color:COLORS[i],r:empty(),roads:[],settlements:[],cities:[],ports:[],dev:[],newDev:[],knights:0,vp:0}));
  game={board:createBoard(),players,turn:0,phase:'setup',setup:[...players.keys(),...players.keys()].map((x,i)=>i<players.length?x:players.length*2-1-i),step:0,setupNode:null,bank:{wood:19,brick:19,wool:19,grain:19,ore:19},deck:shuffle(['knight','knight','knight','knight','knight','knight','knight','knight','knight','knight','knight','knight','knight','knight','road','road','plenty','plenty','monopoly','monopoly','victory','victory','victory','victory','victory']),log:['The first settlement awaits.'],longest:null,largest:null,freeRoads:0,winner:null,offer:null};
  maybeBot(); render();
}
function p(){return game.players[game.turn]}; function n(id){return game.board.nodes.find(x=>x.id===id)}; function e(id){return game.board.edges.find(x=>x.id===id)};
function owner(node){return game.players.find(x=>x.settlements.includes(node)||x.cities.includes(node))};
function adj(node){return game.board.edges.filter(x=>x.a===node||x.b===node)}; function near(node){return adj(node).map(x=>x.a===node?x.b:x.a)};
function note(x){game.log.unshift(x);game.log=game.log.slice(0,24)}; function paid(x,c){return R.every(k=>x.r[k]>=(c[k]||0))}; function take(x,c){R.forEach(k=>x.r[k]-=c[k]||0)}; function give(x,c){R.forEach(k=>x.r[k]+=c[k]||0)};
function freeNode(id){return !owner(id)&&near(id).every(x=>!owner(x))}; function canSet(x,id){return freeNode(id)&&(game.phase==='setup'||adj(id).some(z=>x.roads.includes(z.id)))};
function canRoad(x,id){let z=e(id);if(!z||game.players.some(q=>q.roads.includes(id)))return false;if(game.phase==='setup')return game.setupNode&&(z.a===game.setupNode||z.b===game.setupNode);return [z.a,z.b].some(a=>{let o=owner(a);return (!o||o===x)&&(x.settlements.includes(a)||x.cities.includes(a)||adj(a).some(q=>x.roads.includes(q.id)))});}
function score(x){return x.settlements.length+x.cities.length*2+x.vp+(game.longest===x.id?2:0)+(game.largest===x.id?2:0)};
function ports(x,id){game.board.ports.forEach(q=>{let z=e(q.edge);if((z.a===id||z.b===id)&&!x.ports.includes(q.type))x.ports.push(q.type)})}
function placeSet(id){let x=p();if(!canSet(x,id))return say('Settlements require an empty junction, clear of neighboring settlements, and connected to your road after setup.');let c={wood:1,brick:1,wool:1,grain:1};if(game.phase!=='setup'){if(!paid(x,c))return say('A settlement costs 1 Wood, 1 Brick, 1 Wool, and 1 Grain.');take(x,c);give({r:game.bank},c)}x.settlements.push(id);ports(x,id);game.setupNode=id;if(game.phase==='setup'&&x.settlements.length===2){n(id).tiles.forEach(tid=>{let t=game.board.tiles.find(q=>q.id===tid);if(t.terrain!=='desert'&&game.bank[t.terrain]){x.r[t.terrain]++;game.bank[t.terrain]--}})}sound('settlement');note(`${x.name} raises a settlement.`);tool=null;render();if(game.phase==='setup'&&x.bot)maybeBot()}
function placeRoad(id){let x=p();if(!canRoad(x,id))return say('Roads must join your network and may not pass through another settlement.');let c={wood:1,brick:1};if(!game.freeRoads&&game.phase!=='setup'){if(!paid(x,c))return say('A road costs 1 Wood and 1 Brick.');take(x,c);give({r:game.bank},c)}x.roads.push(id);if(game.freeRoads)game.freeRoads--;sound('road');note(`${x.name} lays a road.`);tool=null;let wasSetup=game.phase==='setup';if(wasSetup){game.step++;if(game.step===game.setup.length){game.phase='roll';game.turn=0;note(`${p().name} begins the first harvest.`)}else{game.turn=game.setup[game.step];game.setupNode=null;note(`${p().name} places a settlement.`)}}render();if(wasSetup&&p().bot)maybeBot()}
function city(id){let x=p(),c={grain:2,ore:3};if(!x.settlements.includes(id)||!paid(x,c))return say('A city upgrades your settlement for 2 grain and 3 ore.');take(x,c);give({r:game.bank},c);x.settlements=x.settlements.filter(q=>q!==id);x.cities.push(id);note(`${x.name} builds a city.`);win(x);tool=null;render()}
function roll(){if(game.phase!=='roll'||game.rolling)return;let one=1+Math.floor(Math.random()*6),two=1+Math.floor(Math.random()*6),v=one+two;game.rolling=true;game.dice=[one,two];sound('dice');render();setTimeout(()=>{game.last=v;game.rolling=false;note(`${p().name} rolls ${v}.`);if(v===7){game.players.forEach(x=>{let before=sum(x.r),amount=before>7?Math.floor(before/2):0;while(amount){let choices=R.filter(k=>x.r[k]);let k=choices[Math.floor(Math.random()*choices.length)];x.r[k]--;game.bank[k]++;amount--}if(before>7)note(`${x.name} discards half their stores.`)});game.phase='robber';tool='robber'}else{game.board.tiles.filter(t=>t.number===v&&t.id!==game.board.robber).forEach(t=>game.players.forEach(x=>t.nodes.forEach(id=>{let amount=x.settlements.includes(id)?1:x.cities.includes(id)?2:0;if(amount&&game.bank[t.terrain]>=amount){x.r[t.terrain]+=amount;game.bank[t.terrain]-=amount}})));game.phase='build'}render();maybeBot()},720)}
function finishRobber(tileId,victimId){let actor=p(),victim=game.players.find(x=>x.id===victimId);game.board.robber=tileId;if(victim){let choices=R.filter(k=>victim.r[k]),taken=choices[Math.floor(Math.random()*choices.length)];victim.r[taken]--;actor.r[taken]++;note(`${actor.name} robs ${victim.name}, taking 1 ${NAME[taken]}.`)}else note(`${actor.name} moves the guard without a theft.`);game.phase='build';tool=null;game.robberTile=null;render();maybeBot()}
function robber(id){if(game.phase!=='robber'||id===game.board.robber)return;let t=game.board.tiles.find(x=>x.id===id),victims=game.players.filter(x=>x!==p()&&sum(x.r)&&t.nodes.some(a=>x.settlements.includes(a)||x.cities.includes(a)));if(!p().bot&&victims.length){game.robberTile=id;tool='robber-victim';render();return}finishRobber(id,victims.length?victims[Math.floor(Math.random()*victims.length)].id:null)}
function buy(){let x=p(),c={wool:1,grain:1,ore:1};if(!paid(x,c)||!game.deck.length)return say('A progress card costs wool, grain, and ore.');take(x,c);give({r:game.bank},c);let card=game.deck.pop();if(card==='victory'){x.vp++;note(`${x.name} earns hidden renown.`);win(x)}else{x.newDev.push(card);note(`${x.name} draws a progress card.`)}render()}
function beginTrade(kind){tool=kind;tradeSelection={give:empty(),want:empty()};render()}
function chooseTrade(side,resource){if(!['bank','offer'].includes(tool))return;let ceiling=side==='give'?p().r[resource]:4;tradeSelection[side][resource]=tradeSelection[side][resource]>=ceiling?0:tradeSelection[side][resource]+1;render()}
function bank(){let give=R.find(k=>tradeSelection.give[k]),want=R.find(k=>tradeSelection.want[k]),x=p(),gave=sum(tradeSelection.give),wanted=sum(tradeSelection.want);let rate=x.ports.includes(give)?2:x.ports.includes('any')?3:4;if(!give||!want||give===want||gave!==rate||wanted!==1||x.r[give]<rate||!game.bank[want])return say(`Choose exactly ${rate} of one resource to give and 1 different resource to receive.`);x.r[give]-=rate;game.bank[give]+=rate;x.r[want]++;game.bank[want]--;note(`${x.name} trades ${rate} ${NAME[give]} for 1 ${NAME[want]} at the bank.`);tool=null;render()}
function canPayMap(player, map){return R.every(k=>player.r[k]>=(map[k]||0))}
function acceptOffer(playerId){let offer=game.offer,buyer=game.players.find(x=>x.id===playerId),seller=game.players.find(x=>x.id===offer?.from);if(!offer||!buyer||!seller||!canPayMap(buyer,offer.want)||!canPayMap(seller,offer.give))return say('That trade can no longer be completed.');R.forEach(k=>{seller.r[k]-=offer.give[k]||0;buyer.r[k]+=offer.give[k]||0;buyer.r[k]-=offer.want[k]||0;seller.r[k]+=offer.want[k]||0});note(`${buyer.name} accepts ${seller.name}'s trade: ${goods(offer.give)} for ${goods(offer.want)}.`);game.offer=null;render();maybeBot()}
function declineOffer(){if(!game.offer)return;

    let seller=game.players.find(x=>x.id===game.offer.from);

    note(`${seller.name}'s trade offer goes unanswered.`);

    if(seller.bot){
        seller.declinedTrade=true;
    }

    game.offer=null;
    render();
    maybeBot();}
function resourceWorth(bot,resource){let need=botNeed(bot);return resource===need?5:bot.r[resource]===0?4:bot.r[resource]===1?3:bot.r[resource]>=5?1:2}
function offerWorth(bot,map){return R.reduce((value,k)=>value+(map[k]||0)*resourceWorth(bot,k),0)}
function botWillAccept(bot,offer){return canPayMap(bot,offer.want)&&offerWorth(bot,offer.give)>=offerWorth(bot,offer.want)*1.2}
function submitOffer(){let give={...tradeSelection.give},want={...tradeSelection.want},seller=p();if(!sum(give)||!sum(want)||!canPayMap(seller,give))return say('Choose at least one resource on both sides, and only offer cards you hold.');game.offer={from:seller.id,give,want};let bot=game.players.filter(x=>x.bot&&botWillAccept(x,game.offer)).sort((a,b)=>offerWorth(b,give)-offerWorth(a,give))[0];if(bot){tool=null;tradeSelection={give:empty(),want:empty()};acceptOffer(bot.id)}else{note(`${seller.name}'s trade is declined: no bot can afford it or values it enough.`);game.offer=null;tool=null;render()}}
function next(){
    if(game.phase!=='build'||game.freeRoads)
        return say(game.freeRoads?'Place the remaining free roads.':'Roll before ending your turn.');

    p().dev.push(...p().newDev);
    p().newDev=[];

    game.turn=(game.turn+1)%game.players.length;

    p().declinedTrade=false;

    game.phase='roll';
    note(`${p().name}'s turn begins.`);
    render();
    maybeBot();
}function play(card){let x=p();if(!x.dev.includes(card))return; x.dev.splice(x.dev.indexOf(card),1);if(card==='knight'){x.knights++;game.phase='robber';tool='robber';note(`${x.name} sends the guard.`)}if(card==='road'){game.freeRoads=2;note(`${x.name} receives two road deeds.`)}if(card==='plenty'){R.forEach(k=>{if(game.bank[k]&&sum(x.r)<10&&Math.random()>.5){x.r[k]++;game.bank[k]--}});note(`${x.name} draws supplies from the bank.`)}if(card==='monopoly'){let k=R[Math.floor(Math.random()*R.length)],got=0;game.players.forEach(q=>{if(q!==x){got+=q.r[k];q.r[k]=0}});x.r[k]+=got;note(`${x.name} claims all ${NAME[k]}.`)}awards();render()}
function roadLen(x){let best=0, owned=new Set(x.roads);function walk(node,used){let o=owner(node);if(o&&o!==x&&used.size)return used.size;let r=used.size;adj(node).forEach(z=>{if(owned.has(z.id)&&!used.has(z.id)){let u=new Set(used);u.add(z.id);r=Math.max(r,walk(z.a===node?z.b:z.a,u))}});return r}x.roads.forEach(id=>{let z=e(id);best=Math.max(best,walk(z.a,new Set),walk(z.b,new Set))});return best}
function awards(){let roads=game.players.map(x=>({x,v:roadLen(x)}),),top=Math.max(...roads.map(x=>x.v)),lead=roads.filter(x=>x.v===top);if(top>=5&&lead.length===1)game.longest=lead[0].x.id;let guards=Math.max(...game.players.map(x=>x.knights)),army=game.players.filter(x=>x.knights===guards);if(guards>=3&&army.length===1)game.largest=army[0].id}
function win(x){awards();if(score(x)>=10){game.winner=x.id;game.phase='done';note(`${x.name} wins the island!`)}}
function botNeed(x){let settlement={wood:1,brick:1,wool:1,grain:1},city={grain:2,ore:3},target=x.settlements.length&&canPayMap(x,city)?city:canPayMap(x,settlement)?settlement:(x.settlements.length?city:settlement);return R.filter(k=>x.r[k]<(target[k]||0)).sort((a,b)=>x.r[a]-x.r[b])[0]||R.find(k=>x.r[k]===0&&game.bank[k]);}
function probability(number){return ({2:1,3:2,4:3,5:4,6:5,8:5,9:4,10:3,11:2,12:1})[number]||0}
function nodeValue(nodeId,bot){let node=n(nodeId),types=new Set(),value=0;node.tiles.forEach(tileId=>{let tile=game.board.tiles.find(q=>q.id===tileId);if(tile.terrain!=='desert'){value+=probability(tile.number)*3;types.add(tile.terrain);if(bot.r[tile.terrain]===0)value+=1}});return value+types.size*2-node.tiles.filter(tileId=>game.board.tiles.find(q=>q.id===tileId).terrain==='desert').length*2}
function bestOf(items,score){return items.reduce((best,item)=>!best||score(item)>score(best)?item:best,null)}
function maybeBot(){
  if(!game||game.winner||!p().bot||game.offer||botTimer)return;
  botTimer=setTimeout(()=>{
    botTimer=null;
    let x=p();
    if(game.phase==='setup'){
      let nodes=game.board.nodes.filter(q=>canSet(x,q.id));
      if(!game.setupNode&&nodes.length){let best=bestOf(nodes,q=>nodeValue(q.id,x));placeSet(best.id)}
      else { let edges=game.board.edges.filter(q=>canRoad(x,q.id));let best=bestOf(edges,q=>nodeValue(q.a===game.setupNode?q.b:q.a,x));if(best)placeRoad(best.id); }
      return;
    }
    if(game.phase==='roll'){ roll(); return; }
    if(game.phase==='robber'){ let tiles=game.board.tiles.filter(q=>q.id!==game.board.robber); robber(tiles[Math.floor(Math.random()*tiles.length)].id); return; }
    if(game.phase!=='build')return;
    let cityNode=x.settlements.find(id=>paid(x,{grain:2,ore:3}));
    let settlementNode=game.board.nodes.find(q=>paid(x,{wood:1,brick:1,wool:1,grain:1})&&canSet(x,q.id));
    let road=bestOf(game.board.edges.filter(q=>paid(x,{wood:1,brick:1})&&canRoad(x,q.id)),q=>Math.max(nodeValue(q.a,x),nodeValue(q.b,x)));
    let development=paid(x,{wool:1,grain:1,ore:1})&&game.deck.length;
    if(x.dev.includes('knight')&&Math.random()>.72) play('knight');
    else if(cityNode) city(cityNode);
    else if(settlementNode) placeSet(settlementNode.id);
    else if(road) placeRoad(road.id);
    else if(development) buy();
    else {
      let wanted=botNeed(x),extra=R.filter(k=>x.r[k]>=3).sort((a,b)=>x.r[b]-x.r[a])[0];
      if(extra&&wanted&&!x.declinedTrade&&game.players.some(q=>!q.bot&&q.r[wanted])){
        game.offer={from:x.id,give:{...empty(),[extra]:Math.min(2,x.r[extra]-2)},want:{...empty(),[wanted]:1}};
        note(`${x.name} requests ${goods(game.offer.want)} for ${goods(game.offer.give)}.`);
        render();
        return;
      }
      if(extra&&wanted){
        let rate=x.ports.includes(extra)?2:x.ports.includes('any')?3:4;
        if(x.r[extra]>=rate&&game.bank[wanted]){
          x.r[extra]-=rate; game.bank[extra]+=rate; x.r[wanted]++; game.bank[wanted]--;
          note(`${x.name} trades ${rate} ${NAME[extra]} for 1 ${NAME[wanted]} at the harbor.`);
        }
      }
    }
    setTimeout(next,BOT_DELAY);
  },BOT_DELAY);
}
function shape(t){let a=[];for(let i=0;i<6;i++){let z=(60*i-30)*Math.PI/180;a.push(`${t.center.x+Math.cos(z)},${t.center.y+Math.sin(z)}`)}return a.join(' ')}
function bounds(){let xs=game.board.nodes.map(x=>x.x),ys=game.board.nodes.map(x=>x.y);return `${Math.min(...xs)-1.1} ${Math.min(...ys)-1.1} ${Math.max(...xs)-Math.min(...xs)+2.2} ${Math.max(...ys)-Math.min(...ys)+2.2}`}
function board(){let b=game.board,player=p(),ports=b.ports.map(q=>{let z=e(q.edge),a=n(z.a),d=n(z.b),label=q.type==='any'?'Any 3:1':`${NAME[q.type]} 2:1`;return `<g class="harbor"><circle cx="${(a.x+d.x)/2}" cy="${(a.y+d.y)/2}" r=".25"/><text class="anchor" x="${(a.x+d.x)/2}" y="${(a.y+d.y)+.04}">⚓</text><text class="harbor-label" x="${(a.x+d.x)/2}" y="${(a.y+d.y)+.38}">${label}</text></g>`}).join('');let ts=b.tiles.map(t=>`<g onclick="clickTile('${t.id}')"><polygon class="tile ${t.terrain} ${tool==='robber'&&t.id!==b.robber?'target':''}" points="${shape(t)}"/><text class="terrain-mark" x="${t.center.x}" y="${t.center.y-.18}">${({wood:'♣',brick:'◆',wool:'✿',grain:'✦',ore:'▲',desert:'☼'})[t.terrain]}</text>${t.number?`<circle class="token" cx="${t.center.x}" cy="${t.center.y+.17}" r=".28"/><text class="number ${[6,8].includes(t.number)?'hot':''}" x="${t.center.x}" y="${t.center.y+.26}">${t.number}</text>`:''}${b.robber===t.id?`<text class="robber" x="${t.center.x}" y="${t.center.y+.1}">♜</text>`:''}</g>`).join('');let es=b.edges.map(z=>{let a=n(z.a),d=n(z.b),o=game.players.find(x=>x.roads.includes(z.id)),target=!o&&(tool==='road'||game.phase==='setup')&&!player.bot&&canRoad(player,z.id);return `<line class="road ${o?'claimed':target?'target':''}" style="${o?`stroke:${o.color}`:''}" x1="${a.x}" y1="${a.y}" x2="${d.x}" y2="${d.y}" onclick="clickRoad('${z.id}')"/>`}).join('');let ns=b.nodes.map(z=>{let o=owner(z.id),city=o?.cities.includes(z.id),path=city?'M-.18,.16V-.12H-.1V-.28H.1V-.12H.18V.16Z':'M-.16,.16V-.08L0-.24 .16-.08V.16Z';if(o){let target=tool==='city'&&o===player&&!city;return `<path class="piece ${city?'city':'house'} ${target?'target':''}" fill="${o.color}" d="${path}" transform="translate(${z.x} ${z.y})" onclick="clickNode('${z.id}')"/>`}let target=(tool==='settlement'||game.phase==='setup')&&!player.bot&&canSet(player,z.id);return `<circle class="node ${target?'target':''}" cx="${z.x}" cy="${z.y}" r=".09" onclick="clickNode('${z.id}')"/>`}).join('');return `<svg class="board" viewBox="${bounds()}"><defs><pattern id="grain" width=".34" height=".34" patternUnits="userSpaceOnUse"><path d="M.17 0v.34M.1 .08l.07.06 .07-.06M.1 .2l.07.06 .07-.06" stroke="#f8dd75" stroke-width=".025"/></pattern><pattern id="wood" width=".5" height=".5" patternUnits="userSpaceOnUse"><circle cx=".13" cy=".18" r=".1" fill="#77965a"/><circle cx=".33" cy=".31" r=".12" fill="#355d38"/></pattern></defs>${ts}${ports}${es}${ns}</svg>`}
function clickNode(id){if(tool==='city')city(id);else if(tool==='settlement'||game.phase==='setup')placeSet(id)}function clickRoad(id){if(tool==='road'||game.phase==='setup')placeRoad(id)}function clickTile(id){if(tool==='robber')robber(id)}
function stores(x){return `<div class="resource-grid">${R.map(k=>`<div class="resource ${k}"><b>${x.r[k]}</b>${NAME[k]}</div>`).join('')}</div>`}
function dice(){return game.dice?`<span class="dice"><i class="die d${game.dice[0]}">${game.dice[0]}</i><i class="die d${game.dice[1]}">${game.dice[1]}</i></span>`:''}
function controls(){let x=p();if(game.winner)return `<section><h2>A new legend</h2><p><b>${game.players.find(x=>x.id===game.winner).name}</b> reaches ten renown.</p><button onclick="game=null;render()">New table</button></section>`;if(game.offer){let seller=game.players.find(q=>q.id===game.offer.from),people=game.players.filter(q=>!q.bot&&canPayMap(q,game.offer.want));return `<section><h2>Trade offer</h2><div class="status"><strong>${seller.name}</strong>offers <b>${goods(game.offer.give)}</b> for <b>${goods(game.offer.want)}</b>.</div><div class="actions">${people.map(q=>`<button onclick="acceptOffer(${q.id})">Accept as ${q.name}</button>`).join('')}<button class="wide" onclick="declineOffer()">Decline</button></div></section>`}if(tool==='robber-victim'){let tile=game.board.tiles.find(q=>q.id===game.robberTile),victims=game.players.filter(q=>q!==x&&sum(q.r)&&tile.nodes.some(id=>q.settlements.includes(id)||q.cities.includes(id)));return `<section><h2>Choose a victim</h2><div class="status"><strong>Guard on ${tile.terrain}</strong>Choose a settlement owner adjacent to this tile. The stolen resource is selected at random.</div><div class="actions">${victims.map(q=>`<button onclick="finishRobber('${tile.id}',${q.id})">Rob ${q.name}</button>`).join('')}<button class="wide" onclick="finishRobber('${tile.id}',null)">Rob nobody</button></div></section>`}let text=game.phase==='setup'?'Gold markers show your legal settlement and road locations.':game.phase==='roll'?'Roll the two dice to begin your turn.':game.phase==='robber'?'Gold hexes are valid guard destinations.':`${x.name} may trade, build, or end the turn.`;let buttons='';if(!x.bot&&game.phase==='roll')buttons='<button class="wide" onclick="roll()">Roll dice</button>';if(!x.bot&&game.phase==='build')buttons=`<button onclick="tool='settlement';render()">Build house</button><button onclick="tool='road';render()">Build road</button><button onclick="tool='city';render()">Build city</button><button onclick="buy()">Progress card</button><button onclick="beginTrade('bank')">Bank trade</button><button onclick="beginTrade('offer')">Player trade</button><button class="wide" onclick="next()">Pass turn</button>`;let extra=tool==='bank'?`<div class="panel-form"><strong>Bank trade</strong><p>Click your cards and requested bank cards in the dock below. Your active harbor rate is applied automatically.</p><p>Giving: <b>${goods(tradeSelection.give)}</b><br>Receiving: <b>${goods(tradeSelection.want)}</b></p><div class="form-actions"><button onclick="bank()">Confirm bank trade</button><button onclick="tool=null;render()">Cancel</button></div></div>`:tool==='offer'?`<div class="panel-form"><strong>Player trade</strong><p>Click cards from your hand and the request row in the dock below. Bots only accept if they can afford the deal and it helps their plan.</p><p>Giving: <b>${goods(tradeSelection.give)}</b><br>Requesting: <b>${goods(tradeSelection.want)}</b></p><div class="form-actions"><button onclick="submitOffer()">Offer to bots</button><button onclick="tool=null;render()">Cancel</button></div></div>`:tool==='city'?'<div class="panel-form">Gold outlined houses are yours. Click one to raise a city.</div>':'';return `<section><h2>Turn</h2><div class="status"><strong>${x.name}${x.bot?' is considering their options...':''}</strong>${text}<br>${dice()}</div><div class="actions">${buttons}</div>${extra}</section>`}
function cardFace(card, playable){let title={knight:'Knight',road:'Road Craft',plenty:'Year of Plenty',monopoly:'Monopoly'}[card]||card,mark={knight:'♞',road:'╋',plenty:'✦',monopoly:'♜'}[card]||'◆';return `<button class="card card-${card}" ${playable?`onclick="play('${card}')"`:'disabled'}><b>${mark}</b><span>${title}</span></button>`}
function resourceCard(resource,count,side){let selected=tradeSelection[side][resource],active=['bank','offer'].includes(tool),label=side==='give'?'Your card':'Request';return `<button class="hand-card ${resource} ${active&&selected?'selected':''}" ${active?`onclick="chooseTrade('${side}','${resource}')"`:'disabled'}><i></i><b>${count}</b><span>${NAME[resource]}</span>${active?`<small>${label}: ${selected}</small>`:''}</button>`}
function dock(viewer,canPlay){if(!canPlay)return '';return `<footer class="card-dock"><div><h3>Your resource cards</h3><div class="hand-row">${R.map(k=>resourceCard(k,viewer.r[k],'give')).join('')}</div></div>${['bank','offer'].includes(tool)?`<div><h3>${tool==='bank'?'Bank cards':'Resources requested'}</h3><div class="hand-row">${R.map(k=>resourceCard(k,19,'want')).join('')}</div></div>`:''}<div><h3>Progress cards</h3><div class="hand-row">${viewer.dev.map(k=>cardFace(k,true)).join('')||'<span class="empty-hand">No playable cards</span>'}</div></div></footer>`}
function render(){if(!game){app.innerHTML=`<section class="welcome"><div class="crest"></div><h1>Harbor & Hearth</h1><p class="subtitle">Enter a name only for a human seat. Every blank seat becomes a Hearthkeeper bot.</p><div class="entry"><label>Seat one<input data-name placeholder="Human name (optional)"></label><label>Seat two<input data-name placeholder="Human name (optional)"></label><label>Seat three<input data-name placeholder="Human name (optional)"></label><label>Seat four<input data-name placeholder="Human name (optional)"></label><button onclick="start()">Begin table</button></div><p class="tiny">Runs directly in Chrome. No install or account required.</p>${message?`<p class="alert">${message}</p>`:''}</section>`;return}let active=p(),humans=game.players.filter(q=>!q.bot),viewer=humans.length===1?humans[0]:active,canPlay=viewer===active&&!active.bot;app.innerHTML=`<div class="game"><header class="topbar"><h1>Harbor & Hearth</h1><span>Offline table</span><span>First to 10 renown</span></header><div class="board-wrap">${board()}${game.dice?`<div class="board-dice ${game.rolling?'rolling':''}">${dice()}</div>`:''}</div><aside class="side">${controls()}<section><h2>${humans.length===1?'Your':'Active player\'s'} stores</h2>${stores(viewer)}${viewer.ports.length?`<p class="tiny">Your harbors: ${viewer.ports.map(k=>k==='any'?'Any 3:1':`${NAME[k]} 2:1`).join(', ')}</p>`:''}</section><section><h2>Houses & halls</h2><div class="players">${game.players.map((q,i)=>`<div class="player ${i===game.turn?'current':''}"><i style="--color:${q.color}"></i><span>${q.name}${q.bot?' (bot)':''}</span><span class="points">${score(q)} renown</span></div>`).join('')}</div></section><section><h2>Chronicle</h2><ul class="log">${game.log.map(q=>`<li>${q}</li>`).join('')}</ul></section>${message?`<p class="alert">${message}</p>`:''}</aside>${dock(viewer,canPlay)}</div>`}
function say(x){message=x;render();setTimeout(()=>{if(message===x){message='';render()}},3500)}render();
