const http = require('http');
const fs = require('fs');
const path = require('path');
const crypto = require('crypto');

const PORT = Number(process.env.PORT || 8080);
const clients = new Map();
const games = new Map();
const COLORS = ['#a93d2f', '#1f6f91', '#d49a28', '#4f7d42'];
const TERRAIN = ['wood', 'wood', 'wood', 'wood', 'grain', 'grain', 'grain', 'grain', 'wool', 'wool', 'wool', 'wool', 'brick', 'brick', 'brick', 'ore', 'ore', 'ore', 'desert'];
const NUMBERS = [2, 3, 3, 4, 4, 5, 5, 6, 6, 8, 8, 9, 9, 10, 10, 11, 11, 12];
const RESOURCE_NAMES = { wood: 'Wood', brick: 'Brick', wool: 'Wool', grain: 'Grain', ore: 'Ore' };
const RESOURCES = Object.keys(RESOURCE_NAMES);
const DEV = ['knight', 'knight', 'knight', 'knight', 'knight', 'knight', 'knight', 'knight', 'knight', 'knight', 'knight', 'knight', 'knight', 'knight', 'road', 'road', 'plenty', 'plenty', 'monopoly', 'monopoly', 'victory', 'victory', 'victory', 'victory', 'victory'];

function randomId(length = 6) { return crypto.randomBytes(length).toString('base64url').toUpperCase().slice(0, length); }
function shuffle(values) { const output = [...values]; for (let i = output.length - 1; i > 0; i--) { const j = crypto.randomInt(i + 1); [output[i], output[j]] = [output[j], output[i]]; } return output; }
function emptyResources() { return { wood: 0, brick: 0, wool: 0, grain: 0, ore: 0 }; }
function totalResources(resources) { return RESOURCES.reduce((sum, resource) => sum + resources[resource], 0); }
function addResources(target, source, direction = 1) { RESOURCES.forEach((resource) => { target[resource] += (source[resource] || 0) * direction; }); }
function resourceText(resources) { return RESOURCES.filter((resource) => resources[resource]).map((resource) => `${resources[resource]} ${RESOURCE_NAMES[resource]}`).join(', ') || 'nothing'; }
function pointKey(x, y) { return `${Math.round(x * 100) / 100},${Math.round(y * 100) / 100}`; }
function edgeKey(a, b) { return [a, b].sort().join('|'); }
function axialToPixel(q, r) { return { x: Math.sqrt(3) * (q + r / 2), y: 1.5 * r }; }

function buildBoard() {
  const coords = [];
  for (let q = -2; q <= 2; q++) for (let r = -2; r <= 2; r++) if (Math.abs(q + r) <= 2) coords.push({ q, r });
  let terrain, numbers;
  for (;;) {
    terrain = shuffle(TERRAIN); numbers = shuffle(NUMBERS);
    let numberIndex = 0; const candidate = coords.map((coord, index) => ({ ...coord, terrain: terrain[index], number: terrain[index] === 'desert' ? null : numbers[numberIndex++] }));
    const invalid = candidate.some((tile) => (tile.number === 6 || tile.number === 8) && candidate.some((other) => other !== tile && (other.number === 6 || other.number === 8) && Math.abs(tile.q - other.q) + Math.abs(tile.r - other.r) + Math.abs((tile.q + tile.r) - (other.q + other.r)) === 2));
    if (!invalid) { terrain = candidate; break; }
  }
  const nodes = new Map(); const edges = new Map();
  terrain.forEach((tile, index) => {
    const center = axialToPixel(tile.q, tile.r); tile.id = String(index); tile.center = center;
    tile.nodes = [];
    for (let corner = 0; corner < 6; corner++) {
      const radians = Math.PI / 180 * (60 * corner - 30);
      const raw = { x: center.x + Math.cos(radians), y: center.y + Math.sin(radians) };
      const key = pointKey(raw.x, raw.y);
      if (!nodes.has(key)) nodes.set(key, { id: `n${nodes.size}`, x: raw.x, y: raw.y, tiles: [] });
      const node = nodes.get(key); node.tiles.push(tile.id); tile.nodes.push(node.id);
    }
    for (let corner = 0; corner < 6; corner++) {
      const a = tile.nodes[corner]; const b = tile.nodes[(corner + 1) % 6]; const key = edgeKey(a, b);
      if (!edges.has(key)) edges.set(key, { id: `e${edges.size}`, a, b, tiles: [] });
      edges.get(key).tiles.push(tile.id);
    }
  });
  const nodeList = [...nodes.values()]; const edgeList = [...edges.values()];
  const coastal = edgeList.filter((edge) => edge.tiles.length === 1);
  const portTypes = shuffle(['any', 'any', 'any', 'any', 'wood', 'brick', 'wool', 'grain', 'ore']);
  const ports = coastal.filter((_, index) => index % 2 === 0).slice(0, 9).map((edge, index) => ({ id: `p${index}`, edge: edge.id, type: portTypes[index] }));
  return { tiles: terrain, nodes: nodeList, edges: edgeList, ports, robber: terrain.find((tile) => tile.terrain === 'desert').id };
}

function player(id, name, bot = false) { return { id, name: name.slice(0, 18) || 'Settler', bot, color: COLORS[0], resources: emptyResources(), roads: [], settlements: [], cities: [], dev: [], newDev: [], knights: 0, playedDev: false, victoryDev: 0, ports: [] }; }
function log(game, text) { game.log.unshift({ id: randomId(9), text, at: Date.now() }); game.log = game.log.slice(0, 60); }
function findPlayer(game, id) { return game.players.find((entry) => entry.id === id); }
function current(game) { return game.players[game.turn]; }
function nodeById(game, id) { return game.board.nodes.find((node) => node.id === id); }
function edgeById(game, id) { return game.board.edges.find((edge) => edge.id === id); }
function ownerAt(game, nodeId) { return game.players.find((entry) => entry.settlements.includes(nodeId) || entry.cities.includes(nodeId)); }
function adjacentEdges(game, nodeId) { return game.board.edges.filter((edge) => edge.a === nodeId || edge.b === nodeId); }
function neighbors(game, nodeId) { return adjacentEdges(game, nodeId).map((edge) => edge.a === nodeId ? edge.b : edge.a); }
function canPay(playerEntry, cost) { return RESOURCES.every((resource) => playerEntry.resources[resource] >= (cost[resource] || 0)); }
function pay(playerEntry, cost) { addResources(playerEntry.resources, cost, -1); }
function bankHas(game, resources) { return RESOURCES.every((resource) => game.bank[resource] >= (resources[resource] || 0)); }
function takeFromBank(game, playerEntry, resources) { if (!bankHas(game, resources)) return false; addResources(game.bank, resources, -1); addResources(playerEntry.resources, resources); return true; }
function returnToBank(game, playerEntry, resources) { addResources(playerEntry.resources, resources, -1); addResources(game.bank, resources); }
function isSetup(game) { return game.phase === 'setup'; }
function activePhase(game) { return game.phase === 'build'; }

function nodeFree(game, nodeId) { return !ownerAt(game, nodeId) && neighbors(game, nodeId).every((neighbor) => !ownerAt(game, neighbor)); }
function canPlaceRoad(game, playerEntry, edgeId, free = false) {
  const edge = edgeById(game, edgeId);
  if (!edge || game.players.some((entry) => entry.roads.includes(edgeId))) return false;
  if (isSetup(game) && playerEntry.id === current(game).id) return playerEntry.settlements.length && (edge.a === game.setupNode || edge.b === game.setupNode);
  return [edge.a, edge.b].some((nodeId) => {
    const owner = ownerAt(game, nodeId);
    if (owner && owner.id !== playerEntry.id) return false;
    return playerEntry.settlements.includes(nodeId) || playerEntry.cities.includes(nodeId) || adjacentEdges(game, nodeId).some((adjacent) => playerEntry.roads.includes(adjacent.id));
  });
}
function canPlaceSettlement(game, playerEntry, nodeId) {
  if (!nodeById(game, nodeId) || !nodeFree(game, nodeId)) return false;
  if (isSetup(game)) return true;
  return activePhase(game) && adjacentEdges(game, nodeId).some((edge) => playerEntry.roads.includes(edge.id));
}
function assignPorts(game, playerEntry, nodeId) { game.board.ports.forEach((port) => { const edge = edgeById(game, port.edge); if ((edge.a === nodeId || edge.b === nodeId) && !playerEntry.ports.includes(port.type)) playerEntry.ports.push(port.type); }); }
function buildSettlement(game, playerEntry, nodeId) {
  if (playerEntry.settlements.length + playerEntry.cities.length >= 5 || !canPlaceSettlement(game, playerEntry, nodeId)) throw Error('That settlement cannot be built there.');
  if (!isSetup(game)) { const cost = { wood: 1, brick: 1, wool: 1, grain: 1 }; if (!canPay(playerEntry, cost)) throw Error('A settlement costs 1 each of timber, clay, wool, and grain.'); pay(playerEntry, cost); addResources(game.bank, cost); }
  playerEntry.settlements.push(nodeId); assignPorts(game, playerEntry, nodeId); game.setupNode = nodeId;
  if (isSetup(game) && playerEntry.settlements.length === 2) { const node = nodeById(game, nodeId); const grant = emptyResources(); node.tiles.forEach((tileId) => { const tile = game.board.tiles.find((entry) => entry.id === tileId); if (tile.terrain !== 'desert') grant[tile.terrain]++; }); takeFromBank(game, playerEntry, grant); log(game, `${playerEntry.name} receives ${resourceText(grant)} from their second settlement.`); }
  log(game, `${playerEntry.name} builds a settlement.`); updateAwards(game); checkWin(game, playerEntry);
}
function buildRoad(game, playerEntry, edgeId, free = false) {
  if (playerEntry.roads.length >= 15 || !canPlaceRoad(game, playerEntry, edgeId, free)) throw Error('That road must connect to your network and cannot pass through another settlement.');
  if (!free && !isSetup(game)) { const cost = { wood: 1, brick: 1 }; if (!canPay(playerEntry, cost)) throw Error('A road costs 1 timber and 1 clay.'); pay(playerEntry, cost); addResources(game.bank, cost); }
  playerEntry.roads.push(edgeId); log(game, `${playerEntry.name} builds a road.`); updateAwards(game); checkWin(game, playerEntry);
}
function buildCity(game, playerEntry, nodeId) {
  if (!activePhase(game) || !playerEntry.settlements.includes(nodeId)) throw Error('Cities upgrade one of your settlements.');
  const cost = { grain: 2, ore: 3 }; if (!canPay(playerEntry, cost)) throw Error('A city costs 2 grain and 3 ore.'); pay(playerEntry, cost); addResources(game.bank, cost);
  playerEntry.settlements = playerEntry.settlements.filter((id) => id !== nodeId); playerEntry.cities.push(nodeId); log(game, `${playerEntry.name} fortifies a city.`); checkWin(game, playerEntry);
}
function score(game, playerEntry) { return playerEntry.settlements.length + playerEntry.cities.length * 2 + playerEntry.victoryDev + (game.longest === playerEntry.id ? 2 : 0) + (game.largest === playerEntry.id ? 2 : 0); }
function longestRoad(game, playerEntry) {
  const edgeIds = new Set(playerEntry.roads); let best = 0;
  function walk(nodeId, used) {
    const blocked = ownerAt(game, nodeId); if (blocked && blocked.id !== playerEntry.id && used.size) return used.size;
    let result = used.size;
    adjacentEdges(game, nodeId).forEach((edge) => { if (edgeIds.has(edge.id) && !used.has(edge.id)) { const next = new Set(used); next.add(edge.id); result = Math.max(result, walk(edge.a === nodeId ? edge.b : edge.a, next)); } });
    return result;
  }
  playerEntry.roads.forEach((edgeId) => { const edge = edgeById(game, edgeId); best = Math.max(best, walk(edge.a, new Set()), walk(edge.b, new Set())); }); return best;
}
function updateAwards(game) {
  const roads = game.players.map((entry) => ({ id: entry.id, value: longestRoad(game, entry) })); const highestRoad = Math.max(...roads.map((entry) => entry.value));
  const roadLeaders = roads.filter((entry) => entry.value === highestRoad);
  const roadHolderIsStillTied = game.longest && roadLeaders.some((entry) => entry.id === game.longest) && highestRoad >= 5;
  if (highestRoad >= 5 && roadLeaders.length === 1) { if (game.longest !== roadLeaders[0].id) log(game, `${findPlayer(game, roadLeaders[0].id).name} claims the Longest Road.`); game.longest = roadLeaders[0].id; }
  else if (!roadHolderIsStillTied) game.longest = null;
  const knights = game.players.map((entry) => ({ id: entry.id, value: entry.knights })); const highestKnights = Math.max(...knights.map((entry) => entry.value)); const knightLeaders = knights.filter((entry) => entry.value === highestKnights);
  if (highestKnights >= 3 && knightLeaders.length === 1) { if (game.largest !== knightLeaders[0].id) log(game, `${findPlayer(game, knightLeaders[0].id).name} claims the Largest Guard.`); game.largest = knightLeaders[0].id; }
}
function checkWin(game, playerEntry) { if (!game.winner && score(game, playerEntry) >= 10) { game.winner = playerEntry.id; game.phase = 'finished'; log(game, `${playerEntry.name} reaches ten renown and wins the table!`); } }
function setupOrder(players) { return [...players.keys(), ...players.keys()].map((index, step) => step < players.length ? index : players.length * 2 - 1 - step); }
function startGame(game) {
  if (game.players.length < 2) throw Error('Add at least one bot or another player.');
  game.started = true; game.board = buildBoard(); game.bank = { wood: 19, brick: 19, wool: 19, grain: 19, ore: 19 }; game.deck = shuffle(DEV); game.turn = 0; game.phase = 'setup'; game.setupSteps = setupOrder(game.players); game.setupStep = 0; game.turn = game.setupSteps[0]; game.setupNode = null; game.freeRoads = 0; log(game, `${current(game).name} places the first settlement.`); runBots(game);
}
function advanceSetup(game) { game.setupStep++; if (game.setupStep >= game.setupSteps.length) { game.phase = 'roll'; game.turn = 0; game.setupNode = null; log(game, `${current(game).name} begins the first harvest.`); } else { game.turn = game.setupSteps[game.setupStep]; game.setupNode = null; log(game, `${current(game).name} places a settlement.`); } }
function rollDice(game, playerEntry) {
  if (game.phase !== 'roll' || current(game).id !== playerEntry.id) throw Error('Roll at the start of your turn.');
  const value = crypto.randomInt(1, 7) + crypto.randomInt(1, 7); game.lastRoll = value; playerEntry.playedDev = false; playerEntry.dev.push(...playerEntry.newDev); playerEntry.newDev = [];
  log(game, `${playerEntry.name} rolls ${value}.`);
  if (value === 7) { game.discardQueue = game.players.filter((entry) => totalResources(entry.resources) > 7).map((entry) => entry.id); if (game.discardQueue.length) { game.phase = 'discard'; log(game, 'Anyone holding more than seven goods must discard half.'); } else { game.phase = 'robber'; } } else { game.players.forEach((entry) => { const gain = emptyResources(); game.board.tiles.filter((tile) => tile.number === value && tile.id !== game.board.robber && tile.terrain !== 'desert').forEach((tile) => { tile.nodes.forEach((nodeId) => { if (entry.settlements.includes(nodeId)) gain[tile.terrain]++; if (entry.cities.includes(nodeId)) gain[tile.terrain] += 2; }); }); takeFromBank(game, entry, gain); if (totalResources(gain)) log(game, `${entry.name} harvests ${resourceText(gain)}.`); }); game.phase = 'build'; }
}
function discard(game, playerEntry, resources) { if (game.phase !== 'discard' || game.discardQueue[0] !== playerEntry.id) throw Error('It is not your discard choice.'); const amount = Math.floor(totalResources(playerEntry.resources) / 2); if (totalResources(resources) !== amount || !canPay(playerEntry, resources)) throw Error(`Discard exactly ${amount} goods you hold.`); returnToBank(game, playerEntry, resources); game.discardQueue.shift(); log(game, `${playerEntry.name} discards ${amount} goods.`); if (!game.discardQueue.length) game.phase = 'robber'; }
function moveRobber(game, playerEntry, tileId, victimId) { if (game.phase !== 'robber' || current(game).id !== playerEntry.id) throw Error('The guard is not ready to move.'); const tile = game.board.tiles.find((entry) => entry.id === tileId); if (!tile || tile.id === game.board.robber) throw Error('Choose another land tile.'); const eligible = game.players.filter((entry) => entry.id !== playerEntry.id && totalResources(entry.resources) && tile.nodes.some((nodeId) => entry.settlements.includes(nodeId) || entry.cities.includes(nodeId)));
  if (victimId && !eligible.some((entry) => entry.id === victimId)) throw Error('That player cannot be robbed there.'); game.board.robber = tileId; if (victimId) { const victim = findPlayer(game, victimId); const available = RESOURCES.filter((resource) => victim.resources[resource]); const stolen = available[crypto.randomInt(available.length)]; victim.resources[stolen]--; playerEntry.resources[stolen]++; log(game, `${playerEntry.name} takes one unknown good from ${victim.name}.`); } else log(game, `${playerEntry.name} moves the guard.`); game.phase = 'build'; }
function buyDev(game, playerEntry) { const cost = { wool: 1, grain: 1, ore: 1 }; if (!activePhase(game) || !game.deck.length || !canPay(playerEntry, cost)) throw Error('A progress card costs 1 wool, 1 grain, and 1 ore.'); pay(playerEntry, cost); addResources(game.bank, cost); const card = game.deck.pop(); if (card === 'victory') playerEntry.victoryDev++; else playerEntry.newDev.push(card); log(game, `${playerEntry.name} draws a progress card.`); checkWin(game, playerEntry); }
function playDev(game, playerEntry, card, resources) { if (!activePhase(game) || playerEntry.playedDev || !playerEntry.dev.includes(card)) throw Error('You may play one available progress card per turn.'); playerEntry.dev.splice(playerEntry.dev.indexOf(card), 1); playerEntry.playedDev = true;
  if (card === 'knight') { playerEntry.knights++; game.phase = 'robber'; updateAwards(game); log(game, `${playerEntry.name} calls the guard.`); }
  if (card === 'road') { game.freeRoads = 2; log(game, `${playerEntry.name} receives two free roads.`); }
  if (card === 'plenty') { if (!resources || totalResources(resources) !== 2 || !bankHas(game, resources)) throw Error('Choose exactly two available goods.'); takeFromBank(game, playerEntry, resources); log(game, `${playerEntry.name} collects two goods from the bank.`); }
  if (card === 'monopoly') { const resource = resources && RESOURCES.find((entry) => resources[entry]); if (!resource) throw Error('Choose a resource for monopoly.'); let amount = 0; game.players.forEach((entry) => { if (entry.id !== playerEntry.id) { amount += entry.resources[resource]; entry.resources[resource] = 0; } }); playerEntry.resources[resource] += amount; log(game, `${playerEntry.name} claims ${amount} ${RESOURCE_NAMES[resource]} through monopoly.`); }
}
function bankTrade(game, playerEntry, give, receive) { if (!activePhase(game) || !RESOURCES.includes(give) || !RESOURCES.includes(receive) || give === receive) throw Error('Choose two different goods.'); const rate = playerEntry.ports.includes(give) ? 2 : playerEntry.ports.includes('any') ? 3 : 4; if (playerEntry.resources[give] < rate || game.bank[receive] < 1) throw Error(`You need ${rate} ${RESOURCE_NAMES[give]} for that trade.`); playerEntry.resources[give] -= rate; game.bank[give] += rate; playerEntry.resources[receive]++; game.bank[receive]--; log(game, `${playerEntry.name} trades with the bank.`); }
function offerTrade(game, playerEntry, give, want) { if (!activePhase(game) || !canPay(playerEntry, give) || !totalResources(give) || !totalResources(want)) throw Error('A trade needs goods on both sides, and you must hold your offer.'); game.trade = { id: randomId(8), from: playerEntry.id, give, want }; log(game, `${playerEntry.name} offers a trade.`); }
function acceptTrade(game, playerEntry) { const trade = game.trade; const source = trade && findPlayer(game, trade.from); if (!trade || !source || source.id === playerEntry.id || !canPay(source, trade.give) || !canPay(playerEntry, trade.want)) throw Error('This trade is no longer available.'); addResources(source.resources, trade.give, -1); addResources(playerEntry.resources, trade.give); addResources(playerEntry.resources, trade.want, -1); addResources(source.resources, trade.want); log(game, `${playerEntry.name} accepts ${source.name}'s trade.`); game.trade = null; }
function endTurn(game, playerEntry) { if (!activePhase(game) || current(game).id !== playerEntry.id || game.freeRoads) throw Error(game.freeRoads ? 'Place your remaining free roads first.' : 'Finish the harvest before ending your turn.'); game.trade = null; game.turn = (game.turn + 1) % game.players.length; game.phase = 'roll'; log(game, `${current(game).name}'s turn begins.`); runBots(game); }
function botChoice(array) { return array[crypto.randomInt(array.length)]; }
function runBots(game) { if (!game.started || game.winner) return; let safety = 0; while (current(game).bot && safety++ < 40) { const bot = current(game); try { if (game.phase === 'setup') { const nodes = game.board.nodes.filter((node) => canPlaceSettlement(game, bot, node.id)); if (nodes.length) buildSettlement(game, bot, botChoice(nodes).id); const edges = game.board.edges.filter((edge) => canPlaceRoad(game, bot, edge.id)); if (edges.length) buildRoad(game, bot, botChoice(edges).id, true); advanceSetup(game); } else if (game.phase === 'roll') rollDice(game, bot); else if (game.phase === 'discard') { if (game.discardQueue[0] !== bot.id) break; const amount = Math.floor(totalResources(bot.resources) / 2); const selection = emptyResources(); let remaining = amount; while (remaining) { const available = RESOURCES.filter((resource) => bot.resources[resource] > selection[resource]); selection[botChoice(available)]++; remaining--; } discard(game, bot, selection); } else if (game.phase === 'robber') { const tiles = game.board.tiles.filter((tile) => tile.id !== game.board.robber); const tile = botChoice(tiles); const victims = game.players.filter((entry) => entry.id !== bot.id && totalResources(entry.resources) && tile.nodes.some((nodeId) => entry.settlements.includes(nodeId) || entry.cities.includes(nodeId))); moveRobber(game, bot, tile.id, victims.length ? botChoice(victims).id : null); } else if (game.phase === 'build') { const city = bot.settlements.find((nodeId) => canPay(bot, { grain: 2, ore: 3 })); const settlement = game.board.nodes.find((node) => canPay(bot, { wood: 1, brick: 1, wool: 1, grain: 1 }) && canPlaceSettlement(game, bot, node.id)); const road = game.board.edges.find((edge) => canPay(bot, { wood: 1, brick: 1 }) && canPlaceRoad(game, bot, edge.id)); if (city) buildCity(game, bot, city); else if (settlement) buildSettlement(game, bot, settlement.id); else if (road) buildRoad(game, bot, road.id); endTurn(game, bot); } else break; } catch (error) { log(game, `${bot.name} considers the fields.`); if (game.phase === 'build') { game.freeRoads = 0; endTurn(game, bot); } else break; } }
}

function snapshot(game, viewerId) {
  const viewer = findPlayer(game, viewerId);
  return { code: game.code, host: game.host, started: game.started, phase: game.phase, turn: game.turn, lastRoll: game.lastRoll, board: game.board, bank: game.bank, trade: game.trade, longest: game.longest, largest: game.largest, winner: game.winner, log: game.log, freeRoads: game.freeRoads || 0, you: viewerId, players: game.players.map((entry) => ({ id: entry.id, name: entry.name, bot: entry.bot, color: entry.color, resources: entry.id === viewerId ? entry.resources : { count: totalResources(entry.resources) }, roads: entry.roads, settlements: entry.settlements, cities: entry.cities, dev: entry.id === viewerId ? entry.dev : [], newDev: entry.id === viewerId ? entry.newDev : [], devCount: entry.dev.length + entry.newDev.length + entry.victoryDev, knights: entry.knights, ports: entry.id === viewerId ? entry.ports : [], score: game.winner ? score(game, entry) : (entry.id === viewerId ? score(game, entry) : entry.settlements.length + entry.cities.length * 2 + (game.longest === entry.id ? 2 : 0) + (game.largest === entry.id ? 2 : 0)) })), pendingDiscard: game.discardQueue ? game.discardQueue[0] : null };
}
function broadcast(game) { clients.forEach((client) => { if (client.game === game.code) client.res.write(`event: state\ndata: ${JSON.stringify(snapshot(game, client.player))}\n\n`); }); }
function error(res, message) { res.writeHead(400, { 'Content-Type': 'application/json' }); res.end(JSON.stringify({ error: message })); }
function body(req) { return new Promise((resolve, reject) => { let data = ''; req.on('data', (chunk) => data += chunk); req.on('end', () => { try { resolve(data ? JSON.parse(data) : {}); } catch { reject(Error('Invalid request.')); } }); }); }
function gameFor(client) { const game = games.get(client.game); if (!game) throw Error('This table no longer exists.'); return game; }
function act(game, playerId, action, data) { const entry = findPlayer(game, playerId); if (!entry) throw Error('Player missing.'); if (game.winner) throw Error('This game is complete.'); if (action === 'start') { if (game.host !== playerId) throw Error('Only the table host can start.'); startGame(game); }
  else if (action === 'addBot') { if (game.host !== playerId || game.started || game.players.length >= 4) throw Error('Bots can only be added by the host before play.'); const bot = player(randomId(10), `Hearthkeeper ${game.players.filter((item) => item.bot).length + 1}`, true); bot.color = COLORS[game.players.length]; game.players.push(bot); log(game, `${bot.name} joins the table.`); }
  else if (action === 'settlement') { if (current(game).id !== playerId) throw Error('Wait for your turn.'); buildSettlement(game, entry, data.nodeId); }
  else if (action === 'road') { if (current(game).id !== playerId) throw Error('Wait for your turn.'); const free = game.freeRoads > 0; buildRoad(game, entry, data.edgeId, free); if (free) game.freeRoads--; if (isSetup(game)) advanceSetup(game); }
  else if (action === 'city') { if (current(game).id !== playerId) throw Error('Wait for your turn.'); buildCity(game, entry, data.nodeId); }
  else if (action === 'roll') rollDice(game, entry);
  else if (action === 'discard') discard(game, entry, data.resources);
  else if (action === 'robber') moveRobber(game, entry, data.tileId, data.victimId || null);
  else if (action === 'dev') { if (current(game).id !== playerId) throw Error('Wait for your turn.'); buyDev(game, entry); }
  else if (action === 'playDev') { if (current(game).id !== playerId) throw Error('Wait for your turn.'); playDev(game, entry, data.card, data.resources); }
  else if (action === 'bankTrade') { if (current(game).id !== playerId) throw Error('Wait for your turn.'); bankTrade(game, entry, data.give, data.receive); }
  else if (action === 'offer') { if (current(game).id !== playerId) throw Error('Wait for your turn.'); offerTrade(game, entry, data.give, data.want); }
  else if (action === 'accept') acceptTrade(game, entry);
  else if (action === 'end') endTurn(game, entry);
  else throw Error('Unknown action.'); runBots(game);
}

const mime = { '.html': 'text/html; charset=utf-8', '.js': 'application/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.svg': 'image/svg+xml' };
const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (url.pathname === '/events') { const token = url.searchParams.get('token'); const client = clients.get(token); if (!client) return error(res, 'Reconnect from the game page.'); res.writeHead(200, { 'Content-Type': 'text/event-stream', 'Cache-Control': 'no-cache', Connection: 'keep-alive' }); client.res = res; res.write(`event: state\ndata: ${JSON.stringify(snapshot(gameFor(client), client.player))}\n\n`); req.on('close', () => { if (clients.get(token)?.res === res) clients.get(token).res = null; }); return; }
  if (url.pathname === '/api/create' && req.method === 'POST') { const data = await body(req); const code = randomId(6); const id = randomId(12); const host = player(id, data.name); host.color = COLORS[0]; const game = { code, host: id, players: [host], started: false, phase: 'lobby', log: [{ id: randomId(), text: `${host.name} opens the table.`, at: Date.now() }] }; games.set(code, game); const token = randomId(24); clients.set(token, { game: code, player: id, res: null }); res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ token, code })); }
  if (url.pathname === '/api/join' && req.method === 'POST') { const data = await body(req); const game = games.get(String(data.code || '').toUpperCase()); if (!game || game.started || game.players.length >= 4) return error(res, 'That table cannot be joined.'); const entry = player(randomId(12), data.name); entry.color = COLORS[game.players.length]; game.players.push(entry); log(game, `${entry.name} joins the table.`); const token = randomId(24); clients.set(token, { game: game.code, player: entry.id, res: null }); broadcast(game); res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ token, code: game.code })); }
  if (url.pathname === '/api/action' && req.method === 'POST') { try { const data = await body(req); const client = clients.get(data.token); if (!client) return error(res, 'Session expired.'); const game = gameFor(client); act(game, client.player, data.action, data); broadcast(game); res.writeHead(200, { 'Content-Type': 'application/json' }); return res.end(JSON.stringify({ ok: true })); } catch (problem) { return error(res, problem.message); } }
  const localPath = url.pathname === '/' ? '/index.html' : url.pathname; const file = path.join(__dirname, 'public', path.normalize(localPath).replace(/^[/\\]+/, ''));
  if (!file.startsWith(path.join(__dirname, 'public'))) return error(res, 'Not found.'); fs.readFile(file, (problem, content) => { if (problem) { res.writeHead(404); res.end('Not found'); return; } res.writeHead(200, { 'Content-Type': mime[path.extname(file)] || 'application/octet-stream' }); res.end(content); });
});
server.listen(PORT, () => console.log(`Harbor & Hearth is ready at http://localhost:${PORT}`));
