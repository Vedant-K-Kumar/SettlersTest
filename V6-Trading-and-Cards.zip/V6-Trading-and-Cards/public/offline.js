const app = document.querySelector('#app');
const R = ['wood', 'brick', 'wool', 'grain', 'ore'];
const NAME = { wood:'Wood', brick:'Brick', wool:'Wool', grain:'Grain', ore:'Ore' };
const COLORS = ['#b73d2e', '#236f93', '#d69b27', '#5a7f43'];
const TERRAINS = ['wood','wood','wood','wood','grain','grain','grain','grain','wool','wool','wool','wool','brick','brick','brick','ore','ore','ore','desert'];
const NUMBERS = [2,3,3,4,4,5,5,6,6,8,8,9,9,10,10,11,11,12];
let game = null, tool = null, message = '', botTimer = null, audio = null, tradeSelection = { give: {wood:0,brick:0,wool:0,grain:0,ore:0}, want: {wood:0,brick:0,wool:0,grain:0,ore:0} };
const BOT_DELAY = 1250;
const empty = () => ({wood:0,brick:0,wool:0,grain:0,ore:0});
const sum = x => R.reduce((n,k)=>n+(x[k]||0),0);
const goods = x => R.filter(k=>x[k]).map(k=>`${x[k]} ${NAME[k]}`).join(', ') || 'nothing';
const shuffle = x => [...x].sort(()=>Math.random()-.5);
const key = (x,y) => `${Math.round(x*100)/100},${Math.round(y*100)/100}`;
const edgeKey = (a,b) => [a,b].sort().join('|');
const px = (q,r) => ({x:Math.sqrt(3)*(q+r/2),y:1.5*r});
function prepareSound(){try{audio=new (window.AudioContext||window.webkitAudioContext)();audio.resume()}catch{audio=null}}
function sound(kind){if(!audio)return;let now=audio.currentTime,notes=kind==='road'?[160,205]:kind==='settlement'?[392,523,659]:[130,165,210,260];notes.forEach((frequency,index)=>{let oscillator=audio.createOscillator(),gain=audio.createGain();oscillator.type=kind==='dice'?'square':'triangle';oscillator.frequency.setValueAtTime(frequency,now+index*.06);gain.gain.setValueAtTime(.0001,now+index*.06);gain.gain.exponentialRampToValueAtTime(kind==='dice'?.035:.06,now+index*.06+.01);gain.gain.exponentialRampToValueAtTime(.0001,now+index*.06+.11);oscillator.connect(gain).connect(audio.destination);oscillator.start(now+index*.06);oscillator.stop(now+index*.06+.13)})}
function createBoard(){
  const coords=[]; for(let q=-2;q<=2;q++)for(let r=-2;r<=2;r++)if(Math.abs(q+r)<=2)coords.push({q,r});
  let tiles;
  do { let nums=shuffle(NUMBERS), ni=0, ts=shuffle(TERRAINS); tiles=coords.map((c,i)=>({...c,id:String(i),terrain:ts[i],number:ts[i]==='desert'?null:nums[ni++],center:px(c.q,c.r)})); }
  while(tiles.some(t=>(t.number===6||t.number===8)&&tiles.some(o=>o!==t&&(o.number===6||o.number===8)&&Math.abs(t.q-o.q)+Math.abs(t.r-o.r)+Math.abs(t.q+t.r-o.q-o.r)===2)));
  const nodes=new Map(), edges=new Map();
  tiles.forEach(t=>{t.nodes=[];for(let i=0;i<6;i++){let a=(60*i-30)*Math.PI/180,p={x:t.center.x+Math.cos(a),y:t.center.y+Math.sin(a)},k=key(p.x,p.y);if(!nodes.has(k))nodes.set(k,{id:`n${nodes.size}`,x:p.x,y:p.y,tiles:[]});let n=nodes.get(k);n.tiles.push(t.id);t.nodes.push(n.id)}for(let i=0;i<6;i++){let a=t.nodes[i],b=t.nodes[(i+1)%6],k=edgeKey(a,b);if(!edges.has(k))edges.set(k,{id:`e${edges.size}`,a,b,tiles:[]});edges.get(k).tiles.push(t.id)}});
  const edgeList=[...edges.values()], coast=edgeList.filter(e=>e.tiles.length===1), nm=new Map([...nodes.values()].map(z=>[z.id,z])), ang=e=>{let u=nm.get(e.a),v=nm.get(e.b);return Math.atan2((u.y+v.y)/2,(u.x+v.x)/2)}, sorted=coast.sort((u,v)=>ang(u)-ang(v)), types=shuffle(['any','any','any','any','wood','brick','wool','grain','ore']);
  return {tiles,nodes:[...nodes.values()],edges:edgeList,ports:Array.from({length:9},(_,i)=>coast[Math.floor((i+.5)*coast.length/9)]).map((e,i)=>({edge:e.id,type:types[i]})),robber:tiles.find(t=>t.terrain==='desert').id};
}
function start(){
  prepareSound();
  const names=[...document.querySelectorAll('[data-name]')].map((input,index)=>input.value.trim()||`Hearthkeeper ${index+1}`);
  const players=names.slice(0,4).map((name,i)=>({id:i,name,bot:name.startsWith('Hearthkeeper'),color:COLORS[i],r:empty(),roads:[],settlements:[],cities:[],ports:[],dev:[],newDev:[],secretVp:[],knights:0,vp:0}));
  game={board:createBoard(),players,turn:0,phase:'setup',setup:[...players.keys(),...players.keys()].map((x,i)=>i<players.length?x:players.length*2-1-i),step:0,setupNode:null,bank:{wood:19,brick:19,wool:19,grain:19,ore:19},deck:shuffle(['knight','knight','knight','knight','knight','knight','knight','knight','knight','knight','knight','knight','knight','knight','road','road','plenty','plenty','monopoly','monopoly','victory','victory','victory','victory','victory']),log:['The first settlement awaits.'],longest:null,largest:null,freeRoads:0,winner:null,offer:null,turnCount:0,discardQueue:[],discardPick:empty(),pick:null};
  maybeBot(); render();
}
function p(){return game.players[game.turn]}; function n(id){return game.board.nodes.find(x=>x.id===id)}; function e(id){return game.board.edges.find(x=>x.id===id)};
function owner(node){return game.players.find(x=>x.settlements.includes(node)||x.cities.includes(node))};
function adj(node){return game.board.edges.filter(x=>x.a===node||x.b===node)}; function near(node){return adj(node).map(x=>x.a===node?x.b:x.a)};
function note(x){game.log.unshift(x);game.log=game.log.slice(0,24)}; function paid(x,c){return R.every(k=>x.r[k]>=(c[k]||0))}; function take(x,c){R.forEach(k=>x.r[k]-=c[k]||0)}; function give(x,c){R.forEach(k=>x.r[k]+=c[k]||0)};
function freeNode(id){return !owner(id)&&near(id).every(x=>!owner(x))}; function canSet(x,id){return freeNode(id)&&(game.phase==='setup'?!game.setupNode:adj(id).some(z=>x.roads.includes(z.id)))};
function canRoad(x,id){let z=e(id);if(!z||game.players.some(q=>q.roads.includes(id)))return false;if(game.phase==='setup')return game.setupNode&&(z.a===game.setupNode||z.b===game.setupNode);return [z.a,z.b].some(a=>{let o=owner(a);return (!o||o===x)&&(x.settlements.includes(a)||x.cities.includes(a)||adj(a).some(q=>x.roads.includes(q.id)))});}
function score(x){return x.settlements.length+x.cities.length*2+x.vp+(game.longest===x.id?2:0)+(game.largest===x.id?2:0)};
function ports(x,id){game.board.ports.forEach(q=>{let z=e(q.edge);if((z.a===id||z.b===id)&&!x.ports.includes(q.type))x.ports.push(q.type)})}
function placeSet(id){let x=p();if(game.phase==='setup'&&game.setupNode)return say('Place the road that leaves this settlement.');if(!canSet(x,id))return say('Settlements require an empty junction, clear of neighboring settlements, and connected to your road after setup.');let c={wood:1,brick:1,wool:1,grain:1};if(game.phase!=='setup'){if(!paid(x,c))return say('A settlement costs 1 Wood, 1 Brick, 1 Wool, and 1 Grain.');take(x,c);give({r:game.bank},c)}x.settlements.push(id);ports(x,id);game.setupNode=id;if(game.phase==='setup'&&x.settlements.length===2){n(id).tiles.forEach(tid=>{let t=game.board.tiles.find(q=>q.id===tid);if(t.terrain!=='desert'&&game.bank[t.terrain]){x.r[t.terrain]++;game.bank[t.terrain]--}})}sound('settlement');note(`${x.name} raises a settlement.`);tool=null;awards();if(game.phase!=='setup')win(x);render();if(game.phase==='setup'&&x.bot)maybeBot()}
function placeRoad(id){let x=p();if(!canRoad(x,id))return say('Roads must join your network and may not pass through another settlement.');let c={wood:1,brick:1};if(!game.freeRoads&&game.phase!=='setup'){if(!paid(x,c))return say('A road costs 1 Wood and 1 Brick.');take(x,c);give({r:game.bank},c)}x.roads.push(id);if(game.freeRoads)game.freeRoads--;sound('road');note(`${x.name} lays a road.`);tool=null;let wasSetup=game.phase==='setup';if(wasSetup){game.step++;if(game.step===game.setup.length){game.phase='roll';game.turn=0;note(`${p().name} begins the first harvest.`)}else{game.turn=game.setup[game.step];game.setupNode=null;note(`${p().name} places a settlement.`)}}else{awards();win(x)}render();if(wasSetup&&p().bot)maybeBot()}
function city(id){let x=p(),c={grain:2,ore:3};if(!x.settlements.includes(id)||!paid(x,c))return say('A city upgrades your settlement for 2 grain and 3 ore.');take(x,c);give({r:game.bank},c);x.settlements=x.settlements.filter(q=>q!==id);x.cities.push(id);note(`${x.name} builds a city.`);win(x);tool=null;render()}
function roll(){if(game.phase!=='roll'||game.rolling)return;let one=1+Math.floor(Math.random()*6),two=1+Math.floor(Math.random()*6),v=one+two;game.rolling=true;game.dice=[one,two];sound('dice');render();setTimeout(()=>{game.last=v;game.rolling=false;note(`${p().name} rolls ${v}.`);if(v===7){let order=game.players.map(q=>q.id);order=[...order.slice(game.turn),...order.slice(0,game.turn)];game.discardQueue=order.filter(id=>sum(game.players.find(q=>q.id===id).r)>7);game.discardPick=empty();if(game.discardQueue.length){game.phase='discard';note('A seven: anyone with more than seven cards discards half.');advanceDiscard()}else{game.phase='robber';tool='robber'}}else{game.board.tiles.filter(t=>t.number===v&&t.id!==game.board.robber).forEach(t=>game.players.forEach(x=>t.nodes.forEach(id=>{let amount=x.settlements.includes(id)?1:x.cities.includes(id)?2:0;if(amount&&game.bank[t.terrain]>=amount){x.r[t.terrain]+=amount;game.bank[t.terrain]-=amount}})));game.phase='build'}render();maybeBot()},720)}
function discarder(){return game.players.find(x=>x.id===(game.discardQueue||[])[0])}
function advanceDiscard(){if(!game||game.phase!=='discard')return;while(game.discardQueue.length){let x=discarder();if(!x||!x.bot)return;let amount=Math.floor(sum(x.r)/2),left=amount;while(left){let choices=R.filter(k=>x.r[k]),k=choices[Math.floor(Math.random()*choices.length)];x.r[k]--;game.bank[k]++;left--}note(`${x.name} discards ${amount} cards.`);game.discardQueue.shift()}game.phase='robber';tool='robber';game.discardPick=empty()}
function toggleDiscard(k){let x=discarder();if(!x||x.bot||game.phase!=='discard')return;if(!game.discardPick)game.discardPick=empty();if(game.discardPick[k]>0){game.discardPick[k]=0;render();return}let room=Math.floor(sum(x.r)/2)-sum(game.discardPick);if(room<=0||!x.r[k])return;game.discardPick[k]=Math.min(x.r[k],room);render()}
function confirmDiscard(){let x=discarder();if(!x||x.bot)return;let need=Math.floor(sum(x.r)/2);if(sum(game.discardPick)!==need||!canPayMap(x,game.discardPick))return say(`Discard exactly ${need} cards you hold.`);R.forEach(k=>{x.r[k]-=game.discardPick[k];game.bank[k]+=game.discardPick[k]});note(`${x.name} discards ${need} cards.`);game.discardQueue.shift();game.discardPick=empty();advanceDiscard();render();maybeBot()}
function discardPanel(){let who=discarder();if(!who)return '';let need=Math.floor(sum(who.r)/2),got=sum(game.discardPick||empty());if(who.bot)return `<section><h2>Discard</h2><div class="status"><strong>${who.name}</strong>is returning ${need} cards.</div></section>`;return `<section><h2>Discard</h2><div class="status"><strong>${who.name}</strong>Choose ${need} cards to discard. ${got} of ${need} selected. Click a resource card on the bottom row to set it aside. Click that card again to take the resource back.</div><div class="actions"><button class="wide" onclick="confirmDiscard()" ${got===need?'':'disabled'}>Discard ${need} cards</button></div></section>`}
function finishRobber(tileId,victimId){let actor=p(),victim=game.players.find(x=>x.id===victimId);game.board.robber=tileId;if(victim){let choices=R.filter(k=>victim.r[k]),taken=choices[Math.floor(Math.random()*choices.length)];if(taken){victim.r[taken]--;actor.r[taken]++;note(`${actor.name} robs ${victim.name}.`);toast('steal','Robber strikes!',[{who:actor.name,text:`Took a card from ${victim.name}.`}])}}else note(`${actor.name} moves the guard without a theft.`);game.phase=game.afterRobber||'build';game.afterRobber=null;tool=null;game.robberTile=null;render();maybeBot()}
function robber(id){if(game.phase!=='robber'||id===game.board.robber)return;let t=game.board.tiles.find(x=>x.id===id),victims=game.players.filter(x=>x!==p()&&sum(x.r)&&t.nodes.some(a=>x.settlements.includes(a)||x.cities.includes(a)));if(!p().bot&&victims.length){game.robberTile=id;tool='robber-victim';render();return}let victim=p().bot?bestOf(victims,q=>score(q)*2+sum(q.r)):victims[Math.floor(Math.random()*victims.length)];finishRobber(id,victim?.id??null)}
function buy(){let x=p(),c={wool:1,grain:1,ore:1};if(game.phase!=='build')return say('Buy a progress card after you roll.');if(!paid(x,c)||!game.deck.length)return say('A progress card costs wool, grain, and ore.');take(x,c);give({r:game.bank},c);x.newDev.push(game.deck.pop());note(`${x.name} draws a progress card.`);win(x);render()}
function revealVp(){let x=p();if(!x||x.bot)return;let i=x.newDev.indexOf('victory');if(i>=0)x.newDev.splice(i,1);else if(x.secretVp&&x.secretVp.length)x.secretVp.pop();else return;x.vp++;note(`${x.name} reveals a victory point.`);win(x);render()}
function beginTrade(kind){if(game.pick)return;tool=kind;tradeSelection={give:empty(),want:empty()};bankSel={give:null,qty:1,want:empty()};render()}
function chooseTrade(side,resource){if(!['bank','offer'].includes(tool))return;let ceiling=side==='give'?p().r[resource]:4;tradeSelection[side][resource]=tradeSelection[side][resource]>=ceiling?0:tradeSelection[side][resource]+1;render()}
function bank(){let x=p(),g=bankSel.give,q=bankSel.qty,want=bankSel.want,rate=bankRate(x,g);if(!g||sum(want)!==q||want[g]||x.r[g]<rate*q||R.some(k=>(want[k]||0)>game.bank[k]))return say('Choose a resource to give and exactly that many different or matching cards to receive.');x.r[g]-=rate*q;game.bank[g]+=rate*q;R.forEach(k=>{x.r[k]+=want[k]||0;game.bank[k]-=want[k]||0});note(`${x.name} trades ${chip(g,rate*q)} for ${goodsHtml(want)} at the bank.`);toast('trade','Bank trade complete',[{who:x.name,lose:{[g]:rate*q},gain:want}]);tool=null;render()}
function canPayMap(player, map){return R.every(k=>player.r[k]>=(map[k]||0))}
function acceptOffer(playerId){let offer=game.offer,buyer=game.players.find(x=>x.id===playerId),seller=game.players.find(x=>x.id===offer?.from);if(!offer||!buyer||!seller)return;if(!canPayMap(buyer,offer.want)||!canPayMap(seller,offer.give))return toast('fail','Trade failed',[{who:seller.name+' & '+buyer.name,text:'One side no longer has the cards for this deal.'}]);R.forEach(k=>{seller.r[k]-=offer.give[k]||0;buyer.r[k]+=offer.give[k]||0;buyer.r[k]-=offer.want[k]||0;seller.r[k]+=offer.want[k]||0});note(`${buyer.name} accepts ${seller.name}'s trade: ${goodsHtml(offer.give)} for ${goodsHtml(offer.want)}.`);toast('trade','Trade complete',[{who:seller.name,lose:offer.give,gain:offer.want},{who:buyer.name,lose:offer.want,gain:offer.give}]);game.offer=null;render();maybeBot()}
function declineOffer(){if(!game.offer)return;let offer=game.offer,seller=game.players.find(x=>x.id===offer.from);note(`${seller.name}'s trade offer goes unanswered.`);toast('fail','Offer declined',[{who:seller.name,text:`${goodsHtml(offer.give)} for ${goodsHtml(offer.want)} was not accepted.`}]);if(seller.bot)seller.tradeDeclinedTurn=game.turnCount;game.offer=null;render();maybeBot()}
function resourceWorth(bot,resource){let need=botNeed(bot);return resource===need?5:bot.r[resource]===0?4:bot.r[resource]===1?3:bot.r[resource]>=5?1:2}
function offerWorth(bot,map){return R.reduce((value,k)=>value+(map[k]||0)*resourceWorth(bot,k),0)}
function botWillAccept(bot,offer){return canPayMap(bot,offer.want)&&offerWorth(bot,offer.give)>=offerWorth(bot,offer.want)*1.2}
function submitOffer(){let give={...tradeSelection.give},want={...tradeSelection.want},seller=p();if(!sum(give)||!sum(want)||!canPayMap(seller,give)||R.some(k=>give[k]&&want[k]))return say('Choose cards to give and different cards to ask for, and only offer cards you hold.');game.offer={from:seller.id,give,want};let bot=game.players.filter(x=>x.bot&&botWillAccept(x,game.offer)).sort((a,b)=>offerWorth(b,give)-offerWorth(a,give))[0];if(bot){tool=null;tradeSelection={give:empty(),want:empty()};acceptOffer(bot.id)}else{note(`${seller.name}'s trade is declined: no bot can afford it or values it enough.`);toast('fail','No deal',[{who:seller.name,text:`${goodsHtml(give)} for ${goodsHtml(want)}: no bot could afford it or wanted it.`}]);game.offer=null;tool=null;render()}}
function next(){if(game.phase!=='build'||game.freeRoads)return say(game.freeRoads?'Place the remaining free roads.':'Roll before ending your turn.');let x=p();x.newDev.forEach(card=>{if(card==='victory')x.secretVp.push(card);else x.dev.push(card)});x.newDev=[];game.turn=(game.turn+1)%game.players.length;game.turnCount++;game.phase='roll';note(`${p().name}'s turn begins.`);render();maybeBot()}
function play(card){
  let x=p();
  if(!x.dev.includes(card)||game.phase==='setup'||game.phase==='discard'||game.phase==='robber')return;
  if(x.bot&&x.devPlayedTurn===game.turnCount)return;
  if(!x.bot&&card==='plenty'){game.pick={card:'plenty',chosen:[]};tool=null;render();return}
  if(!x.bot&&card==='monopoly'){game.pick={card:'monopoly',chosen:[]};tool=null;render();return}
  x.dev.splice(x.dev.indexOf(card),1);
  if(x.bot)x.devPlayedTurn=game.turnCount;
  if(card==='knight'){
    x.knights++;game.afterRobber=game.phase==='roll'?'roll':'build';game.phase='robber';tool='robber';note(`${x.name} sends the guard.`);awards();
  }
  if(card==='road'){game.freeRoads=2;note(`${x.name} receives two road deeds.`)}
  if(card==='plenty'){
    let picks=[],goal=botBuildGoal(x);
    for(let i=0;i<2;i++){
      let k=R.filter(q=>game.bank[q]>(picks.filter(z=>z===q).length))
        .sort((a,b)=>((goal.cost[b]||0)-x.r[b])-((goal.cost[a]||0)-x.r[a]) || resourceWorth(x,b)-resourceWorth(x,a))[0];
      if(!k)break;picks.push(k);
    }
    picks.forEach(k=>{x.r[k]++;game.bank[k]--});
    note(`${x.name} draws supplies from the bank.`);
  }
  if(card==='monopoly'){
    let k=bestOf(R,q=>game.players.filter(z=>z!==x).reduce((n,z)=>n+z.r[q],0)*(botNeed(x)===q?1.35:1)),got=0;
    game.players.forEach(q=>{if(q!==x){got+=q.r[k];q.r[k]=0}});x.r[k]+=got;note(`${x.name} claims all ${NAME[k]}.`);
  }
  awards();win(x);render();
}
function cancelDev(){game.pick=null;render()}
function pickBank(k){if(!game.pick||game.pick.card!=='plenty'||game.pick.chosen.length>=2)return;let used=empty();game.pick.chosen.forEach(q=>used[q]++);if(game.bank[k]-used[k]<1)return say('The bank has no more of that card.');game.pick.chosen.push(k);render()}
function unpickDev(){if(game.pick&&game.pick.chosen.length){game.pick.chosen.pop();render()}}
function confirmPlenty(){let x=p();if(!game.pick||game.pick.card!=='plenty'||!x.dev.includes('plenty'))return;let chosen=game.pick.chosen;if(chosen.length!==2)return say('Choose two cards from the bank.');let need=empty();chosen.forEach(k=>need[k]++);if(R.some(k=>game.bank[k]<need[k]))return say('The bank does not have those cards.');x.dev.splice(x.dev.indexOf('plenty'),1);R.forEach(k=>{x.r[k]+=need[k];game.bank[k]-=need[k]});note(`${x.name} takes ${goodsHtml(need)} from the bank.`);game.pick=null;awards();win(x);render()}
function confirmMonopoly(k){let x=p();if(!game.pick||game.pick.card!=='monopoly'||!x.dev.includes('monopoly')||!R.includes(k))return;x.dev.splice(x.dev.indexOf('monopoly'),1);let got=0;game.players.forEach(q=>{if(q!==x){got+=q.r[k];q.r[k]=0}});x.r[k]+=got;note(`${x.name} claims every ${NAME[k]} (${got}).`);game.pick=null;awards();win(x);render()}
function roadLen(x){let best=0,owned=new Set(x.roads);function walk(node,used){let o=owner(node);if(o&&o!==x&&used.size)return used.size;let r=used.size;adj(node).forEach(z=>{if(owned.has(z.id)&&!used.has(z.id)){let u=new Set(used);u.add(z.id);r=Math.max(r,walk(z.a===node?z.b:z.a,u))}});return r}x.roads.forEach(id=>{let z=e(id);best=Math.max(best,walk(z.a,new Set),walk(z.b,new Set))});return best}
function awards(){
  if(!game.players.length)return;
  let roads=game.players.map(x=>({id:x.id,length:roadLen(x)})),top=Math.max(...roads.map(x=>x.length)),leaders=roads.filter(x=>x.length===top);
  if(top<5)game.longest=null;
  else if(leaders.some(x=>x.id===game.longest)){} // The incumbent keeps the award on a tie.
  else if(leaders.length===1)game.longest=leaders[0].id;
  else game.longest=null;
  let armies=game.players.map(x=>({id:x.id,knights:x.knights})),maxArmy=Math.max(...armies.map(x=>x.knights)),armyLeaders=armies.filter(x=>x.knights===maxArmy);
  if(maxArmy<3)game.largest=null;
  else if(armyLeaders.some(x=>x.id===game.largest)){} // The incumbent keeps the award on a tie.
  else if(armyLeaders.length===1)game.largest=armyLeaders[0].id;
  else game.largest=null;
}
function hiddenVp(x){return (x.secretVp||[]).length+x.newDev.filter(card=>card==='victory').length}
function win(x){awards();if(x.bot&&score(x)<10&&score(x)+hiddenVp(x)>=10){let revealed=x.newDev.filter(card=>card==='victory').length+x.secretVp.length;x.newDev=x.newDev.filter(card=>card!=='victory');x.secretVp=[];x.vp+=revealed;note(`${x.name} reveals ${revealed} victory point${revealed>1?'s':''}.`)}if(score(x)>=10){game.winner=x.id;game.phase='done';note(`${x.name} wins the island!`)}}
function probability(number){return ({2:1,3:2,4:3,5:4,6:5,8:5,9:4,10:3,11:2,12:1})[number]||0}
function nodeValue(nodeId,bot){
  let node=n(nodeId),types=new Set(),value=0;
  node.tiles.forEach(tileId=>{let tile=game.board.tiles.find(q=>q.id===tileId);if(tile.terrain!=='desert'){let pip=tile.id===game.board.robber?0:probability(tile.number);value+=pip*(bot.r[tile.terrain]===0?1.35:1);types.add(tile.terrain)}});
  value+=types.size*2.5;
  value+=node.tiles.some(tileId=>game.board.ports.some(port=>{let z=e(port.edge);return z.a===nodeId||z.b===nodeId}))?1.5:0;
  return value;
}
function botBuildGoal(x){
  let settlement={wood:1,brick:1,wool:1,grain:1},cityCost={grain:2,ore:3};
  let cityNode=x.settlements.length?bestOf(x.settlements,id=>nodeValue(id,x)):null;
  let cityScore=cityNode?nodeValue(cityNode,x)+3:0;
  let setScore=bestOf(game.board.nodes.filter(q=>canSet(x,q.id)),q=>nodeValue(q.id,x));
  if(setScore)setScore=nodeValue(setScore.id,x)+4.5;
  if(cityNode&&cityScore>=setScore)return {kind:'city',cost:cityCost};
  return {kind:'settlement',cost:settlement};
}
function botNeed(x){
  let goal=botBuildGoal(x),missing=R.filter(k=>x.r[k]<(goal.cost[k]||0));
  return missing.sort((a,b)=>((goal.cost[a]||0)-x.r[a])-((goal.cost[b]||0)-x.r[b]) || resourceWorth(x,b)-resourceWorth(x,a))[0]||R.find(k=>x.r[k]===0&&game.bank[k]);
}
function resourceWorth(bot,resource){let need=botNeedShallow(bot),short=Math.max(0,(need.cost[resource]||0)-bot.r[resource]);return 3+short*2+(bot.r[resource]===0?1:0)-(bot.r[resource]>=4?1.5:0)}
function botNeedShallow(x){return botBuildGoalShallow(x)}
function botBuildGoalShallow(x){let settlement={wood:1,brick:1,wool:1,grain:1},city={grain:2,ore:3};return x.settlements.length&&x.cities.length<x.settlements.length?{cost:city}:{cost:settlement}}
function bestOf(items,scoreFn){return items.reduce((best,item)=>!best||scoreFn(item)>scoreFn(best)?item:best,null)}
function bestSettlement(x){return bestOf(game.board.nodes.filter(q=>canSet(x,q.id)),q=>nodeValue(q.id,x)+game.board.ports.filter(port=>{let z=e(port.edge);return z.a===q.id||z.b===q.id}).length*2+(score(x)>=7?2:0))}
function bestCity(x){return bestOf(x.settlements.filter(id=>paid(x,{grain:2,ore:3})),id=>nodeValue(id,x)+3)}
function bestRoadPlan(x){
  let starts=new Set([...x.settlements,...x.cities]);
  x.roads.forEach(id=>{let z=e(id);if(z){starts.add(z.a);starts.add(z.b)}});
  let queue=[...starts].filter(id=>{let o=owner(id);return !o||o===x}).map(id=>({node:id,first:null,distance:0}));
  let seen=new Map(queue.map(q=>[q.node,0])),best=null;
  while(queue.length){let cur=queue.shift();if(cur.distance>=8)continue;
    for(let edge of adj(cur.node)){
      if(x.roads.includes(edge.id)||game.players.some(q=>q!==x&&q.roads.includes(edge.id)))continue;
      let next=edge.a===cur.node?edge.b:edge.a,occupant=owner(next);if(occupant&&occupant!==x)continue;
      let first=cur.first||edge.id,dist=cur.distance+1;
      if(cur.distance===0&&!canRoad(x,edge.id))continue;
      if(freeNode(next)){
        let old=x.roads.length?roadLen(x):0;x.roads.push(first);let projected=roadLen(x);x.roads.pop();
        let roadGain=projected-old;let value=nodeValue(next,x)+4.5-dist*1.35+roadGain*1.4+(projected>=5&&game.longest!==x.id?3:0);
        if(!best||value>best.value)best={edge:first,target:next,distance:dist,value,roadGain};
      }
      if(!seen.has(next)||seen.get(next)>dist){seen.set(next,dist);queue.push({node:next,first,distance:dist})}
    }
  }
  return best&&canRoad(x,best.edge)?best:null;
}
function bestRobberTile(x){
  return bestOf(game.board.tiles.filter(t=>t.id!==game.board.robber),t=>{
    let value=0;
    game.players.forEach(q=>t.nodes.forEach(id=>{let amount=q.settlements.includes(id)?1:q.cities.includes(id)?2:0;if(!amount)return;let node=n(id),production=node.tiles.reduce((v,tid)=>{let tile=game.board.tiles.find(z=>z.id===tid);return v+(tile.id===t.id?probability(tile.number):0)},0);value+=(q===x?-1.4:1)*(production*amount+amount*2);if(q!==x&&score(q)>=Math.max(...game.players.map(score))-1)value+=2}));
    return value;
  });
}
function shouldPlayKnight(x){if(!x.dev.includes('knight')||x.devPlayedTurn===game.turnCount)return false;if(x.knights>=2)return true;let leader=bestOf(game.players.filter(q=>q!==x),score);return leader&&score(leader)>=score(x)+1&&bestRobberTile(x)&&bestRobberTile(x).nodes.some(id=>{let q=owner(id);return q&&q!==x});}
function botBankTrade(x){
  let wanted=botNeed(x);if(!wanted||!game.bank[wanted])return false;
  let candidates=R.filter(k=>k!==wanted).map(k=>({k,rate:x.ports.includes(k)?2:x.ports.includes('any')?3:4})).filter(q=>x.r[q.k]>=q.rate+1&&game.bank[wanted]>0).sort((a,b)=>(x.r[b.k]-b.rate)-(x.r[a.k]-a.rate));
  if(!candidates.length)return false;let {k,rate}=candidates[0];x.r[k]-=rate;game.bank[k]+=rate;x.r[wanted]++;game.bank[wanted]--;note(`${x.name} trades ${chip(k,rate)} for ${chip(wanted,1)} at the harbor.`);toast('trade','Harbor trade',[{who:x.name,lose:{[k]:rate},gain:{[wanted]:1}}]);return true;
}
function continueBot(){if(game&&!game.winner&&p().bot&&!game.offer&&!botTimer)botTimer=setTimeout(()=>{botTimer=null;maybeBot()},BOT_DELAY)}
function maybeBot(){
  if(!game||game.winner||!p().bot||game.offer||botTimer)return;
  botTimer=setTimeout(()=>{
    botTimer=null;let x=p();if(!x||!x.bot||game.winner||game.offer)return;
    if(game.phase==='setup'){
      let nodes=game.board.nodes.filter(q=>canSet(x,q.id));
      if(!game.setupNode&&nodes.length){let best=bestOf(nodes,q=>nodeValue(q.id,x));placeSet(best.id)}
      else{let edges=game.board.edges.filter(q=>canRoad(x,q.id)),best=bestOf(edges,q=>nodeValue(q.a===game.setupNode?q.b:q.a,x));if(best)placeRoad(best.id)}
      return;
    }
    if(game.phase==='discard'){advanceDiscard();if(game.phase==='discard'){render();return}}
    if(game.phase==='roll'){roll();return;}
    if(game.phase==='robber'){
      let tile=bestRobberTile(x);if(tile)robber(tile.id);return;
    }
    if(game.phase!=='build')return;

    // A bot takes multiple useful actions in one turn, rather than ending after its first purchase.
    if(shouldPlayKnight(x)){play('knight');continueBot();return;}
    if(x.dev.includes('monopoly')&&x.devPlayedTurn!==game.turnCount){
      let best=bestOf(R,k=>game.players.filter(q=>q!==x).reduce((v,q)=>v+q.r[k],0)*(botNeed(x)===k?1.4:1));
      if(best&&game.players.filter(q=>q!==x).reduce((v,q)=>v+q.r[best],0)>=3){play('monopoly');continueBot();return;}
    }
    if(x.dev.includes('plenty')&&x.devPlayedTurn!==game.turnCount){let goal=botBuildGoal(x),missing=R.filter(k=>x.r[k]<(goal.cost[k]||0)&&game.bank[k]);if(missing.length>=1){play('plenty');continueBot();return;}}
    if(game.freeRoads>0){let plan=bestRoadPlan(x);if(plan){placeRoad(plan.edge);continueBot();return;}game.freeRoads=0;}
    let cityNode=bestCity(x),settlementNode=bestSettlement(x);
    let cityScore=cityNode?nodeValue(cityNode,x)+3: -Infinity;
    let settlementScore=settlementNode?nodeValue(settlementNode.id,x)+4.5+game.board.ports.filter(port=>{let z=e(port.edge);return z.a===settlementNode.id||z.b===settlementNode.id}).length*2:-Infinity;
    if(cityNode&&paid(x,{grain:2,ore:3})&&cityScore>=settlementScore-1){city(cityNode);continueBot();return;}
    if(settlementNode&&paid(x,{wood:1,brick:1,wool:1,grain:1})){placeSet(settlementNode.id);continueBot();return;}
    if(cityNode&&paid(x,{grain:2,ore:3})){city(cityNode);continueBot();return;}

    let roadPlan=bestRoadPlan(x);
    if(x.dev.includes('road')&&x.devPlayedTurn!==game.turnCount&&roadPlan){play('road');continueBot();return;}
    let currentRoad=roadLen(x),otherRoad=Math.max(0,...game.players.filter(q=>q!==x).map(roadLen));
    let roadRace=roadPlan&&roadPlan.roadGain>0&&currentRoad>=4&&(game.longest===x.id||otherRoad>=currentRoad-1);
    if(roadPlan&&paid(x,{wood:1,brick:1})&&((roadPlan.distance<=3&&roadPlan.value>9)||roadRace)){placeRoad(roadPlan.edge);continueBot();return;}

    let development=paid(x,{wool:1,grain:1,ore:1})&&game.deck.length>0;
    if(development&&(score(x)>=4||!roadPlan||roadPlan.distance>3)){buy();continueBot();return;}
    if(botBankTrade(x)){continueBot();return;}

    let wanted=botNeed(x),extra=R.filter(k=>k!==wanted&&x.r[k]>=3).sort((a,b)=>x.r[b]-x.r[a])[0];
    if(extra&&wanted&&x.tradeDeclinedTurn!==game.turnCount&&x.tradeRequestedTurn!==game.turnCount&&game.players.some(q=>!q.bot&&q.r[wanted])){
      game.offer={from:x.id,give:{...empty(),[extra]:Math.min(2,x.r[extra]-1)},want:{...empty(),[wanted]:1}};
      x.tradeRequestedTurn=game.turnCount;note(`${x.name} requests ${goodsHtml(game.offer.want)} for ${goodsHtml(game.offer.give)}.`);render();return;
    }
    next();
  },BOT_DELAY);
}

function shape(t){let a=[];for(let i=0;i<6;i++){let z=(60*i-30)*Math.PI/180;a.push(`${t.center.x+Math.cos(z)},${t.center.y+Math.sin(z)}`)}return a.join(' ')}
function bounds(){let xs=game.board.nodes.map(x=>x.x),ys=game.board.nodes.map(x=>x.y);return `${Math.min(...xs)-1.1} ${Math.min(...ys)-1.1} ${Math.max(...xs)-Math.min(...xs)+2.2} ${Math.max(...ys)-Math.min(...ys)+2.2}`}

function terrainArt(type,x,y){
  const common=`stroke="#39291d" stroke-width=".035" stroke-linejoin="round"`;
  const art={
    wood:`<g transform="translate(${x} ${y-.24}) scale(.78)" ${common}><path d="M-.34 .22 Q-.22 .08 -.1 .22 Q.03 .04 .16 .2 Q.29 .08 .38 .22" fill="#31583b"/><path d="M-.27 .08l.13-.28 .13.28z M-.04 .04l.16-.36 .16.36z M.17 .1l.12-.25 .12.25z" fill="#527b48"/><path d="M-.14 .1v.2 M.12 .02v.28 M.31 .12v.18" stroke="#76502f" stroke-width=".055" fill="none"/><circle cx="-.22" cy="-.04" r=".035" fill="#b7c77a" stroke="none"/><circle cx=".18" cy="-.19" r=".03" fill="#c3cf87" stroke="none"/></g>`,
    brick:`<g transform="translate(${x} ${y-.24}) scale(.78)" ${common}><path d="M-.34 .2l.1-.15h.25l.1.15v.13h-.45z" fill="#b65b3c"/><path d="M-.2 .03l.1-.15h.25l.1.15v.13h-.45z" fill="#d17a4c"/><path d="M-.12-.13l.1-.14h.25l.1.14v.13h-.45z" fill="#a94732"/><path d="M-.28 .2h.34 M-.12 .03h.34 M.04-.13h.34" stroke="#f0b17a" stroke-width=".025"/></g>`,
    wool:`<g transform="translate(${x} ${y-.24}) scale(.78)" ${common}><path d="M-.4 .22Q-.34-.03-.13 .02Q-.03-.2 .12-.03Q.34-.08 .39 .22Z" fill="#66804a"/><path d="M-.24 .1q-.1-.18 .04-.23q.12-.05 .17 .08q.16-.1 .23 .05q.11 .16-.07 .23h-.3q-.17 0-.17-.13z" fill="#f1e8c9"/><circle cx="-.05" cy="-.08" r=".025" fill="#49372b" stroke="none"/><path d="M-.23 .19l-.02 .1 M.1 .18l.02 .11" fill="none" stroke="#49372b" stroke-width=".025"/></g>`,
    grain:`<g transform="translate(${x} ${y-.24}) scale(.78)" ${common}><path d="M0 .3V-.2 M-.16 .25l.04-.32 M.16 .25l-.04-.32" fill="none" stroke="#80602b" stroke-width=".045"/><path d="M0-.16q-.19-.03-.16-.17q.16-.03 .16 .17 M0-.05q.19-.03 .16-.17q-.16-.03-.16 .17 M-.12-.03q-.17-.04-.15-.17q.14-.02 .15 .17 M.12 .03q.17-.04 .15-.17q-.14-.02-.15 .17" fill="#e7bd52" stroke="#9a722f" stroke-width=".025"/><path d="M-.34 .22Q0 .08 .34 .22" fill="none" stroke="#67804a" stroke-width=".04"/></g>`,
    ore:`<g transform="translate(${x} ${y-.24}) scale(.78)" ${common}><path d="M-.38 .22l.13-.29 .12 .1 .15-.25 .15 .19 .13-.1 .12 .35z" fill="#777b79"/><path d="M-.25-.04l.12 .07 .15-.25 .1 .18-.12 .16-.12-.04z" fill="#b7b9ad"/><path d="M-.02 .03l.14-.18 .11 .13-.12 .14z" fill="#d4c8a1"/><path d="M-.36 .22h.76" stroke="#3e4745" stroke-width=".04"/></g>`,
    desert:`<g transform="translate(${x} ${y-.24}) scale(.78)" ${common}><path d="M-.4 .2Q-.18-.02 .03 .16Q.22-.04 .4 .2" fill="#e2bd79" stroke="none"/><path d="M-.12 .2V-.14q0-.12 .09-.12q.09 0 .09 .12v.34 M.06 .01q.17 0 .17-.13 M-.1 .04q-.16 0-.16-.12" fill="none" stroke="#47704a" stroke-width=".075" stroke-linecap="round"/><path d="M-.3 .25h.6" stroke="#b88e51" stroke-width=".025"/></g>`
  };
  return `<g pointer-events="none">${art[type]||''}</g>`;
}

function clickNode(id){if(tool==='city')city(id);else if(tool==='settlement'||(game.phase==='setup'&&!game.setupNode))placeSet(id)}function clickRoad(id){if(tool==='road'||game.phase==='setup')placeRoad(id)}function clickTile(id){if(tool==='robber')robber(id)}
function stores(x){return `<div class="resource-grid">${R.map(k=>rcard(k,{n:x.r[k],cls:'mini'})).join('')}</div>`}
function dice(){return game.dice?`<span class="dice"><i class="die d${game.dice[0]}">${game.dice[0]}</i><i class="die d${game.dice[1]}">${game.dice[1]}</i></span>`:''}
function controls(){let x=p();if(game.phase==='discard'&&!game.winner)return discardPanel();if(game.winner)return `<section><h2>A new legend</h2><p><b>${game.players.find(x=>x.id===game.winner).name}</b> reaches ten renown.</p><button onclick="game=null;render()">New table</button></section>`;if(game.offer){let seller=game.players.find(q=>q.id===game.offer.from),people=game.players.filter(q=>!q.bot&&canPayMap(q,game.offer.want));return `<section><h2>Trade offer</h2><div class="status"><strong>${seller.name}</strong>offers ${goodsHtml(game.offer.give)} for ${goodsHtml(game.offer.want)}.</div><div class="actions">${people.map(q=>`<button onclick="acceptOffer(${q.id})">Accept as ${q.name}</button>`).join('')}<button class="wide" onclick="declineOffer()">Decline</button></div></section>`}if(tool==='robber-victim'){let tile=game.board.tiles.find(q=>q.id===game.robberTile),victims=game.players.filter(q=>q!==x&&sum(q.r)&&tile.nodes.some(id=>q.settlements.includes(id)||q.cities.includes(id)));return `<section><h2>Choose a victim</h2><div class="status"><strong>Guard on ${tile.terrain}</strong>Choose a settlement owner adjacent to this tile. The stolen resource is selected at random.</div><div class="actions">${victims.map(q=>`<button onclick="finishRobber('${tile.id}',${q.id})">Rob ${q.name}</button>`).join('')}<button class="wide" onclick="finishRobber('${tile.id}',null)">Rob nobody</button></div></section>`}let text=game.phase==='setup'?'Gold markers show your legal settlement and road locations.':game.phase==='roll'?'Roll the two dice to begin your turn.':game.phase==='robber'?'Gold hexes are valid guard destinations.':`${x.name} may trade, build, or end the turn.`;let buttons='';if(!x.bot&&game.phase==='roll')buttons='<button class="wide" onclick="roll()">Roll dice</button>';if(!x.bot&&game.phase==='build')buttons=`<button onclick="tool='settlement';render()">Build house</button><button onclick="tool='road';render()">Build road</button><button onclick="tool='city';render()">Build city</button><button onclick="buy()">Progress card</button><button onclick="beginTrade('bank')">Bank trade</button><button onclick="beginTrade('offer')">Player trade</button><button class="wide" onclick="next()">Pass turn</button>`;let extra=(tool==='bank'||tool==='offer')?'':tool==='city'?'<div class="panel-form">Gold outlined houses are yours. Click one to raise a city.</div>':'';return `<section><h2>Turn</h2><div class="status"><strong>${x.name}${x.bot?' is considering their options...':''}</strong>${text}<br>${dice()}</div><div class="actions">${buttons}</div>${extra}</section>`}
function cardFace(card, playable){let title={knight:'Knight',road:'Road Craft',plenty:'Year of Plenty',monopoly:'Monopoly'}[card]||card,mark={knight:'♞',road:'╋',plenty:'✦',monopoly:'♜'}[card]||'◆';return `<button class="card card-${card}" ${playable?`onclick="play('${card}')"`:'disabled'}><b>${mark}</b><span>${title}</span></button>`}
function resourceCard(resource,count,viewer){if(game.phase==='discard'&&discarder()===viewer&&!viewer.bot){let sel=(game.discardPick&&game.discardPick[resource])||0;return rcard(resource,{n:count,cls:'dock'+(sel?' sel':''),on:count?`toggleDiscard('${resource}')`:'',dis:!count,tag:sel?`Set aside ${sel}`:'Click'})}return rcard(resource,{n:count,cls:'dock'})}
function progressCards(viewer,playable){let html='';viewer.dev.forEach(card=>{html+=dcard(card,{cls:'dock',on:playable?`play('${card}')`:'',dis:!playable,tag:playable?'Play':''})});viewer.newDev.forEach(card=>{html+=card==='victory'?dcard(card,{cls:'dock dev-secret',on:playable?'revealVp()':'',tag:'Secret'}):dcard(card,{cls:'dock held',tag:'Next turn'})});(viewer.secretVp||[]).forEach(()=>{html+=dcard('victory',{cls:'dock dev-secret',on:playable?'revealVp()':'',tag:'Show'})});for(let i=0;i<viewer.vp;i++)html+=dcard('victory',{cls:'dock',tag:'Shown'});return html||'<span class="empty-hand">No progress cards</span>'}
function buildDock(x){let house=paid(x,{wood:1,brick:1,wool:1,grain:1}),city=paid(x,{grain:2,ore:3})&&x.settlements.length,dev=paid(x,{wool:1,grain:1,ore:1})&&game.deck.length;let items=[{id:'house',name:'House',icon:'house',tag:'1 of each',ok:house,action:"tool=tool==='settlement'?null:'settlement';render()",on:tool==='settlement'},{id:'city',name:'City',icon:'city',tag:x.settlements.length?'2 grain, 3 ore':'Need a house',ok:city,action:"tool=tool==='city'?null:'city';render()",on:tool==='city'},{id:'dev',name:'Progress',icon:'dev',tag:game.deck.length?'Wool, grain, ore':'Deck empty',ok:dev,action:'buy()',on:false}];return items.map(item=>`<button type="button" class="rcard build build-${item.id} ${item.on?'sel':''} ${item.ok?'ready':''}" ${item.ok?'':'disabled'} onclick="${item.action}"><span class="rc-art">${buildIcon(item.icon)}</span><span class="rc-name">${item.name}</span><small class="rc-tag">${item.tag}</small></button>`).join('')}
function dock(viewer,show){if(!show)return '';let mine=viewer===p()&&!viewer.bot,playable=mine&&(game.phase==='build'||game.phase==='roll'),building=mine&&game.phase==='build';return `<footer class="card-dock"><div><h3>Your resource cards</h3><div class="hand-row">${R.map(k=>resourceCard(k,viewer.r[k],viewer)).join('')}</div></div><div><h3>Progress cards</h3><div class="hand-row">${progressCards(viewer,playable)}</div></div>${building?`<div><h3>Build</h3><div class="hand-row">${buildDock(viewer)}</div></div>`:''}</footer>`}
function render(){if(!game){app.innerHTML=`<section class="welcome"><div class="crest"></div><h1>Harbor & Hearth</h1><p class="subtitle">Enter a name only for a human seat. Every blank seat becomes a Hearthkeeper bot.</p><div class="entry"><label>Seat one<input data-name placeholder="Human name (optional)"></label><label>Seat two<input data-name placeholder="Human name (optional)"></label><label>Seat three<input data-name placeholder="Human name (optional)"></label><label>Seat four<input data-name placeholder="Human name (optional)"></label><button onclick="start()">Begin table</button></div><p class="tiny">Runs directly in Chrome. No install or account required.</p>${message?`<p class="alert">${message}</p>`:''}</section>`;return}let active=p(),humans=game.players.filter(q=>!q.bot),discarding=game.phase==='discard'?discarder():null,viewer=discarding&&!discarding.bot?discarding:(humans.length===1?humans[0]:active),canPlay=viewer===active&&!active.bot,showHand=canPlay||discarding===viewer;app.innerHTML=`<div class="game"><header class="topbar"><h1>Harbor & Hearth</h1><span>Offline table</span><span>First to 10 renown</span></header><div class="board-wrap">${board()}${game.dice?`<div class="board-dice ${game.rolling?'rolling':''}">${dice()}</div>`:''}</div><aside class="side">${controls()}<section><h2>${humans.length===1?'Your':'Active player\'s'} stores</h2>${stores(viewer)}${viewer.ports.length?`<p class="tiny">Your harbors: ${viewer.ports.map(k=>k==='any'?'Any 3:1':`${NAME[k]} 2:1`).join(', ')}</p>`:''}</section><section><h2>Houses & halls</h2><div class="players">${game.players.map((q,i)=>`<div class="player ${i===game.turn?'current':''}"><i style="--color:${q.color}"></i><span>${q.name}${q.bot?' (bot)':''}</span><span class="hand-count">${sum(q.r)} cards</span><span class="points">${score(q)} renown</span></div>`).join('')}</div></section><section><h2>Chronicle</h2><ul class="log">${game.log.map(q=>`<li>${q}</li>`).join('')}</ul></section>${message?`<p class="alert">${message}</p>`:''}</aside>${dock(viewer,showHand)}${tradeModal()}${devModal()}</div>`}
function say(x){message=x;render();setTimeout(()=>{if(message===x){message='';render()}},3500)}render();
