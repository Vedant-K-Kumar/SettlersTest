/* Harbor & Hearth: 2.5D isometric board renderer.
   Board logic is untouched; this only changes how board() draws it.
   Ground is squashed vertically (ISO.K); tiles get thickness (ISO.H);
   trees, houses, mountains etc. stand upright on top of the squashed ground. */
const ISO = { K: .8, H: .17 };
const iso = (x, y) => [+x.toFixed(3), +(y * ISO.K).toFixed(3)];
const pts = a => a.map(q => q.join(',')).join(' ');
function shade(h, f) { let n = parseInt(h.slice(1), 16), t = f < 0 ? 0 : 255, k = Math.abs(f); return '#' + [n >> 16, n >> 8 & 255, n & 255].map(v => Math.round(v + (t - v) * k).toString(16).padStart(2, '0')).join(''); }
function hexPts(c, s = 1, dy = 0) { let a = []; for (let i = 0; i < 6; i++) { let z = (60 * i - 30) * Math.PI / 180, q = iso(c.x + Math.cos(z) * s, c.y + Math.sin(z) * s); a.push([q[0], +(q[1] + dy).toFixed(3)]); } return a; }

const TOP = { wood: ['#659357', '#3f6d40'], brick: ['#d98456', '#a64b30'], wool: ['#b2cc76', '#82a050'], grain: ['#f2cb5f', '#cf9d37'], ore: ['#a3a9a6', '#6f7776'], desert: ['#efd69c', '#d0aa66'] };
const SIDE = { wood: '#27432c', brick: '#66291d', wool: '#51663a', grain: '#85621f', ore: '#404544', desert: '#8c6f3d' };
const OUT = 'stroke="#22150c" stroke-opacity=".6" stroke-width=".015" stroke-linejoin="round"';

/* ---------- small 3D building blocks (screen space, y grows downward) ---------- */
function isoBox(x, y, w, d, h, c) {
  return `<polygon points="${x - w},${y} ${x},${y + d} ${x},${y + d - h} ${x - w},${y - h}" fill="${c[1]}"/>` +
    `<polygon points="${x},${y + d} ${x + w},${y} ${x + w},${y - h} ${x},${y + d - h}" fill="${c[2]}"/>` +
    `<polygon points="${x - w},${y - h} ${x},${y - h - d} ${x + w},${y - h} ${x},${y + d - h}" fill="${c[0]}"/>`;
}
function isoRoof(x, y, w, d, h, rh, col) {
  let ty = y - h, ay = ty - rh, f = (a, b, c) => `${x + a[0]},${ty + a[1]} ${x + b[0]},${ty + b[1]} ${x},${ay}`;
  return `<polygon points="${f([-w, 0], [0, -d])}" fill="${shade(col, .2)}"/><polygon points="${f([0, -d], [w, 0])}" fill="${shade(col, -.15)}"/>` +
    `<polygon points="${f([-w, 0], [0, d])}" fill="${shade(col, .06)}"/><polygon points="${f([0, d], [w, 0])}" fill="${shade(col, -.32)}"/>`;
}
const WALL = ['#f8edd2', '#ecddb9', '#bda677'];
function house(col) {
  return `<g ${OUT}><ellipse cy=".05" rx=".24" ry=".09" fill="rgba(0,0,0,.3)" stroke="none"/>${isoBox(0, .03, .15, .08, .15, WALL)}${isoRoof(0, .03, .18, .1, .15, .2, col)}</g>`;
}
function cityPiece(col) {
  return `<g ${OUT}><ellipse cy=".06" rx=".32" ry=".11" fill="rgba(0,0,0,.3)" stroke="none"/>` +
    `${isoBox(-.1, -.02, .09, .05, .34, WALL)}${isoRoof(-.1, -.02, .11, .065, .34, .18, col)}` +
    `${isoBox(.08, .05, .16, .085, .18, WALL)}${isoRoof(.08, .05, .18, .1, .18, .17, col)}</g>`;
}

/* ---------- terrain scenes (origin = tile centre) ---------- */
function pine(x, y, s) {
  let t = ''; for (let k = 0; k < 3; k++) { let by = -.1 - k * .13, hw = .19 - k * .04; t += `<polygon points="0,${by - .26} ${-hw},${by} 0,${by + .04}" fill="#52904d"/><polygon points="0,${by - .26} 0,${by + .04} ${hw},${by}" fill="#2d5f37"/>`; }
  return `<g transform="translate(${x} ${y}) scale(${s})" stroke="#1d3320" stroke-width=".02" stroke-linejoin="round"><ellipse cy=".03" rx=".17" ry=".06" fill="rgba(0,0,0,.28)" stroke="none"/><rect x="-.03" y="-.1" width=".06" height=".12" fill="#5b3b22"/>${t}</g>`;
}
function mount(x, y, s, w, h) {
  let ax = .03;
  return `<g transform="translate(${x} ${y}) scale(${s})" stroke="#2e3433" stroke-width=".02" stroke-linejoin="round"><ellipse cy=".05" rx="${w + .05}" ry=".06" fill="rgba(0,0,0,.26)" stroke="none"/>` +
    `<polygon points="${-w},0 ${ax},${-h} 0,.07" fill="#959b99"/><polygon points="${ax},${-h} ${w},0 0,.07" fill="#5d6564"/>` +
    `<polygon points="${ax},${-h} ${ax - w * .38},${-h * .6} ${ax - .02},${-h * .67} ${ax + .04},${-h * .52} ${ax + w * .34},${-h * .62}" fill="#f7f4e9"/></g>`;
}
function stack(x, y, s) {
  const c = ['#eb9f6c', '#c9663f', '#96432b'], b = (bx, by) => isoBox(bx, by, .085, .045, .055, c);
  return `<g transform="translate(${x} ${y}) scale(${s})" ${OUT}><ellipse cy=".04" rx=".32" ry=".08" fill="rgba(0,0,0,.25)" stroke="none"/>${b(-.17, .04)}${b(0, .04)}${b(.17, .04)}${b(-.085, -.015)}${b(.085, -.015)}${b(0, -.07)}</g>`;
}
function sheep(x, y, s, f) {
  const wl = (cx, cy, r) => `<circle cx="${cx}" cy="${cy}" r="${r}"/>`;
  return `<g transform="translate(${x} ${y}) scale(${f * s} ${s})" stroke="#8a7f64" stroke-width=".015"><ellipse cy=".03" rx=".16" ry=".05" fill="rgba(0,0,0,.25)" stroke="none"/>` +
    `<g fill="#3d362f" stroke="none"><rect x="-.07" y="-.03" width=".035" height=".07"/><rect x=".04" y="-.03" width=".035" height=".07"/></g>` +
    `<g fill="#f9f2de">${wl(-.07, -.1, .08)}${wl(0, -.14, .09)}${wl(.07, -.1, .08)}${wl(0, -.07, .1)}</g>` +
    `<ellipse cx=".14" cy="-.08" rx=".05" ry=".045" fill="#40382f" stroke="none"/><ellipse cx=".12" cy="-.125" rx=".02" ry=".03" fill="#40382f" stroke="none"/></g>`;
}
function stalk(x, y) {
  return `<path d="M${x} ${y}q.012-.1 0-.2" stroke="#8c6a22" stroke-width=".022" fill="none"/><ellipse cx="${x}" cy="${y - .22}" rx=".032" ry=".07" fill="#f7d765" stroke="#a37a22" stroke-width=".012"/>`;
}
function cactus(x, y) {
  const arm = c => `<path d="M-.04 -.1H-.1V-.2M.04 -.15H.1V-.24" fill="none" stroke="${c[0]}" stroke-width="${c[1]}" stroke-linecap="round" stroke-linejoin="round"/>`;
  return `<g transform="translate(${x} ${y})"><ellipse cy=".02" rx=".12" ry=".04" fill="rgba(0,0,0,.25)"/>${arm(['#2e5c35', .08])}<rect x="-.045" y="-.3" width=".09" height=".32" rx=".045" fill="#2e5c35"/>${arm(['#55995a', .05])}<rect x="-.03" y="-.28" width=".06" height=".3" rx=".03" fill="#55995a"/></g>`;
}
const ART = {
  wood: () => [[-.44, 0, .62], [-.23, -.2, .68], [.22, -.22, .66], [.45, 0, .6], [.0, -.07, .72]].sort((a, b) => a[1] - b[1]).map(a => pine(...a)).join(''),
  ore: () => mount(.2, -.14, 1, .22, .42) + mount(-.24, -.02, 1, .27, .5) + mount(.4, .02, .8, .16, .3),
  brick: () => `<ellipse cy="-.06" rx=".5" ry=".22" fill="#8d4a30" opacity=".5"/>` + stack(.1, -.12, .8) + stack(-.12, .08, 1),
  wool: () => sheep(-.02, -.24, .8, 1) + sheep(.27, -.1, .9, -1) + sheep(-.3, -.02, 1, 1),
  grain: () => { let t = ''; for (let r = 0; r < 3; r++) for (let i = 0; i < 6; i++) t += stalk(-.38 + i * .15 + (r % 2) * .07, -.2 + r * .12); return t + `<g ${OUT}>${isoBox(.38, .06, .09, .05, .09, ['#f5db7d', '#dbb44b', '#b68b2f'])}</g>`; },
  desert: () => `<path d="M-.5 .12Q-.28-.14-.02 .08Q.2-.08 .5 .12Z" fill="#e6c581" stroke="#a98245" stroke-width=".02" stroke-linejoin="round"/><path d="M-.5 .12Q-.28-.14-.02 .08V.12Z" fill="#c9a460" opacity=".5"/>` + cactus(.3, -.02) + `<polygon points="-.2,.02 -.14,-.05 -.06,-.03 -.04,.03" fill="#9c9486" stroke="#4a443b" stroke-width=".015"/>`
};

function pawn(x, y) {
  return `<g transform="translate(${x} ${y})" stroke="#0b0b0e" stroke-width=".02"><ellipse cy=".03" rx=".15" ry=".06" fill="rgba(0,0,0,.4)" stroke="none"/><path d="M-.11 .03Q-.1-.12-.04-.2H.04Q.1-.12 .11 .03Z" fill="url(#pawn)"/><circle cy="-.27" r=".075" fill="url(#pawn)"/><ellipse cx="-.025" cy="-.3" rx=".02" ry=".03" fill="#fff" opacity=".25" stroke="none"/></g>`;
}
function tokenSvg(n, x, y) {
  let pips = 6 - Math.abs(7 - n), dots = ''; for (let i = 0; i < pips; i++) dots += `<circle cx="${(i - (pips - 1) / 2) * .045}" cy=".12" r=".014" fill="${n === 6 || n === 8 ? '#a12e24' : '#35241a'}"/>`;
  return `<g transform="translate(${x} ${y})"><ellipse cy=".05" rx=".28" ry=".17" fill="#4a3320"/><ellipse rx=".28" ry=".17" fill="#f5e8c8" stroke="#8a6234" stroke-width=".025"/><ellipse rx=".22" ry=".13" fill="none" stroke="#c9a468" stroke-width=".015"/><text class="iso-num ${n === 6 || n === 8 ? 'hot' : ''}" y=".05">${n}</text>${dots}</g>`;
}

/* ---------- the board ---------- */
function board() {
  const b = game.board, player = p(), H = ISO.H, K = ISO.K;
  const tiles = [...b.tiles].sort((u, v) => u.center.y - v.center.y || u.center.x - v.center.x);
  const xs = b.nodes.map(z => z.x), ys = b.nodes.map(z => z.y * K);
  const x0 = Math.min(...xs) - 1.5, y0 = Math.min(...ys) - 1.15, W = Math.max(...xs) + 1.5 - x0, Ht = Math.max(...ys) + 1.3 - y0;
  const defs = `<defs>${Object.entries(TOP).map(([k, [a, c]]) => `<linearGradient id="gt-${k}" x1="0" y1="0" x2="0" y2="1"><stop offset="0" stop-color="${a}"/><stop offset="1" stop-color="${c}"/></linearGradient>`).join('')}` +
    `<radialGradient id="sea" cx=".5" cy=".5" r=".75"><stop offset="0" stop-color="#2b8b99"/><stop offset=".6" stop-color="#17596c"/><stop offset="1" stop-color="#0d3342"/></radialGradient>` +
    `<linearGradient id="pawn" x1="0" x2="1"><stop offset="0" stop-color="#5a5a66"/><stop offset="1" stop-color="#17171c"/></linearGradient></defs>`;
  const sea = `<rect x="${x0}" y="${y0}" width="${W}" height="${Ht}" rx="1.1" fill="url(#sea)" stroke="#c49a4b" stroke-width=".07"/><rect x="${x0 + .14}" y="${y0 + .14}" width="${W - .28}" height="${Ht - .28}" rx=".95" fill="none" stroke="#f0d9a0" stroke-opacity=".3" stroke-width=".02"/>`;
  const shallows = `<g opacity=".3" fill="#86d6cc" stroke="#86d6cc" stroke-width=".3" stroke-linejoin="round">${tiles.map(t => `<polygon points="${pts(hexPts(t.center, 1.3))}"/>`).join('')}</g>`;
  const sand = `<g fill="#8b6b3c" stroke="#8b6b3c" stroke-width=".02" stroke-linejoin="round">${tiles.map(t => `<polygon points="${pts(hexPts(t.center, 1.1, .13))}"/>`).join('')}</g>` +
    `<g fill="#ecd9a8" stroke="#ecd9a8" stroke-width=".02" stroke-linejoin="round">${tiles.map(t => `<polygon points="${pts(hexPts(t.center, 1.1))}"/>`).join('')}</g>`;

  const tileSvg = tiles.map(t => {
    const top = hexPts(t.center, 1), V = hexPts(t.center, 1, H), s = SIDE[t.terrain], [cx, cy] = iso(t.center.x, t.center.y), target = tool === 'robber' && t.id !== b.robber;
    return `<g onclick="clickTile('${t.id}')"><polygon points="${pts(V)}" fill="${s}"/><polygon points="${pts([top[1], top[2], V[2], V[1]])}" fill="${shade(s, -.18)}"/><polygon points="${pts([top[2], top[3], V[3], V[2]])}" fill="${shade(s, .1)}"/>` +
      `<polygon class="iso-top ${target ? 'target' : ''}" points="${pts(top)}" fill="url(#gt-${t.terrain})"/><polygon points="${pts(hexPts(t.center, .9))}" fill="none" stroke="#fff" stroke-opacity=".16" stroke-width=".03" pointer-events="none"/>` +
      `<g transform="translate(${cx} ${cy})" pointer-events="none">${ART[t.terrain]()}${t.number ? tokenSvg(t.number, 0, .3) : ''}${b.robber === t.id ? pawn(-.34, .06) : ''}</g></g>`;
  }).join('');

  const harbors = `<g pointer-events="none">${b.ports.map(q => {
    const z = e(q.edge), a = n(z.a), d = n(z.b), mx = (a.x + d.x) / 2, my = (a.y + d.y) / 2, len = Math.hypot(mx, my) || 1, [hx, hy] = iso(mx + mx / len * .75, my + my / len * .75), [ax, ay] = iso(a.x, a.y), [dx, dy] = iso(d.x, d.y);
    const nm = q.type === 'any' ? 'Any' : NAME[q.type], ratio = q.type === 'any' ? '3:1' : '2:1', ring = q.type === 'any' ? '#7b5a34' : TOP[q.type][1];
    return `<g stroke-linecap="round"><path d="M${ax} ${ay + .04}L${hx} ${hy + .04}M${dx} ${dy + .04}L${hx} ${hy + .04}" stroke="#2a1a0d" stroke-opacity=".45" stroke-width=".085" fill="none"/><path d="M${ax} ${ay}L${hx} ${hy}M${dx} ${dy}L${hx} ${hy}" stroke="#a97c4a" stroke-width=".065" fill="none"/>` +
      `<ellipse cx="${hx}" cy="${hy + .05}" rx=".4" ry=".27" fill="#3a2614"/><ellipse cx="${hx}" cy="${hy}" rx=".4" ry=".27" fill="#efdcae" stroke="${ring}" stroke-width=".06"/>` +
      `<text class="iso-port" x="${hx}" y="${hy - .02}" font-size=".13">${nm}</text><text class="iso-port" x="${hx}" y="${hy + .13}" font-size=".17" font-weight="700">${ratio}</text></g>`;
  }).join('')}</g>`;

  const road = [], claimed = [];
  b.edges.forEach(z => {
    const a = n(z.a), d = n(z.b), [x1, y1] = iso(a.x, a.y), [x2, y2] = iso(d.x, d.y), o = game.players.find(x => x.roads.includes(z.id)), target = !o && (tool === 'road' || game.phase === 'setup') && !player.bot && canRoad(player, z.id), ln = (dy, st, w) => `<line x1="${x1}" y1="${y1 + dy}" x2="${x2}" y2="${y2 + dy}" stroke="${st}" stroke-width="${w}" stroke-linecap="round"/>`;
    if (o) claimed.push([(y1 + y2) / 2, `<g>${ln(.05, 'rgba(24,14,8,.5)', .17)}${ln(0, shade(o.color, -.35), .17)}${ln(-.02, o.color, .12)}${ln(-.04, shade(o.color, .35), .03)}</g>`]);
    else road.push(`<g onclick="clickRoad('${z.id}')">${target ? `<line class="iso-road-target" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"/>` : `<line class="iso-edge" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"/>`}</g>`);
  });

  const nodes = [...b.nodes].sort((u, v) => u.y - v.y).map(z => {
    const o = owner(z.id), [x, y] = iso(z.x, z.y);
    if (o) {
      const city = o.cities.includes(z.id), target = tool === 'city' && o === player && !city;
      return `<g class="iso-piece ${target ? 'target' : ''}" transform="translate(${x} ${y})" onclick="clickNode('${z.id}')">${city ? cityPiece(o.color) : house(o.color)}${target ? '<ellipse class="iso-ring" cy=".05" rx=".3" ry=".13"/>' : ''}</g>`;
    }
    const target = (tool === 'settlement' || game.phase === 'setup') && !player.bot && canSet(player, z.id);
    return `<g onclick="clickNode('${z.id}')"><ellipse class="iso-node ${target ? 'target' : ''}" cx="${x}" cy="${y}" rx="${target ? .16 : .07}" ry="${target ? .1 : .045}"/><ellipse cx="${x}" cy="${y}" rx=".22" ry=".14" fill="transparent"/></g>`;
  }).join('');

  return `<svg class="board" viewBox="${x0} ${y0} ${W} ${Ht}">${defs}${sea}${shallows}${sand}${tileSvg}${harbors}${road.join('')}${claimed.sort((u, v) => u[0] - v[0]).map(q => q[1]).join('')}${nodes}</svg>`;
}
