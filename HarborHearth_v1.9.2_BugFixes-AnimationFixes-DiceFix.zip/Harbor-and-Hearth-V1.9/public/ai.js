/* Harbor & Hearth - strategic bot brain (Normal difficulty).
   Engine-agnostic: every decision receives a normalized snapshot S built by the host
   (offline.js or server.js) and returns an action object. Opponent hands inside S are the
   bot's own card-tracking estimates, never the true hidden hands, so bots play fair.

   Core ideas (drawn from established Catan strategy):
   - Production is measured in pips (dice probability), valued with diminishing returns so
     resource diversity and complementary numbers matter.
   - Each bot picks goals by value-per-time: the VP-equivalent gain of a build divided by the
     estimated turns until it can be afforded (production + harbor rates). This is the same
     "estimated time to build" planning used by strong Catan programs.
   - Six archetypes bias resource weights, goal categories, robber aggression and trading.
   - Threat assessment (visible points + expected hidden points) drives robber targeting,
     trade refusals, blocking settlements and Longest Road cuts against the leader. */
(function (root) {
  'use strict';

  const R = ['wood', 'brick', 'wool', 'grain', 'ore'];
  const COST = {
    road: { wood: 1, brick: 1 },
    settlement: { wood: 1, brick: 1, wool: 1, grain: 1 },
    city: { grain: 2, ore: 3 },
    dev: { wool: 1, grain: 1, ore: 1 }
  };
  const PIPS = { 2: 1, 3: 2, 4: 3, 5: 4, 6: 5, 8: 5, 9: 4, 10: 3, 11: 2, 12: 1 };
  const DECK = { knight: 14, road: 2, plenty: 2, monopoly: 2, victory: 5 };
  const LIMIT = { settlement: 5, city: 4, road: 15 };
  const CARDS_PER_VP = 4.6;
  const TIME_K = 1.2;

  const vec = (o) => ({ wood: (o && o.wood) || 0, brick: (o && o.brick) || 0, wool: (o && o.wool) || 0, grain: (o && o.grain) || 0, ore: (o && o.ore) || 0 });
  const total = (v) => R.reduce((n, k) => n + ((v && v[k]) || 0), 0);
  const add = (a, b, s = 1) => { const o = vec(a); R.forEach((k) => { o[k] += ((b && b[k]) || 0) * s; }); return o; };
  const covers = (h, c) => R.every((k) => ((h && h[k]) || 0) >= ((c && c[k]) || 0) - 1e-9);
  const clamp = (x, lo, hi) => Math.max(lo, Math.min(hi, x));
  const uniq = (a) => [...new Set(a)];
  const mul = (c, n) => { const o = vec(); R.forEach((k) => { o[k] = (c[k] || 0) * n; }); return o; };

  /* ---------------------------------------------------------------- archetypes */
  // Archetypes live in archetypes.js (shared registry). The AI reads their weights from there.
  const ARCH = (root.HearthArchetypes) || (typeof require === 'function' ? require('./archetypes.js') : null);
  const STYLES = ARCH.STYLES; const BALANCED = ARCH.BALANCED; const STYLE_ORDER = ARCH.order();

  /* ---------------------------------------------------------------- board geometry (cached) */
  const geoCache = new WeakMap();
  function geo(board) {
    let g = geoCache.get(board);
    if (g) return g;
    g = { node: new Map(), edge: new Map(), tile: new Map(), nodeEdges: new Map(), nbrs: new Map(), nodePorts: new Map(), raw: new Map() };
    board.nodes.forEach((n) => { g.node.set(n.id, n); g.nodeEdges.set(n.id, []); g.nodePorts.set(n.id, []); });
    board.tiles.forEach((t) => g.tile.set(t.id, t));
    board.edges.forEach((e) => { g.edge.set(e.id, e); g.nodeEdges.get(e.a).push(e); g.nodeEdges.get(e.b).push(e); });
    board.nodes.forEach((n) => g.nbrs.set(n.id, g.nodeEdges.get(n.id).map((e) => (e.a === n.id ? e.b : e.a))));
    board.ports.forEach((p) => { const e = g.edge.get(p.edge); if (!e) return; [e.a, e.b].forEach((id) => { if (!g.nodePorts.get(id).includes(p.type)) g.nodePorts.get(id).push(p.type); }); });
    const supply = vec();
    board.tiles.forEach((t) => { if (t.terrain !== 'desert' && t.number) supply[t.terrain] += PIPS[t.number]; });
    const avg = total(supply) / 5;
    g.scarcity = {};
    R.forEach((k) => { g.scarcity[k] = clamp(Math.pow(avg / Math.max(1, supply[k]), 0.4), 0.82, 1.35); });
    board.nodes.forEach((n) => {
      const v = vec(); const nums = new Set();
      n.tiles.forEach((tid) => { const t = g.tile.get(tid); if (t && t.terrain !== 'desert' && t.number) { v[t.terrain] += PIPS[t.number]; nums.add(t.number); } });
      g.raw.set(n.id, { prod: v, pips: total(v), kinds: R.filter((k) => v[k] > 0).length, nums: nums.size });
    });
    geoCache.set(board, g);
    return g;
  }

  /* ---------------------------------------------------------------- context */
  function ctx(S) {
    const g = geo(S.board);
    const own = new Map(); const road = new Map();
    S.players.forEach((p, i) => {
      p.settlements.forEach((n) => own.set(n, i));
      p.cities.forEach((n) => own.set(n, i));
      p.roads.forEach((e) => road.set(e, i));
    });
    const me = S.players[S.meIndex];
    const C = { S, g, own, road, mi: S.meIndex, me, N: S.players.length, st: styleOf(me), np: new Map(), memo: {} };
    // Maturity drift: archetype category biases are full strength early and soften as the bot nears
    // ten points, so a Roadrunner still builds cities to close out a game without losing its identity.
    const drift = clamp((8 - (me.vp + (me.hiddenVp || 0))) / 4, 0.35, 1);
    C.cat = {}; Object.keys(C.st.cat).forEach((k) => { C.cat[k] = 1 + (C.st.cat[k] - 1) * drift; });
    C.lens = S.players.map((_, i) => roadLen(C, i));
    const pool = S.devPool || DECK; const poolSize = Math.max(1, total2(pool));
    C.pVP = (pool.victory || 0) / poolSize;
    C.exp = S.players.map((p, i) => expVP(C, i));
    const lead = Math.max(...C.exp);
    C.horizon = clamp((10 - lead) * 2.3 + 1.5, 2, 20);
    C.oppDist = S.players.map((_, i) => (i === C.mi ? null : networkDist(C, i, 3)));
    return C;
  }
  function total2(o) { return Object.keys(o).reduce((n, k) => n + (o[k] || 0), 0); }
  function styleOf(p) { return (p && p.style && STYLES[p.style]) || BALANCED; }
  function expVP(C, i) {
    const p = C.S.players[i];
    if (i === C.mi) return p.vp + (p.hiddenVp || 0);
    return p.vp + (p.devHidden || 0) * C.pVP;
  }
  function threatW(C, i) {
    if (i === C.mi) return 0;
    const lead = C.exp[i] - C.exp[C.mi];
    return 1 + Math.max(0, lead) * 0.35 + (C.exp[i] >= 7.5 ? 1.2 : 0) + (C.exp[i] >= 8.5 ? 2 : 0);
  }
  function leaderOther(C) { let best = -1, idx = -1; C.exp.forEach((v, i) => { if (i !== C.mi && v > best) { best = v; idx = i; } }); return { vp: best, i: idx }; }

  /* ---------------------------------------------------------------- rules helpers */
  function freeNode(C, n) { return !C.own.has(n) && C.g.nbrs.get(n).every((m) => !C.own.has(m)); }
  function canRoad(C, i, eid) {
    const e = C.g.edge.get(eid);
    if (!e || C.road.has(eid)) return false;
    return [e.a, e.b].some((a) => {
      const o = C.own.get(a);
      if (o !== undefined && o !== i) return false;
      if (o === i) return true;
      return C.g.nodeEdges.get(a).some((x) => C.road.get(x.id) === i);
    });
  }
  function legalSettle(C, i, n) { return freeNode(C, n) && C.g.nodeEdges.get(n).some((e) => C.road.get(e.id) === i); }
  function legalRoads(C, i) { const out = []; C.g.edge.forEach((e, id) => { if (canRoad(C, i, id)) out.push(id); }); return out; }
  function roadLen(C, i) {
    let best = 0; const used = new Set();
    const walk = (node) => {
      const o = C.own.get(node);
      if (o !== undefined && o !== i && used.size) return used.size;
      let r = used.size;
      for (const ed of C.g.nodeEdges.get(node)) {
        if (C.road.get(ed.id) === i && !used.has(ed.id)) {
          used.add(ed.id); r = Math.max(r, walk(ed.a === node ? ed.b : ed.a)); used.delete(ed.id);
        }
      }
      return r;
    };
    C.road.forEach((owner, eid) => {
      if (owner !== i) return;
      const e = C.g.edge.get(eid);
      // only start from ends of chains (or any edge if the network is a loop) to save work
      const deg = (n) => C.g.nodeEdges.get(n).filter((x) => C.road.get(x.id) === i).length;
      if (deg(e.a) !== 2 || best === 0) best = Math.max(best, walk(e.a));
      if (deg(e.b) !== 2 || best === 0) best = Math.max(best, walk(e.b));
    });
    return best;
  }
  function withRoads(C, i, edges, fn) { edges.forEach((e) => C.road.set(e, i)); try { return fn(); } finally { edges.forEach((e) => C.road.delete(e)); } }
  function withNode(C, i, n, fn) { C.own.set(n, i); try { return fn(); } finally { C.own.delete(n); } }

  /* ---------------------------------------------------------------- production */
  function nodeProd(C, n) {
    if (C.np.has(n)) return C.np.get(n);
    const v = vec();
    C.g.node.get(n).tiles.forEach((tid) => {
      const t = C.g.tile.get(tid);
      if (!t || t.terrain === 'desert' || !t.number) return;
      v[t.terrain] += PIPS[t.number] * (t.id === C.S.board.robber ? 0.3 : 1);
    });
    C.np.set(n, v);
    return v;
  }
  function playerProd(C, i) {
    const key = 'prod' + i; if (C.memo[key]) return C.memo[key];
    const p = C.S.players[i]; let v = vec();
    p.settlements.forEach((n) => { v = add(v, nodeProd(C, n)); });
    p.cities.forEach((n) => { v = add(v, nodeProd(C, n), 2); });
    C.memo[key] = v; return v;
  }
  function weights(C, i) {
    const key = 'w' + i; if (C.memo[key]) return C.memo[key];
    const p = C.S.players[i]; const st = styleOf(p); const w = {};
    R.forEach((k) => {
      let x = (st.w[k] || 1) * C.g.scarcity[k];
      if (p.vp <= 4 && (k === 'wood' || k === 'brick')) x *= 1.08;
      if (p.vp >= 6 && (k === 'ore' || k === 'grain')) x *= 1.1;
      w[k] = x;
    });
    C.memo[key] = w; return w;
  }
  function prodValue(C, i, P, ports) {
    const w = weights(C, i); const st = styleOf(C.S.players[i]);
    let v = 0; let kinds = 0;
    R.forEach((k) => {
      const x = P[k];
      if (x >= 1) kinds++;
      const gx = ports.includes(k) ? x * (1 + 0.04 * st.port) : (x <= 7 ? x : x <= 12 ? 7 + (x - 7) * 0.8 : 11 + (x - 12) * 0.6);
      v += w[k] * gx;
    });
    v += st.diversity * [0, 0, 0.5, 1.2, 2, 2.8][kinds];
    if (ports.includes('any')) v *= 1 + 0.025 * st.port;
    return v;
  }
  function prodToVP(C, dv) { return dv * (C.N / 36) * C.horizon / CARDS_PER_VP; }
  function portBonus(C, i, type, P, ports) {
    if (ports.includes(type)) return 0;
    const st = styleOf(C.S.players[i]);
    if (type === 'any') return (ports.some((t) => t !== 'any') ? 0.5 : 1.4) * st.port;
    return Math.max(0, P[type] - 2) * 0.32 * st.port;
  }
  function rates(C, i) { const P = playerProd(C, i); const o = {}; R.forEach((k) => { o[k] = P[k] * C.N / 36; }); return o; }
  function ratios(p, bank) {
    const o = {};
    R.forEach((k) => { o[k] = p.ports.includes(k) ? 2 : p.ports.includes('any') ? 3 : 4; });
    return o;
  }

  /* ---------------------------------------------------------------- affordability */
  function tradePlan(h, cost, ratio, bank) {
    const hh = vec(h); const need = [];
    R.forEach((k) => { const d = (cost[k] || 0) - hh[k]; for (let j = 0; j < d; j++) need.push(k); });
    if (!need.length) return [];
    const avail = {}; R.forEach((k) => { avail[k] = Math.max(0, hh[k] - (cost[k] || 0)); });
    const got = vec(); const trades = [];
    for (const k of need) {
      if (bank && (bank[k] || 0) - got[k] < 1) return null;
      const src = R.filter((j) => j !== k && avail[j] >= ratio[j]).sort((a, b) => ratio[a] - ratio[b] || avail[b] - avail[a])[0];
      if (!src) return null;
      avail[src] -= ratio[src]; got[k]++;
      trades.push({ give: src, get: k, rate: ratio[src] });
    }
    return trades;
  }
  function eta(h, cost, rate, ratio) {
    if (covers(h, cost)) return 0;
    const plan = tradePlan(h, cost, ratio);
    if (plan) return 0.25 + plan.length * 0.15;
    const soft = {}; R.forEach((k) => { soft[k] = Math.max(2, ratio[k] - 0.6); });
    const f = (t) => {
      let d = 0; let s = 0;
      R.forEach((k) => { const a = (h[k] || 0) + rate[k] * t; const c = cost[k] || 0; if (a < c) d += c - a; else s += (a - c) / soft[k]; });
      return d - s;
    };
    let prev = f(0);
    for (let t = 1; t <= 30; t++) { const cur = f(t); if (cur <= 0) return t - 1 + prev / Math.max(1e-6, prev - cur); prev = cur; }
    return 30;
  }

  /* ---------------------------------------------------------------- reachability */
  // 0-1 BFS from player i's network. Returns Map node -> {d, path:[edgeIds to build]}.
  function reach(C, i, maxD) {
    const p = C.S.players[i];
    const dist = new Map();
    const dq = [];
    const starts = new Set([...p.settlements, ...p.cities]);
    C.road.forEach((o, eid) => { if (o !== i) return; const e = C.g.edge.get(eid); [e.a, e.b].forEach((n) => { const ow = C.own.get(n); if (ow === undefined || ow === i) starts.add(n); }); });
    starts.forEach((n) => { dist.set(n, { d: 0, path: [] }); dq.push(n); });
    while (dq.length) {
      const u = dq.shift(); const du = dist.get(u);
      const ou = C.own.get(u);
      if (ou !== undefined && ou !== i) continue;
      for (const e of C.g.nodeEdges.get(u)) {
        const ro = C.road.get(e.id);
        if (ro !== undefined && ro !== i) continue;
        const cost = ro === i ? 0 : 1;
        const nd = du.d + cost;
        if (nd > maxD) continue;
        const v = e.a === u ? e.b : e.a;
        const cur = dist.get(v);
        if (!cur || nd < cur.d) {
          dist.set(v, { d: nd, path: cost ? du.path.concat(e.id) : du.path });
          if (cost) dq.push(v); else dq.unshift(v);
        }
      }
    }
    return dist;
  }
  function networkDist(C, i, maxD) { const m = new Map(); reach(C, i, maxD).forEach((v, k) => m.set(k, v.d)); return m; }

  /* ---------------------------------------------------------------- longest road */
  function lrVP(C, i, len, lens) {
    const others = Math.max(0, ...lens.filter((_, j) => j !== i));
    const holder = C.S.longest;
    if (len >= 5 && (len > others || (holder === i && len >= others))) return 2 * clamp(0.55 + 0.15 * (len - others), 0.55, 1);
    const target = Math.max(5, others + 1);
    const gap = target - len;
    return 2 * 0.36 * Math.pow(0.6, Math.max(0, gap - 1));
  }
  function lrGain(C, i, edges) {
    const before = lrVP(C, i, C.lens[i], C.lens);
    const len = withRoads(C, i, edges, () => roadLen(C, i));
    const lens = C.lens.slice(); lens[i] = len;
    return { gain: lrVP(C, i, len, lens) - before, len };
  }
  function roadPush(C) {
    if (C.memo.roadPush !== undefined) return C.memo.roadPush;
    const i = C.mi; const me = C.me; let best = null;
    if (me.roads.length >= LIMIT.road) { C.memo.roadPush = null; return null; }
    const cands = legalRoads(C, i);
    for (const e1 of cands) {
      const one = lrGain(C, i, [e1]);
      const score1 = one.gain;
      if (!best || score1 > best.gain) best = { gain: score1, edges: [e1], len: one.len };
      if (me.roads.length + 2 > LIMIT.road) continue;
      withRoads(C, i, [e1], () => {
        const e = C.g.edge.get(e1);
        [e.a, e.b].forEach((n) => {
          C.g.nodeEdges.get(n).forEach((x) => {
            if (x.id === e1 || !canRoad(C, i, x.id)) return;
            const two = lrGain(C, i, [x.id]);
            // lrGain measured against current C.lens (without e1) inside withRoads -> recompute relative
            const g2 = two.gain;
            if (g2 > (best ? best.gain : 0) + 0.15) best = { gain: g2, edges: [e1, x.id], len: two.len };
          });
        });
      });
    }
    if (best && best.gain > 0.05) {
      const v = best.gain * C.st.lr;
      C.memo.roadPush = { kind: 'road', edges: best.edges, len: best.len, cost: mul(COST.road, best.edges.length), value: v * C.cat.road, steps: best.edges.map((e) => ({ type: 'road', edge: e })), why: `push road to ${best.len}` };
    } else C.memo.roadPush = null;
    return C.memo.roadPush;
  }

  /* ---------------------------------------------------------------- development cards */
  function myDevCount(C, card) { return C.me.dev.filter((c) => c === card).length + C.me.newDev.filter((c) => c === card).length; }
  function armyVP(C) {
    const me = C.me; const S = C.S;
    const others = Math.max(0, ...S.players.filter((_, j) => j !== C.mi).map((p) => p.knights));
    if (S.largest === C.mi) return others >= me.knights - 1 ? 0.75 : 0.2;
    const need = Math.max(3, others + 1) - me.knights - myDevCount(C, 'knight');
    if (need <= 0) return 0.35;
    return 2 * 0.5 * Math.pow(0.6, need - 1);
  }
  function devValue(C) {
    const pool = C.S.devPool || DECK; const n = Math.max(1, total2(pool)); const st = C.st;
    const p = (k) => (pool[k] || 0) / n;
    const vVP = 1 + (st === STYLES.scholar ? 0.35 : 0);
    const vKnight = 0.3 + st.army * armyVP(C);
    const rp = roadPush(C);
    const vRoad = 0.25 + (rp ? Math.min(1, rp.value) * 0.4 : 0) + (C.me.roads.length < 13 ? 0.15 : -0.2);
    const vPlenty = 0.5;
    const vMono = 0.2 * (C.N - 1) + 0.1;
    return p('victory') * vVP + p('knight') * vKnight + p('road') * vRoad + p('plenty') * vPlenty + p('monopoly') * vMono;
  }

  /* ---------------------------------------------------------------- denial and contest */
  function contest(C, n, d) {
    let f = 1;
    C.S.players.forEach((_, q) => {
      if (q === C.mi) return;
      const od = C.oppDist[q] && C.oppDist[q].get(n);
      if (od === undefined) return;
      if (od < d) f = Math.min(f, 0.5);
      else if (od === d && d > 0) f = Math.min(f, 0.75);
    });
    return f;
  }
  function denial(C, n) {
    let d = 0;
    C.S.players.forEach((p, q) => {
      if (q === C.mi) return;
      const adjRoads = C.g.nodeEdges.get(n).filter((e) => C.road.get(e.id) === q).length;
      if (adjRoads >= 2 && C.lens[q] >= 3) {
        const after = withNode(C, C.mi, n, () => roadLen(C, q));
        const red = C.lens[q] - after;
        if (red > 0) {
          const othersMax = Math.max(0, ...C.lens.filter((_, j) => j !== q));
          const lost = C.S.longest === q && (after < 5 || after <= othersMax);
          d += red * 0.08 + (lost ? 1.7 * threatW(C, q) : 0);
        }
      }
      const od = C.oppDist[q] && C.oppDist[q].get(n);
      if (od !== undefined && od <= 1) d += 0.12 * threatW(C, q) * (C.g.raw.get(n).pips / 10);
    });
    return d;
  }

  /* ---------------------------------------------------------------- goals */
  function goals(C) {
    if (C.memo.goals) return C.memo.goals;
    const out = []; const i = C.mi; const me = C.me; const st = C.st;
    const P = playerProd(C, i); const base = prodValue(C, i, P, me.ports);
    if (me.cities.length < LIMIT.city) {
      me.settlements.forEach((n) => {
        const dv = prodValue(C, i, add(P, nodeProd(C, n)), me.ports) - base;
        let v = 1 + prodToVP(C, dv);
        if (me.settlements.length >= LIMIT.settlement) v += 0.4;
        out.push({ kind: 'city', node: n, cost: COST.city, value: v * C.cat.city, steps: [{ type: 'city', node: n }], why: `city on ${n}` });
      });
    }
    if (me.settlements.length < LIMIT.settlement) {
      const map = reach(C, i, 4);
      map.forEach((info, n) => {
        if (!freeNode(C, n)) return;
        if (me.roads.length + info.path.length > LIMIT.road) return;
        const np = nodeProd(C, n); const newPorts = C.g.nodePorts.get(n);
        const ports = uniq(me.ports.concat(newPorts)); const P2 = add(P, np);
        const dv = prodValue(C, i, P2, ports) - base;
        let pb = 0; newPorts.forEach((t) => { pb += portBonus(C, i, t, P2, me.ports); });
        let v = 1 + prodToVP(C, dv + pb);
        if (info.path.length) v += lrGain(C, i, info.path).gain * st.lr * 0.8;
        v += denial(C, n);
        const avail = Math.pow(0.9, Math.max(0, info.path.length - 1)) * contest(C, n, info.path.length);
        const cost = add(COST.settlement, mul(COST.road, info.path.length));
        const steps = info.path.map((e) => ({ type: 'road', edge: e })).concat([{ type: 'settlement', node: n }]);
        out.push({ kind: 'settlement', node: n, path: info.path, cost, value: v * avail * C.cat.settlement, steps, why: `settle ${n} (${info.path.length} roads)` });
      });
    }
    if (C.S.deckCount > 0) out.push({ kind: 'dev', cost: COST.dev, value: devValue(C) * C.cat.dev, steps: [{ type: 'buyDev' }], why: 'progress card' });
    const rp = roadPush(C); if (rp) out.push(rp);
    C.memo.goals = out;
    return out;
  }
  function rank(C, h) {
    const rate = rates(C, C.mi); const ratio = ratios(C.me);
    return goals(C).map((g) => {
      const t = eta(h, g.cost, rate, ratio);
      return { ...g, eta: t, u: g.value / (t + TIME_K) };
    }).sort((a, b) => b.u - a.u);
  }
  function handRisk(h) { const n = total(h); return n > 7 ? 0.42 * Math.floor(n / 2) * 0.16 : 0; }
  function handScore(C, h) {
    const list = rank(C, h);
    return (list[0] ? list[0].u : 0) + (list[1] ? list[1].u * 0.35 : 0) + (list[2] ? list[2].u * 0.15 : 0) - handRisk(h);
  }

  /* ---------------------------------------------------------------- win-this-turn search */
  function winNow(C) {
    const me = C.me; const S = C.S; const need = 10 - me.vp - (me.hiddenVp || 0);
    if (need <= 0 || need > 4) return null;
    const opts = [];
    const devFree = !S.devPlayed;
    if (me.cities.length < LIMIT.city) {
      const cs = me.settlements.slice().sort((a, b) => total(nodeProd(C, b)) - total(nodeProd(C, a)));
      cs.slice(0, 2).forEach((n) => opts.push({ vp: 1, cost: COST.city, acts: [{ type: 'city', node: n }], tag: 'city' }));
    }
    const pieces = LIMIT.settlement - me.settlements.length;
    if (pieces > 0) {
      const map = reach(C, C.mi, 1);
      const spots = [];
      map.forEach((info, n) => { if (freeNode(C, n) && me.roads.length + info.path.length <= LIMIT.road) spots.push({ n, path: info.path }); });
      spots.sort((a, b) => a.path.length - b.path.length || total(nodeProd(C, b.n)) - total(nodeProd(C, a.n)));
      spots.slice(0, 4).forEach((s) => opts.push({ vp: 1, cost: add(COST.settlement, mul(COST.road, s.path.length)), acts: s.path.map((e) => ({ type: 'road', edge: e })).concat([{ type: 'settlement', node: s.n }]), node: s.n, tag: 'settlement' }));
    }
    if (S.longest !== C.mi) {
      const rp = roadPush(C);
      if (rp) {
        const others = Math.max(0, ...C.lens.filter((_, j) => j !== C.mi));
        if (rp.len >= 5 && rp.len > others) opts.push({ vp: 2, cost: rp.cost, acts: rp.steps, tag: 'lr' });
      }
    }
    if (devFree && me.dev.includes('knight') && S.largest !== C.mi) {
      const others = Math.max(0, ...S.players.filter((_, j) => j !== C.mi).map((p) => p.knights));
      if (me.knights + 1 >= 3 && me.knights + 1 > others) opts.push({ vp: 2, cost: vec(), acts: [{ type: 'play', card: 'knight' }], dev: true, tag: 'la' });
    }
    const plenty = devFree && me.dev.includes('plenty');
    const ratio = ratios(me); const h = me.r;
    let best = null;
    const n = opts.length;
    for (let mask = 1; mask < (1 << n); mask++) {
      let vp = 0; let cost = vec(); let devs = 0; let setts = 0; const nodes = []; let cities = 0; const acts = [];
      for (let j = 0; j < n; j++) {
        if (!(mask & (1 << j))) continue;
        const o = opts[j]; vp += o.vp; cost = add(cost, o.cost); if (o.dev) devs++;
        if (o.tag === 'settlement') { setts++; nodes.push(o.node); }
        if (o.tag === 'city') cities++;
        acts.push(o);
      }
      if (vp < need || devs > 1 || setts > pieces || me.cities.length + cities > LIMIT.city) continue;
      if (nodes.length > 1 && nodes.some((a, x) => nodes.some((b, y) => x !== y && (a === b || C.g.nbrs.get(a).includes(b))))) continue;
      const wild = plenty && !devs ? 2 : 0;
      let feasible = false; let trades = null; let plentyPick = null;
      if (covers(h, cost)) { feasible = true; trades = []; } else {
        trades = tradePlan(h, cost, ratio, S.bank);
        if (trades) feasible = true;
        else if (wild) {
          const deficits = []; R.forEach((k) => { for (let d = (cost[k] || 0) - (h[k] || 0); d > 0; d--) deficits.push(k); });
          const pick = deficits.slice(0, 2); while (pick.length < 2) pick.push(R.slice().sort((a, b) => (S.bank[b] || 0) - (S.bank[a] || 0))[0]);
          const h2 = add(h, pick.reduce((o, k) => { o[k] = (o[k] || 0) + 1; return o; }, {}));
          if (covers(h2, cost) || tradePlan(h2, cost, ratio, S.bank)) { feasible = true; plentyPick = pick; }
        }
      }
      if (!feasible) continue;
      const price = total(cost) + (trades ? trades.length : 0) * 2;
      if (!best || price < best.price) best = { price, acts, trades, plentyPick, cost };
    }
    if (!best) return null;
    const la = best.acts.find((o) => o.tag === 'la');
    if (la) return { type: 'play', card: 'knight', why: 'win: claim Largest Army' };
    if (best.plentyPick) return { type: 'play', card: 'plenty', pick: best.plentyPick, why: 'win: Year of Plenty' };
    if (best.trades && best.trades.length) { const t = best.trades[0]; return { type: 'bank', give: t.give, get: t.get, rate: t.rate, why: 'win: trade' }; }
    const order = ['lr', 'settlement', 'city'];
    for (const tag of order) {
      const o = best.acts.find((a) => a.tag === tag);
      if (o) return { ...o.acts[0], why: 'win: ' + tag };
    }
    return null;
  }

  /* ---------------------------------------------------------------- robber */
  function robberEval(C, tile) {
    const t = tile; if (t.id === C.S.board.robber) return null;
    const pips = t.terrain === 'desert' || !t.number ? 0 : PIPS[t.number];
    let block = 0; let mine = 0; const victims = new Set();
    t.nodes.forEach((n) => {
      const o = C.own.get(n); if (o === undefined) return;
      const m = C.S.players[o].cities.includes(n) ? 2 : 1;
      if (o === C.mi) mine += pips * m;
      else { block += pips * m * threatW(C, o); victims.add(o); }
    });
    let bestV = null; let stealV = 0;
    victims.forEach((q) => {
      const p = C.S.players[q]; if (!p.cards) return;
      const est = p.r || vec(); const n = Math.max(1, total(est));
      const need = rank(C, C.me.r)[0];
      let use = 0; if (need) R.forEach((k) => { if ((need.cost[k] || 0) > (C.me.r[k] || 0)) use += (est[k] || 0) / n; });
      const v = threatW(C, q) * (0.55 + 0.07 * Math.min(p.cards, 10)) + use * 0.5;
      if (v > stealV) { stealV = v; bestV = q; }
    });
    const score = block * 0.11 * (0.7 + 0.3 * C.st.aggro) + stealV - mine * 0.3 + (victims.size ? 0 : -2.5);
    return { tile: t.id, victim: bestV, score, mine, block };
  }
  function robber(S) {
    const C = ctx(S); let best = null;
    S.board.tiles.forEach((t) => { const e = robberEval(C, t); if (e && (!best || e.score > best.score)) best = e; });
    return best ? { tile: best.tile, victim: best.victim, score: best.score } : null;
  }

  /* ---------------------------------------------------------------- discard */
  function discard(S, n) {
    // Greedy: repeatedly drop the card whose loss hurts the plan least (measured by handScore),
    // breaking ties toward resources the bot produces plentifully.
    const C = ctx(S); const h = vec(C.me.r); const out = vec(); const rate = rates(C, C.mi); const w = weights(C, C.mi);
    for (let s = 0; s < n; s++) {
      let best = null;
      R.forEach((k) => {
        if (h[k] <= 0) return;
        const h2 = vec(h); h2[k]--;
        const v = handScore(C, h2) + rate[k] * 0.02 - w[k] * 0.01;
        if (!best || v > best.v) best = { k, v };
      });
      if (!best) break;
      h[best.k]--; out[best.k]++;
    }
    return out;
  }

  /* ---------------------------------------------------------------- dev card plays */
  function knightValue(C, preRoll) {
    const me = C.me; const S = C.S;
    if (S.devPlayed || !me.dev.includes('knight')) return -Infinity;
    let best = null; S.board.tiles.forEach((t) => { const e = robberEval(C, t); if (e && (!best || e.score > best.score)) best = e; });
    const cur = C.g.tile.get(S.board.robber);
    let onMe = 0;
    if (cur && cur.number) cur.nodes.forEach((n) => { if (C.own.get(n) === C.mi) onMe += PIPS[cur.number] * (me.cities.includes(n) ? 2 : 1); });
    let v = (best ? Math.max(0, best.score) : 0) * 0.45 + onMe * (preRoll ? 0.16 : 0.06);
    const others = Math.max(0, ...S.players.filter((_, j) => j !== C.mi).map((p) => p.knights));
    if (S.largest !== C.mi && me.knights + 1 >= 3 && me.knights + 1 > others) v += 2.2;
    else if (S.largest === C.mi && others >= me.knights) v += 0.9;
    else if (S.largest !== C.mi && me.knights + 1 >= others) v += 0.35 * C.st.army;
    v += C.st.aggro * 0.3;
    if (best && best.score < 0.4 && onMe === 0 && v < 2) v -= 0.6;
    return v;
  }
  function plentyChoice(C) {
    const h = C.me.r; const base = handScore(C, h); let best = null;
    for (let a = 0; a < 5; a++) for (let b = a; b < 5; b++) {
      const ka = R[a]; const kb = R[b];
      const take = vec(); take[ka]++; take[kb]++;
      if (R.some((k) => take[k] > (C.S.bank[k] || 0))) continue;
      const v = handScore(C, add(h, take)) - base;
      if (!best || v > best.v) best = { v, pick: [ka, kb] };
    }
    return best;
  }
  function monopolyChoice(C) {
    const h = C.me.r; const base = handScore(C, h); let best = null;
    R.forEach((k) => {
      let haul = 0; C.S.players.forEach((p, q) => { if (q !== C.mi) haul += (p.r && p.r[k]) || 0; });
      const h2 = vec(h); h2[k] += haul;
      const v = handScore(C, h2) - base + haul * 0.07;
      if (!best || v > best.v) best = { v, pick: k, haul };
    });
    return best;
  }
  function devPlay(C) {
    const me = C.me; const S = C.S; if (S.devPlayed) return null;
    const kv = me.dev.includes('knight') ? knightValue(C, false) : -Infinity;
    const opts = [];
    if (kv > 1.05) opts.push({ v: kv, act: { type: 'play', card: 'knight', why: 'knight' } });
    if (me.dev.includes('monopoly')) {
      const m = monopolyChoice(C);
      if (m && m.haul >= 2.5 && (m.v > 0.3 || m.haul >= 4.5)) opts.push({ v: m.v + 0.4, act: { type: 'play', card: 'monopoly', pick: m.pick, why: `monopoly ${m.pick} ~${m.haul.toFixed(1)}` } });
    }
    if (me.dev.includes('plenty')) {
      const p = plentyChoice(C);
      if (p && p.v > 0.3) opts.push({ v: p.v + 0.2, act: { type: 'play', card: 'plenty', pick: p.pick, why: 'plenty' } });
    }
    if (me.dev.includes('road') && me.roads.length < LIMIT.road) {
      const list = rank(C, me.r);
      const sg = list.find((g) => g.kind === 'settlement' && g.path.length >= 1);
      const rp = roadPush(C);
      let v = 0;
      if (sg) v = Math.max(v, sg.value * Math.min(2, sg.path.length) / Math.max(2, sg.path.length + 1) * 0.6);
      if (rp) v = Math.max(v, rp.value * 0.9);
      if (v > 0.55) opts.push({ v, act: { type: 'play', card: 'road', why: 'road building' } });
    }
    if (!opts.length) return null;
    return opts.sort((a, b) => b.v - a.v)[0].act;
  }

  /* ---------------------------------------------------------------- free roads */
  function freeRoad(C) {
    const list = rank(C, add(C.me.r, mul(COST.road, 2)));
    const sg = list.find((g) => g.kind === 'settlement' && g.path.length >= 1);
    const rp = roadPush(C);
    if (sg && (!rp || sg.u >= rp.value * 0.8)) return { type: 'road', edge: sg.path[0], why: 'free road toward ' + sg.node };
    if (rp) return { type: 'road', edge: rp.edges[0], why: 'free road for length' };
    const legal = legalRoads(C, C.mi);
    if (!legal.length) return { type: 'skipFree' };
    let best = null;
    legal.forEach((eid) => {
      const e = C.g.edge.get(eid);
      const v = Math.max(...[e.a, e.b].map((n) => C.g.nbrs.get(n).concat([n]).filter((m) => freeNode(C, m)).reduce((s, m) => Math.max(s, C.g.raw.get(m).pips), 0)));
      if (!best || v > best.v) best = { v, eid };
    });
    return { type: 'road', edge: best.eid, why: 'free road (best open ground)' };
  }

  /* ---------------------------------------------------------------- main turn decision */
  function stepFor(C, g, h) {
    const s = g.steps[0];
    const cost = s.type === 'road' ? COST.road : s.type === 'settlement' ? COST.settlement : s.type === 'city' ? COST.city : COST.dev;
    return { step: s, cost, affordable: covers(h, cost) };
  }
  function legalStep(C, s) {
    if (s.type === 'road') return canRoad(C, C.mi, s.edge) && C.me.roads.length < LIMIT.road;
    if (s.type === 'settlement') return legalSettle(C, C.mi, s.node) && C.me.settlements.length < LIMIT.settlement;
    if (s.type === 'city') return C.me.settlements.includes(s.node) && C.me.cities.length < LIMIT.city;
    if (s.type === 'buyDev') return C.S.deckCount > 0;
    return true;
  }
  function decide(S) {
    const C = ctx(S); const me = C.me; const flags = S.flags || {};
    if (S.phase === 'roll') {
      if (!S.devPlayed && me.dev.includes('knight')) {
        const w = winNow(C);
        if (w && w.type === 'play' && w.card === 'knight') return w;
        const kv = knightValue(C, true);
        if (kv > 0.95) return { type: 'play', card: 'knight', why: `pre-roll knight (${kv.toFixed(2)})` };
      }
      return { type: 'roll' };
    }
    if (S.phase !== 'build') return { type: 'end' };
    if (S.freeRoads > 0) return freeRoad(C);

    const win = winNow(C);
    if (win) return win;

    const dp = devPlay(C);
    if (dp) return dp;

    const h = vec(me.r);
    const list = rank(C, h).filter((g) => legalStep(C, g.steps[0]));
    const goal = list[0];
    if (goal) {
      const st = stepFor(C, goal, h);
      if (st.affordable) return { ...st.step, why: `${C.st.label}: ${goal.why} (u ${goal.u.toFixed(2)})` };
      // bank trades: complete the whole goal now, or the decisive final step
      if ((flags.bankTrades || 0) < 6) {
        const full = tradePlan(h, goal.cost, ratios(me), S.bank);
        const finalStep = goal.steps.length === 1;
        const plan = full && full.length ? full : (finalStep ? null : (total(h) > 7 ? tradePlan(h, st.cost, ratios(me), S.bank) : null));
        if (plan && plan.length && plan.length <= 3) { const t = plan[0]; return { type: 'bank', give: t.give, get: t.get, rate: t.rate, why: `trade toward ${goal.why}` }; }
      }
    }
    // opportunistic builds that do not meaningfully delay the main goal
    const opp = opportunistic(C, h, goal, list);
    if (opp) return opp;
    // domestic trade
    if ((flags.proposals || 0) < 2 && goal) {
      const offers = proposals(C, h, goal);
      if (offers.length) return { type: 'propose', offers, why: `trade for ${goal.why}` };
    }
    // hand management against the seven
    if (total(h) > 7) {
      const dump = dumpHand(C, h, goal, flags);
      if (dump) return dump;
    }
    return { type: 'end', why: goal ? `saving for ${goal.why}` : 'nothing to do' };
  }
  function opportunistic(C, h, goal, list) {
    const rate = rates(C, C.mi); const ratio = ratios(C.me);
    const seen = new Set(); let best = null;
    const gEta = goal ? goal.eta : 0;
    for (const g of list) {
      if (goal && g === goal) continue;
      const s = g.steps[0]; const key = s.type + (s.node || s.edge || '');
      if (seen.has(key)) continue; seen.add(key);
      const sc = stepFor(C, g, h); if (!sc.affordable) continue;
      const h2 = add(h, sc.cost, -1);
      const delay = goal ? Math.max(0, eta(h2, goal.cost, rate, ratio) - gEta) : 0;
      const lossV = goal ? goal.value * delay / (gEta + TIME_K + delay) : 0;
      const stepShare = g.steps.length === 1 ? 1 : 0.55 / g.steps.length;
      const gainV = g.value * stepShare;
      const margin = total(h) > 7 ? 0 : 0.12;
      const net = gainV - lossV - margin;
      if (gainV > 0.2 && net > 0 && (!best || net > best.net)) best = { net, act: { ...s, why: `opportunistic ${g.why}` } };
    }
    return best ? best.act : null;
  }
  function proposals(C, h, goal) {
    const deficits = R.filter((k) => (goal.cost[k] || 0) > (h[k] || 0));
    if (!deficits.length) return [];
    const surplus = R.filter((k) => (h[k] || 0) > (goal.cost[k] || 0));
    const base = handScore(C, h); const out = [];
    deficits.forEach((want) => {
      surplus.forEach((give) => {
        const spare = h[give] - (goal.cost[give] || 0);
        [1, 2].forEach((n) => {
          if (n > spare) return;
          const g = vec(); g[give] = n; const w = vec(); w[want] = 1;
          const gain = handScore(C, add(add(h, g, -1), w)) - base;
          if (gain > 0.1) out.push({ give: g, want: w, gain });
        });
      });
      if (surplus.length >= 2) {
        const [a, b] = surplus.sort((x, y) => (h[y] - (goal.cost[y] || 0)) - (h[x] - (goal.cost[x] || 0)));
        const g = vec(); g[a] = 1; g[b] = 1; const w = vec(); w[want] = 1;
        const gain = handScore(C, add(add(h, g, -1), w)) - base;
        if (gain > 0.1) out.push({ give: g, want: w, gain });
      }
    });
    // cheaper offers first (1-for-1 before 2-for-1) among those that help
    return out.sort((a, b) => total(a.give) - total(b.give) || b.gain - a.gain).slice(0, 4);
  }
  function dumpHand(C, h, goal, flags) {
    const list = rank(C, h).filter((g) => legalStep(C, g.steps[0]));
    for (const g of list) {
      const sc = stepFor(C, g, h);
      if (sc.affordable && g.value > 0.12) return { ...sc.step, why: `spend before a seven: ${g.why}` };
    }
    if ((flags.bankTrades || 0) >= 6) return null;
    const ratio = ratios(C.me); const want = goal ? R.filter((k) => (goal.cost[k] || 0) > (h[k] || 0)) : [];
    const get = want[0] || R.slice().sort((a, b) => (h[a] || 0) - (h[b] || 0))[0];
    const give = R.filter((k) => k !== get && h[k] >= ratio[k] && (h[k] - ratio[k]) >= ((goal && goal.cost[k]) || 0)).sort((a, b) => (h[b] - ratio[b]) - (h[a] - ratio[a]))[0];
    if (give && (C.S.bank[get] || 0) > 0 && ratio[give] <= 4) return { type: 'bank', give, get, rate: ratio[give], why: 'trim hand before a seven' };
    return null;
  }

  /* ---------------------------------------------------------------- domestic trade acceptance */
  // offer is from the proposer's view: proposer gives `give`, wants `want`. S is the acceptor's view.
  function acceptTrade(S, offer, fromIndex) {
    const C = ctx(S); const h = vec(C.me.r);
    if (!covers(h, offer.want)) return -Infinity;
    const qVP = C.exp[fromIndex];
    if (qVP >= 8.5) return -5;
    const h2 = add(add(h, offer.give), offer.want, -1);
    const gain = handScore(C, h2) - handScore(C, h);
    const lead = Math.max(0, qVP - C.exp[C.mi]);
    const margin = 0.08 * C.st.trade + lead * 0.07 + (qVP >= 7 ? 0.3 : 0) + Math.max(0, total(offer.want) - total(offer.give)) * 0.05;
    return gain - margin;
  }

  /* ---------------------------------------------------------------- setup placement */
  // Opening valuation is production-first: total pips dominate, archetype preferences only tilt the choice.
  function setupProd(C, P, ports) {
    const st = C.st; let v = 0; let kinds = 0;
    R.forEach((k) => {
      const x = P[k]; if (x >= 1) kinds++;
      const w = (1 + ((st.w[k] || 1) - 1) * 0.45) * Math.sqrt(C.g.scarcity[k]);
      const gx = ports.includes(k) ? x * 1.05 : (x <= 8 ? x : 8 + (x - 8) * 0.75);
      v += w * gx;
    });
    v += [0, 0, 0.6, 1.4, 2.3, 3.0][kinds] * (0.7 + 0.3 * st.diversity);
    return v;
  }
  function soloValue(C, n) {
    const raw = C.g.raw.get(n); const ports = C.g.nodePorts.get(n);
    let v = setupProd(C, raw.prod, ports) + raw.nums * 0.2;
    ports.forEach((t) => { v += portBonus(C, C.mi, t, raw.prod, []) * 0.8; });
    return v;
  }
  function expansion(C, n, blocked) {
    // best open spots two roads away, the next settlement after setup
    let best = 0; let second = 0;
    C.g.nbrs.get(n).forEach((m) => {
      C.g.nbrs.get(m).forEach((k) => {
        if (k === n || blocked.has(k) || C.own.has(k) || C.g.nbrs.get(k).some((z) => C.own.has(z) || blocked.has(z))) return;
        const raw = C.g.raw.get(k); const v = raw.pips + raw.kinds;
        if (v > best) { second = best; best = v; } else if (v > second) second = v;
      });
    });
    return best * 0.14 + second * 0.05;
  }
  function pairValue(C, n1, n2, startBonus) {
    const r1 = C.g.raw.get(n1); const r2 = C.g.raw.get(n2);
    const ports = uniq(C.g.nodePorts.get(n1).concat(C.g.nodePorts.get(n2)));
    const P = add(r1.prod, r2.prod);
    let v = setupProd(C, P, ports) + (r1.nums + r2.nums) * 0.15;
    ports.forEach((t) => { v += portBonus(C, C.mi, t, P, []) * 0.8; });
    const blocked = new Set([n1, n2]);
    v += expansion(C, n1, blocked) + expansion(C, n2, blocked);
    // shared numbers add variance; distinct numbers smooth income
    const nums1 = new Set(); const nums2 = new Set();
    C.g.node.get(n1).tiles.forEach((t) => { const x = C.g.tile.get(t); if (x.number) nums1.add(x.number); });
    C.g.node.get(n2).tiles.forEach((t) => { const x = C.g.tile.get(t); if (x.number) nums2.add(x.number); });
    nums2.forEach((x) => { if (nums1.has(x)) v -= 0.3; });
    if (C.st === STYLES.roadrunner) { const d = hop(C, n1, n2, 4); if (d <= 4) v += (5 - d) * 0.6; }
    if (startBonus) {
      const w = weights(C, C.mi);
      C.g.node.get(n2).tiles.forEach((tid) => { const t = C.g.tile.get(tid); if (t.terrain !== 'desert') v += 0.2 * w[t.terrain] * ((t.terrain === 'wood' || t.terrain === 'brick') ? 1.3 : 1); });
    }
    return v;
  }
  function hop(C, a, b, max) {
    const seen = new Map([[a, 0]]); const q = [a];
    while (q.length) { const u = q.shift(); const d = seen.get(u); if (u === b) return d; if (d >= max) continue; C.g.nbrs.get(u).forEach((v) => { if (!seen.has(v)) { seen.set(v, d + 1); q.push(v); } }); }
    return 99;
  }
  function genericPick(C, blocked) {
    let best = null; let bv = -1;
    C.g.node.forEach((_, n) => {
      if (blocked.has(n) || C.own.has(n) || C.g.nbrs.get(n).some((z) => C.own.has(z) || blocked.has(z))) return;
      const raw = C.g.raw.get(n); const v = raw.pips + raw.kinds * 1.2 + (C.g.nodePorts.get(n).length ? 0.5 : 0);
      if (v > bv) { bv = v; best = n; }
    });
    return best;
  }
  function setupSettlement(S) {
    const C = ctx(S); const me = C.me;
    const free = []; C.g.node.forEach((_, n) => { if (freeNode(C, n)) free.push(n); });
    if (!free.length) return null;
    if (me.settlements.length >= 1) {
      const first = me.settlements[0];
      let best = null; let bv = -Infinity;
      free.forEach((n) => { const v = pairValue(C, first, n, true); if (v > bv) { bv = v; best = n; } });
      return best;
    }
    // first settlement: look ahead through the opponents' picks before our second placement
    const order = S.setupOrder || []; const step = S.setupStep || 0;
    let between = 0;
    for (let k = step + 1; k < order.length; k++) { if (order[k] === C.mi) break; between++; }
    const cands = free.slice().sort((a, b) => soloValue(C, b) - soloValue(C, a)).slice(0, 14);
    let best = null; let bv = -Infinity;
    cands.forEach((n1) => {
      const blocked = new Set([n1]);
      for (let k = 0; k < between; k++) { const pk = genericPick(C, blocked); if (pk) blocked.add(pk); }
      let b2 = -Infinity;
      free.forEach((n2) => {
        if (blocked.has(n2) || C.g.nbrs.get(n2).some((z) => blocked.has(z))) return;
        const v = pairValue(C, n1, n2, true); if (v > b2) b2 = v;
      });
      const v = b2 + soloValue(C, n1) * 0.15;
      if (v > bv) { bv = v; best = n1; }
    });
    return best;
  }
  function setupRoad(S) {
    const C = ctx(S); const node = S.setupNode;
    const edges = C.g.nodeEdges.get(node).filter((e) => !C.road.has(e.id));
    let best = null; let bv = -Infinity;
    const other = C.me.settlements.find((x) => x !== node);
    edges.forEach((e) => {
      const v = e.a === node ? e.b : e.a;
      let score = 0;
      C.g.nbrs.get(v).forEach((w) => {
        if (w === node || !freeNode(C, w)) return;
        let s = soloValue(C, w);
        C.S.players.forEach((p, q) => { if (q !== C.mi && p.roads.some((r) => { const re = C.g.edge.get(r); return re.a === w || re.b === w; })) s *= 0.6; });
        score = Math.max(score, s);
        C.g.nbrs.get(w).forEach((x) => { if (x !== v && freeNode(C, x)) score = Math.max(score, soloValue(C, x) * 0.55); });
      });
      score += C.g.node.get(v).tiles.length * 0.4;
      if (other && C.st === STYLES.roadrunner) score += (6 - Math.min(6, hop(C, v, other, 6))) * 0.5;
      if (score > bv) { bv = score; best = e.id; }
    });
    return best;
  }

  /* ---------------------------------------------------------------- card tracking */
  // T is stored on the host game object. Hands are only observed through public changes;
  // robber thefts are applied probabilistically for everyone except the thief and victim.
  const Track = {
    sync(T, players) {
      players.forEach((p) => {
        if (!T.snap[p.id]) T.snap[p.id] = vec();
      });
      players.forEach((obs) => { if (!T.est[obs.id]) T.est[obs.id] = {}; players.forEach((p) => { if (!T.est[obs.id][p.id]) T.est[obs.id][p.id] = vec(T.snap[p.id]); }); });
      players.forEach((p) => {
        const diff = add(p.hand, T.snap[p.id], -1);
        if (total(diff) === 0 && R.every((k) => diff[k] === 0)) return;
        players.forEach((obs) => { T.est[obs.id][p.id] = fix(add(T.est[obs.id][p.id], diff), total(p.hand)); });
        T.snap[p.id] = vec(p.hand);
      });
    },
    steal(T, players, thiefId, victimId, res) {
      // call after sync() of the pre-theft state and after the theft was applied
      players.forEach((obs) => {
        const E = T.est[obs.id]; const victim = players.find((p) => p.id === victimId); const thief = players.find((p) => p.id === thiefId);
        if (obs.id === thiefId || obs.id === victimId || !res) {
          E[victimId] = vec(E[victimId]); E[thiefId] = vec(E[thiefId]);
          if (res) { E[victimId][res] -= 1; E[thiefId][res] += 1; }
        } else {
          const v = vec(E[victimId]); const n = total(v) || 1;
          R.forEach((k) => { const share = v[k] / n; E[victimId][k] -= share; E[thiefId][k] += share; });
        }
        E[victimId] = fix(E[victimId], total(victim.hand)); E[thiefId] = fix(E[thiefId], total(thief.hand));
      });
      players.forEach((p) => { T.snap[p.id] = vec(p.hand); });
    },
    view(T, obsId) { return T.est[obsId] || {}; }
  };
  function fix(v, tot) {
    const o = vec(v); R.forEach((k) => { if (o[k] < 0) o[k] = 0; });
    const s = total(o);
    if (tot <= 0) return vec();
    if (s <= 1e-9) { R.forEach((k) => { o[k] = tot / 5; }); return o; }
    if (Math.abs(s - tot) > 1e-6) R.forEach((k) => { o[k] = o[k] * tot / s; });
    return o;
  }
  function devPool(info) {
    // info: {knightsPlayed, roadPlayed, plentyPlayed, monopolyPlayed, victoryShown, mine:{knight,...}}
    const p = {}; Object.keys(DECK).forEach((k) => { p[k] = DECK[k]; });
    p.knight -= info.knightsPlayed || 0; p.road -= info.roadPlayed || 0; p.plenty -= info.plentyPlayed || 0; p.monopoly -= info.monopolyPlayed || 0; p.victory -= info.victoryShown || 0;
    const mine = info.mine || {}; Object.keys(mine).forEach((k) => { p[k] -= mine[k]; });
    Object.keys(p).forEach((k) => { p[k] = Math.max(0, p[k]); });
    return p;
  }
  function assignStyles(count, rand) {
    const r = rand || Math.random; const pool = ARCH.order().slice();
    for (let i = pool.length - 1; i > 0; i--) { const j = Math.floor(r() * (i + 1)); [pool[i], pool[j]] = [pool[j], pool[i]]; }
    const out = []; for (let i = 0; i < count; i++) out.push(pool[i % pool.length]);
    return out;
  }

  const api = {
    R, COST, STYLES, STYLE_ORDER, ARCH, LIMIT, decide, setupSettlement, setupRoad, robber, discard, acceptTrade,
    plentyPick(S) { const c = plentyChoice(ctx(S)); return c ? c.pick : null; },
    monopolyPick(S) { const c = monopolyChoice(ctx(S)); return c ? c.pick : null; },
    Track, devPool, assignStyles,
    _internals: { ctx, goals, rank, roadLen, winNow, knightValue, handScore, eta, tradePlan }
  };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.HearthAI = api;
})(typeof globalThis !== 'undefined' ? globalThis : this);
