/* Harbor & Hearth V1.9 - medieval tooltips.
   Any element can opt in with attributes; no per-element wiring is needed:
     data-tip="Short description"            (required)
     data-tip-title="Heading"                 (optional)
     data-tip-more="Longer explanation"       (optional; shown after a longer hover or while Shift is held)
   Helper: tipAttrs(title, short, more) returns the attribute string for templates. */
(function (root) {
  'use strict';
  if (typeof document === 'undefined' || !document.addEventListener) { root.tipAttrs = () => ''; root.Tooltip = { refresh() {}, hide() {} }; return; }
  const esc = (s) => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/"/g, '&quot;').replace(/</g, '&lt;');
  root.tipAttrs = (title, short, more) => `data-tip="${esc(short)}"${title ? ` data-tip-title="${esc(title)}"` : ''}${more ? ` data-tip-more="${esc(more)}"` : ''}`;
  let box = null; let target = null; let expandTimer = null; let showTimer = null; let lastX = 0; let lastY = 0; let shift = false;
  function el() {
    if (!box) { box = document.createElement('div'); box.id = 'tooltip'; box.setAttribute('role', 'tooltip'); document.body.appendChild(box); }
    return box;
  }
  function fill(expanded) {
    if (!target) return;
    const t = target.getAttribute('data-tip-title'); const s = target.getAttribute('data-tip'); const m = target.getAttribute('data-tip-more');
    el().innerHTML = `${t ? `<strong>${esc(t)}</strong>` : ''}<span>${esc(s)}</span>${m ? (expanded ? `<p class="tt-more">${esc(m)}</p>` : '<em class="tt-hint">Hold Shift for more</em>') : ''}`;
    box.classList.toggle('expanded', !!expanded);
    place();
  }
  function place() {
    if (!box || !target) return;
    const r = target.getBoundingClientRect(); const b = box.getBoundingClientRect();
    const vw = window.innerWidth; const vh = window.innerHeight;
    let x; let y;
    if (target.closest && target.closest('svg')) { x = lastX + 14; y = lastY + 16; } else { x = r.left + r.width / 2 - b.width / 2; y = r.top - b.height - 10; if (y < 6) y = r.bottom + 10; }
    x = Math.max(6, Math.min(vw - b.width - 6, x)); y = Math.max(6, Math.min(vh - b.height - 6, y));
    box.style.left = x + 'px'; box.style.top = y + 'px';
  }
  function show(t) {
    target = t; clearTimeout(expandTimer); clearTimeout(showTimer);
    showTimer = setTimeout(() => {
      if (!target) return;
      fill(shift); el().classList.add('on');
      if (target.getAttribute('data-tip-more')) expandTimer = setTimeout(() => fill(true), 1400);
    }, 180);
  }
  function hide() { target = null; clearTimeout(expandTimer); clearTimeout(showTimer); if (box) box.classList.remove('on', 'expanded'); }
  document.addEventListener('mouseover', (ev) => {
    const t = ev.target.closest && ev.target.closest('[data-tip]');
    if (t === target) return;
    if (t && t.getAttribute('data-tip')) show(t); else hide();
  });
  document.addEventListener('mousemove', (ev) => { lastX = ev.clientX; lastY = ev.clientY; if (target && target.closest && target.closest('svg') && box && box.classList.contains('on')) place(); });
  document.addEventListener('mousedown', hide);
  document.addEventListener('keydown', (ev) => { if (ev.key === 'Shift') { shift = true; if (target && box && box.classList.contains('on')) fill(true); } });
  document.addEventListener('keyup', (ev) => { if (ev.key === 'Shift') shift = false; });
  // focus support for keyboard users
  document.addEventListener('focusin', (ev) => { const t = ev.target.closest && ev.target.closest('[data-tip]'); if (t) show(t); });
  document.addEventListener('focusout', hide);
  root.Tooltip = {
    hide,
    // called after every render: the hovered element may have been replaced
    refresh() {
      if (!target) return;
      if (target.isConnected) return;
      const now = document.elementFromPoint(lastX, lastY); const t = now && now.closest && now.closest('[data-tip]');
      if (t) { target = t; fill(box && box.classList.contains('expanded')); } else hide();
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
