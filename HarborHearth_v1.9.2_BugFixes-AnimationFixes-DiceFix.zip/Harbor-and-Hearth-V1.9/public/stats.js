/* Harbor & Hearth V1.9 - match statistics, MVP awards and the end-of-game screen.
   The engine calls Stats.* hooks as things happen. At the end, Stats.summary(game) produces a plain
   object (no live references) that is saved with the match and rendered by statsScreen(). */
(function (root) {
  'use strict';
  const RES = ['wood', 'brick', 'wool', 'grain', 'ore'];
  const zero = () => ({ wood: 0, brick: 0, wool: 0, grain: 0, ore: 0 });
  const tot = (m) => RES.reduce((n, k) => n + ((m && m[k]) || 0), 0);
  const CATS = ['production', 'setup', 'tradeIn', 'tradeOut', 'bankIn', 'bankOut', 'stolenIn', 'stolenOut', 'discarded', 'monoIn', 'monoOut', 'plenty', 'spent'];
  const CAT_LABEL = {
    production: 'Production', setup: 'Starting goods', tradeIn: 'Player trades in', tradeOut: 'Player trades out',
    bankIn: 'Bank/harbor in', bankOut: 'Bank/harbor out', stolenIn: 'Stolen (gained)', stolenOut: 'Stolen (lost)',
    discarded: 'Discarded on 7', monoIn: 'Monopoly (gained)', monoOut: 'Monopoly (lost)', plenty: 'Year of Plenty', spent: 'Spent building'
  };
  function blank() {
    const o = {}; CATS.forEach((c) => { o[c] = zero(); });
    o.devBought = { knight: 0, road: 0, plenty: 0, monopoly: 0, victory: 0 };
    o.devPlayed = { knight: 0, road: 0, plenty: 0, monopoly: 0 };
    o.built = { road: 0, settlement: 0, city: 0 };
    o.trades = 0; o.bankTrades = 0; o.robberMoves = 0; o.steals = 0; o.robbed = 0;
    return o;
  }
  const Stats = {
    CATS, CAT_LABEL,
    init(game) {
      game.stats = { startedAt: Date.now(), endedAt: null, dice: {}, rolls: 0, p: {} };
      for (let v = 2; v <= 12; v++) game.stats.dice[v] = 0;
      game.players.forEach((q) => { game.stats.p[q.id] = blank(); });
    },
    p(game, id) { if (!game || !game.stats) return null; if (!game.stats.p[id]) game.stats.p[id] = blank(); return game.stats.p[id]; },
    // add resources to a category: map {wood:1,...} or (res, n)
    res(game, id, cat, map, n) {
      const s = Stats.p(game, id); if (!s) return;
      if (typeof map === 'string') { s[cat][map] += n || 1; return; }
      RES.forEach((k) => { s[cat][k] += (map && map[k]) || 0; });
    },
    count(game, id, key, sub, n) {
      const s = Stats.p(game, id); if (!s) return;
      if (sub) s[key][sub] = (s[key][sub] || 0) + (n || 1); else s[key] = (s[key] || 0) + (n || 1);
    },
    roll(game, v) { if (!game || !game.stats) return; game.stats.dice[v]++; game.stats.rolls++; },
    summary(game) {
      const st = game.stats || { dice: {}, p: {}, rolls: 0, startedAt: Date.now() };
      const end = st.endedAt || Date.now();
      const players = game.players.map((q) => {
        const hidden = (q.secretVp || []).length;
        return {
          id: q.id, name: q.name, color: q.color, bot: !!q.bot, style: q.style || null, styleLabel: q.styleLabel || null,
          visible: root.score ? root.score(q) : 0, hidden, total: (root.score ? root.score(q) : 0) + hidden,
          settlements: q.settlements.length, cities: q.cities.length, roads: q.roads.length,
          roadLen: root.roadLen ? root.roadLen(q) : 0, knights: q.knights, vpCards: q.vp + hidden,
          longest: game.longest === q.id, largest: game.largest === q.id
        };
      });
      const sorted = players.slice().sort((a, b) => (b.id === game.winner) - (a.id === game.winner) || b.total - a.total);
      let rank = 0; let prev = null;
      sorted.forEach((pl, i) => { if (prev === null || pl.total !== prev || pl.id === game.winner) rank = i + 1; prev = pl.total; pl.rank = rank; });
      const per = {}; game.players.forEach((q) => { per[q.id] = JSON.parse(JSON.stringify(st.p[q.id] || blank())); });
      const sum = {
        format: 1, winnerId: game.winner, turns: game.turnCount, rounds: Math.ceil((game.turnCount + 1) / game.players.length),
        startedAt: st.startedAt, endedAt: end, durationMs: end - st.startedAt, rolls: st.rolls, dice: Object.assign({}, st.dice),
        difficulty: game.difficulty || 'normal', mapId: game.board.mapId || 'standard', rules: game.rulesId || 'standard',
        players: sorted, stats: per
      };
      sum.awards = awards(sum);
      return sum;
    }
  };
  /* ---------------- awards ---------------- */
  const AWARDS = [
    { id: 'magnate', title: 'Resource Magnate', glyph: '❖', desc: 'Collected the most resource cards in total.',
      metric: (s) => tot(s.production) + tot(s.setup) + tot(s.tradeIn) + tot(s.bankIn) + tot(s.stolenIn) + tot(s.monoIn) + tot(s.plenty), unit: 'cards' },
    { id: 'harvest', title: 'Lord of the Harvest', glyph: '✿', desc: 'Gathered the most cards from dice production.', metric: (s) => tot(s.production), unit: 'cards' },
    { id: 'trader', title: 'Master Trader', glyph: '⚖', desc: 'Completed the most trades with players and harbors.', metric: (s) => s.trades + s.bankTrades, unit: 'trades' },
    { id: 'strategist', title: 'Development Strategist', glyph: '✒', desc: 'Bought and played the most scrolls.', metric: (s) => tot2(s.devBought) + tot2(s.devPlayed), unit: 'cards' },
    { id: 'builder', title: 'Master Builder', glyph: '⚒', desc: 'Built the most roads, settlements and cities.', metric: (s) => s.built.road + s.built.settlement + s.built.city, unit: 'pieces' },
    { id: 'road', title: 'Road Master', glyph: '➶', desc: 'Held the Longest Road at the end.', holder: 'longest', unit: 'road length', value: (pl) => pl.roadLen },
    { id: 'army', title: 'Greatest Commander', glyph: '⚔', desc: 'Held the Largest Army at the end.', holder: 'largest', unit: 'knights', value: (pl) => pl.knights },
    { id: 'baron', title: 'Robber Baron', glyph: '☗', desc: 'Stole the most cards with the robber.', metric: (s) => s.steals, unit: 'thefts' },
    { id: 'hardluck', title: 'Weathered the Storm', glyph: '☂', desc: 'Lost the most cards to the robber and discards, and kept going.', metric: (s) => tot(s.stolenOut) + tot(s.discarded) + tot(s.monoOut), unit: 'cards lost' }
  ];
  function tot2(m) { return Object.values(m || {}).reduce((a, b) => a + b, 0); }
  function awards(sum) {
    const out = [];
    AWARDS.forEach((a) => {
      if (a.holder) {
        const pl = sum.players.find((q) => q[a.holder]);
        if (pl) out.push({ id: a.id, title: a.title, glyph: a.glyph, desc: a.desc, winners: [pl.id], value: a.value(pl), unit: a.unit });
        return;
      }
      let best = 0; let ids = [];
      sum.players.forEach((pl) => { const s = sum.stats[pl.id]; if (!s) return; const v = a.metric(s); if (v > best) { best = v; ids = [pl.id]; } else if (v === best && v > 0) ids.push(pl.id); });
      if (best > 0) out.push({ id: a.id, title: a.title, glyph: a.glyph, desc: a.desc, winners: ids, value: best, unit: a.unit });
    });
    return out;
  }
  Stats.AWARDS = AWARDS;
  root.Stats = Stats;

  /* ---------------- end-of-game screen ---------------- */
  const PROB = { 2: 1, 3: 2, 4: 3, 5: 4, 6: 5, 7: 6, 8: 5, 9: 4, 10: 3, 11: 2, 12: 1 };
  const esc = (s) => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;');
  function dur(ms) { const s = Math.max(0, Math.round(ms / 1000)); const h = Math.floor(s / 3600); const m = Math.floor((s % 3600) / 60); const r = s % 60; return h ? `${h}h ${m}m` : `${m}m ${r}s`; }
  function nameOf(sum, id) { const q = sum.players.find((x) => x.id === id); return q ? q.name : '?'; }
  function swatch(sum, id) { const q = sum.players.find((x) => x.id === id); return `<i class="sw" style="--color:${q ? q.color : '#888'}"></i>`; }
  function diceChart(sum) {
    const n = sum.rolls || 0; const max = Math.max(1, ...Object.values(sum.dice), ...Object.keys(PROB).map((v) => n * PROB[v] / 36));
    const W = 560; const H = 210; const bw = W / 11;
    let bars = '';
    for (let v = 2; v <= 12; v++) {
      const actual = sum.dice[v] || 0; const exp = n * PROB[v] / 36; const x = (v - 2) * bw;
      const h = actual / max * (H - 40); const he = exp / max * (H - 40);
      const cls = actual > exp + 0.5 ? 'over' : actual < exp - 0.5 ? 'under' : 'even';
      bars += `<g data-tip="${v}: rolled ${actual}×, expected ${exp.toFixed(1)}× (${(PROB[v] / 36 * 100).toFixed(1)}%)"><rect class="dbar ${cls}" x="${x + 8}" y="${H - 22 - h}" width="${bw - 16}" height="${h}" rx="3"/>` +
        `<line class="dexp" x1="${x + 4}" x2="${x + bw - 4}" y1="${H - 22 - he}" y2="${H - 22 - he}"/>` +
        `<text class="dnum" x="${x + bw / 2}" y="${H - 6}">${v}</text><text class="dval" x="${x + bw / 2}" y="${H - 27 - h}">${actual}</text></g>`;
    }
    return `<svg class="dice-chart" viewBox="0 0 ${W} ${H}" role="img" aria-label="Dice distribution">${bars}</svg><p class="legend"><span class="lg over"></span>above expected <span class="lg under"></span>below expected <span class="lg exp"></span>expected count (${n} rolls)</p>`;
  }
  function resTable(sum, pl) {
    const s = sum.stats[pl.id]; if (!s) return '<p>No data recorded.</p>';
    const icon = (k) => (typeof resIcon === 'function' ? `<span class="ri">${resIcon(k)}</span>` : k);
    const rows = CATS.filter((c) => tot(s[c])).map((c) => `<tr><th>${CAT_LABEL[c]}</th>${RES.map((k) => `<td>${s[c][k] || ''}</td>`).join('')}<td class="t">${tot(s[c])}</td></tr>`).join('');
    return `<table class="st-table"><thead><tr><th></th>${RES.map((k) => `<th>${icon(k)}</th>`).join('')}<th>Total</th></tr></thead><tbody>${rows || '<tr><td colspan="7">No resource movement recorded.</td></tr>'}</tbody></table>`;
  }
  function devTable(sum) {
    const types = ['knight', 'road', 'plenty', 'monopoly', 'victory']; const lbl = { knight: 'Knight', road: 'Road Building', plenty: 'Year of Plenty', monopoly: 'Monopoly', victory: 'Victory Point' };
    const head = `<tr><th>Player</th><th>Bought</th>${types.map((t) => `<th>${lbl[t]}</th>`).join('')}<th>Played</th></tr>`;
    const rows = sum.players.map((pl) => { const s = sum.stats[pl.id] || {}; const b = s.devBought || {}; const p = s.devPlayed || {}; return `<tr><th>${swatch(sum, pl.id)}${esc(pl.name)}</th><td class="t">${tot2(b)}</td>${types.map((t) => `<td>${b[t] || 0}${t !== 'victory' && p[t] ? ` <small>(${p[t]} played)</small>` : ''}</td>`).join('')}<td class="t">${tot2(p)}</td></tr>`; }).join('');
    return `<table class="st-table wide"><thead>${head}</thead><tbody>${rows}</tbody></table>`;
  }
  function awardCards(sum) {
    if (!sum.awards || !sum.awards.length) return '<p class="muted">No awards were earned in this match.</p>';
    return `<div class="awards">${sum.awards.map((a) => `<div class="award-card" ${root.tipAttrs ? root.tipAttrs(a.title, a.desc) : ''}><div class="crest-shield"><span>${a.glyph}</span></div><div><b>${esc(a.title)}</b><span class="aw-who">${a.winners.map((id) => `${swatch(sum, id)}${esc(nameOf(sum, id))}`).join(' & ')}</span><small>${esc(a.desc)} ${a.value} ${a.unit}${a.winners.length > 1 ? ' (shared)' : ''}</small></div></div>`).join('')}</div>`;
  }
  const plural = (n, one, many) => `${n} ${n === 1 ? one : (many || one + 's')}`;
  function standings(sum, showStyles) {
    const ord = ['1st', '2nd', '3rd', '4th', '5th', '6th'];
    return `<ol class="standings">${sum.players.map((pl) => `<li class="${pl.id === sum.winnerId ? 'champ' : ''}"><span class="place">${ord[pl.rank - 1] || pl.rank}</span><span class="st-name">${swatch(sum, pl.id)}<b>${esc(pl.name)}</b>${pl.bot && showStyles && pl.styleLabel ? ` <em class="style-tag">${esc(pl.styleLabel)}</em>` : ''}${pl.bot ? '' : ' <small>(human)</small>'}</span><span class="vp"><strong>${pl.total}</strong> renown <small>${pl.visible} visible${pl.hidden ? ` + ${pl.hidden} hidden` : ''}</small></span><span class="mini-stats">${plural(pl.settlements, 'settlement')} · ${plural(pl.cities, 'city', 'cities')} · road ${pl.roadLen} · ${plural(pl.knights, 'knight')}${pl.longest ? ' · <b>Longest Road</b>' : ''}${pl.largest ? ' · <b>Largest Army</b>' : ''}</span></li>`).join('')}</ol>`;
  }
  function statsScreen(sum, opts) {
    opts = opts || {}; const tab = opts.tab || 'summary'; const showStyles = opts.showStyles !== false;
    const tabs = [['summary', 'Standings & Awards'], ['dice', 'Dice'], ['resources', 'Resources'], ['dev', 'Scrolls'], ['match', 'Match']];
    let body = '';
    if (tab === 'summary') body = `<section><h3>Final standings</h3>${standings(sum, showStyles)}</section><section><h3>Honours of the match</h3>${awardCards(sum)}</section>`;
    if (tab === 'dice') body = `<section><h3>Dice rolls</h3>${diceChart(sum)}</section>`;
    if (tab === 'resources') body = `<section><h3>Where every card came from and went</h3><div class="res-grid">${sum.players.map((pl) => `<div class="res-card"><h4>${swatch(sum, pl.id)}${esc(pl.name)}</h4>${resTable(sum, pl)}</div>`).join('')}</div></section>`;
    if (tab === 'dev') body = `<section><h3>Scrolls</h3>${devTable(sum)}</section>`;
    if (tab === 'match') {
      const avg = sum.turns ? sum.durationMs / Math.max(1, sum.turns) : 0;
      body = `<section><h3>The match</h3><dl class="match-facts"><dt>Winner</dt><dd>${swatch(sum, sum.winnerId)}${esc(nameOf(sum, sum.winnerId))}</dd><dt>Turns played</dt><dd>${sum.turns} (${sum.rounds} rounds)</dd><dt>Time at the table</dt><dd>${dur(sum.durationMs)}</dd><dt>Average turn</dt><dd>${dur(avg)}</dd><dt>Dice rolls</dt><dd>${sum.rolls} (${sum.dice[7] || 0} sevens)</dd><dt>Started</dt><dd>${new Date(sum.startedAt).toLocaleString()}</dd><dt>Finished</dt><dd>${new Date(sum.endedAt).toLocaleString()}</dd><dt>Bot difficulty</dt><dd>${esc(sum.difficulty)}</dd></dl></section>`;
    }
    const winner = sum.players.find((q) => q.id === sum.winnerId);
    return `<div class="overlay stats-overlay"><div class="stats-modal" role="dialog" aria-label="Match summary"><header><div class="banner-title"><span class="laurel">❦</span><div><h2>${esc(winner ? winner.name : 'Nobody')} claims the island</h2><p>${sum.turns} turns · ${dur(sum.durationMs)}</p></div><span class="laurel flip">❦</span></div>${opts.close ? `<button class="tm-x" onclick="${opts.close}" aria-label="Close">✕</button>` : ''}</header>` +
      `<nav class="st-tabs">${tabs.map(([id, label]) => `<button class="${id === tab ? 'on' : ''}" onclick="${opts.tabCall || 'setStatsTab'}('${id}')">${label}</button>`).join('')}</nav><div class="st-body">${body}</div>` +
      `<footer>${(opts.buttons || []).map((b) => `<button class="${b.cls || ''}" onclick="${b.on}">${b.label}</button>`).join('')}</footer></div></div>`;
  }
  root.statsScreen = statsScreen;
  root.fmtDuration = dur;
})(typeof globalThis !== 'undefined' ? globalThis : this);
