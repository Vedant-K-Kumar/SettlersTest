/* Harbor & Hearth V1.9 - map definitions and board generation.
   A map definition is plain data (hex coordinates, terrain/number/port pools, constraints).
   build() turns a definition into a board: tiles, nodes, edges, ports, robber.
   Renderers (iso.js = 2.5D, render2d.js = 2D) only read the board, so the planned map maker
   only has to produce a definition (or a fixed layout) and call build(). */
(function (root) {
  'use strict';
  const MAPS = {
    standard: {
      id: 'standard',
      name: 'Classic Isle',
      // axial hex coordinates of land tiles
      hexes: (() => { const c = []; for (let q = -2; q <= 2; q++) for (let r = -2; r <= 2; r++) if (Math.abs(q + r) <= 2) c.push({ q, r }); return c; })(),
      terrains: ['wood', 'wood', 'wood', 'wood', 'grain', 'grain', 'grain', 'grain', 'wool', 'wool', 'wool', 'wool', 'brick', 'brick', 'brick', 'ore', 'ore', 'ore', 'desert'],
      numbers: [2, 3, 3, 4, 4, 5, 5, 6, 6, 8, 8, 9, 9, 10, 10, 11, 11, 12],
      ports: ['any', 'any', 'any', 'any', 'wood', 'brick', 'wool', 'grain', 'ore'],
      constraints: { separateHotNumbers: true },
      // optional fixed layout for hand-made maps: [{q,r,terrain,number}] and fixedPorts: [{edgeIndex,type}]
      fixed: null
    }
  };
  const key = (x, y) => `${Math.round(x * 100) / 100},${Math.round(y * 100) / 100}`;
  const edgeKey = (a, b) => [a, b].sort().join('|');
  const px = (q, r) => ({ x: Math.sqrt(3) * (q + r / 2), y: 1.5 * r });
  const hexDist = (a, b) => (Math.abs(a.q - b.q) + Math.abs(a.r - b.r) + Math.abs(a.q + a.r - b.q - b.r)) / 2;

  function placeTiles(def, shuffle) {
    if (def.fixed) return def.fixed.map((t, i) => ({ q: t.q, r: t.r, id: String(i), terrain: t.terrain, number: t.terrain === 'desert' ? null : t.number, center: px(t.q, t.r) }));
    let tiles; let guard = 0;
    do {
      const nums = shuffle(def.numbers); let ni = 0; const ts = shuffle(def.terrains);
      tiles = def.hexes.map((c, i) => ({ q: c.q, r: c.r, id: String(i), terrain: ts[i], number: ts[i] === 'desert' ? null : nums[ni++], center: px(c.q, c.r) }));
    } while (def.constraints && def.constraints.separateHotNumbers && guard++ < 5000 &&
      tiles.some((t) => (t.number === 6 || t.number === 8) && tiles.some((o) => o !== t && (o.number === 6 || o.number === 8) && hexDist(t, o) === 1)));
    return tiles;
  }
  function build(defOrId, shuffle) {
    const def = typeof defOrId === 'string' ? (MAPS[defOrId] || MAPS.standard) : defOrId;
    const tiles = placeTiles(def, shuffle);
    const nodes = new Map(); const edges = new Map();
    tiles.forEach((t) => {
      t.nodes = [];
      for (let i = 0; i < 6; i++) {
        const a = (60 * i - 30) * Math.PI / 180; const p = { x: t.center.x + Math.cos(a), y: t.center.y + Math.sin(a) }; const k = key(p.x, p.y);
        if (!nodes.has(k)) nodes.set(k, { id: `n${nodes.size}`, x: p.x, y: p.y, tiles: [] });
        const nd = nodes.get(k); nd.tiles.push(t.id); t.nodes.push(nd.id);
      }
      for (let i = 0; i < 6; i++) {
        const a = t.nodes[i]; const b = t.nodes[(i + 1) % 6]; const k = edgeKey(a, b);
        if (!edges.has(k)) edges.set(k, { id: `e${edges.size}`, a, b, tiles: [] });
        edges.get(k).tiles.push(t.id);
      }
    });
    const edgeList = [...edges.values()];
    const nm = new Map([...nodes.values()].map((z) => [z.id, z]));
    const ang = (e) => { const u = nm.get(e.a); const v = nm.get(e.b); return Math.atan2((u.y + v.y) / 2, (u.x + v.x) / 2); };
    const coast = edgeList.filter((e) => e.tiles.length === 1).sort((u, v) => ang(u) - ang(v));
    let ports;
    if (def.fixedPorts) ports = def.fixedPorts.map((p) => ({ edge: coast[p.edgeIndex].id, type: p.type }));
    else {
      const types = shuffle(def.ports);
      ports = types.map((type, i) => ({ edge: coast[Math.floor((i + 0.5) * coast.length / types.length)].id, type }));
    }
    const desert = tiles.find((t) => t.terrain === 'desert');
    return { mapId: def.id, tiles, nodes: [...nodes.values()], edges: edgeList, ports, robber: desert ? desert.id : tiles[0].id };
  }
  function register(def) { MAPS[def.id] = def; return def; }
  root.HearthMaps = { MAPS, build, register, px };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.HearthMaps;
})(typeof globalThis !== 'undefined' ? globalThis : this);
