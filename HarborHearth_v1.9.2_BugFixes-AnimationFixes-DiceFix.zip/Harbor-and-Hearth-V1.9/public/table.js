/* Harbor & Hearth V1.9 - table interface.
   Layout: top bar | left rail (Chronicle tab + notifications) | board | right rail (bank + player
   profiles) | bottom bar (turn, hand, progress cards, build and trade). Everything fits the window;
   no right-side action panel. Also: main menu, new-game screen, settings, end-of-game overlay. */
var ui = { screen: 'main', settingsOpen: false, settingsTab: 'display', statsOpen: false, statsTab: 'summary', difficulty: null };
const escH = (s) => String(s == null ? '' : s).replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;').replace(/"/g, '&quot;');
const PHASE_TEXT = { setup: 'Setup', roll: 'Roll', build: 'Trade & build', robber: 'Robber', discard: 'Discard', done: 'Game over', replay: 'Replay' };

/* ---------------- art for the profile card indicators (original designs) ---------------- */
const IND_ART = {
  goods: '<svg viewBox="0 0 40 56" aria-hidden="true"><rect x="2" y="2" width="36" height="52" rx="5" fill="#6b3f22" stroke="#2a170b" stroke-width="2"/><rect x="6" y="6" width="28" height="44" rx="3" fill="none" stroke="#d9b56a" stroke-width="1.5"/><path d="M20 10l4 4-4 4-4-4z M20 38l4 4-4 4-4-4z" fill="#d9b56a"/><circle cx="20" cy="28" r="9" fill="#f3e3b8" stroke="#2a170b" stroke-width="1.5"/><text x="20" y="33" text-anchor="middle" font-family="Pirata One, Georgia, serif" font-weight="700" font-size="14" fill="#6b3f22">?</text></svg>',
  dev: '<svg viewBox="0 0 40 56" aria-hidden="true"><rect x="2" y="2" width="36" height="52" rx="5" fill="#2f3f6e" stroke="#141c33" stroke-width="2"/><rect x="6" y="6" width="28" height="44" rx="3" fill="none" stroke="#c9b26b" stroke-width="1.5"/><path d="M12 36c0-10 8-18 16-22-2 6-3 10-8 16" fill="#f2e6c4" stroke="#141c33" stroke-width="1.3"/><path d="M12 36l-2 6 5-3" fill="#c9b26b" stroke="#141c33" stroke-width="1"/><path d="M27 41l1.6 3.2 3.5.5-2.6 2.4.6 3.5-3.1-1.7-3.1 1.7.6-3.5-2.6-2.4 3.5-.5z" fill="#e8c460"/></svg>',
  renown: '<svg viewBox="0 0 40 56" aria-hidden="true"><path d="M20 3l15 6v17c0 13-7 22-15 27C12 48 5 39 5 26V9z" fill="#8a1f1a" stroke="#3a0b08" stroke-width="2"/><path d="M20 8l11 4.5V26c0 9.5-5 16.5-11 20.5C14 42.5 9 35.5 9 26V12.5z" fill="none" stroke="#e8c460" stroke-width="1.4"/><path d="M12 20l3 4 5-7 5 7 3-4v8H12z" fill="#e8c460" stroke="#5a3a08" stroke-width="1"/><circle cx="20" cy="15.5" r="1.6" fill="#e8c460"/></svg>',
  road: '<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M4 26L12 6h8l8 20z" fill="#9a6a3c" stroke="#3a2414" stroke-width="1.5" stroke-linejoin="round"/><path d="M16 9v3M16 15v3M16 21v3" stroke="#f3e3b8" stroke-width="2" stroke-linecap="round"/></svg>',
  army: '<svg viewBox="0 0 32 32" aria-hidden="true"><path d="M6 5l14 14M26 5L12 19" stroke="#d8dde3" stroke-width="3" stroke-linecap="round"/><path d="M6 5l14 14M26 5L12 19" stroke="#3a3f46" stroke-width="1" stroke-linecap="round"/><path d="M9 22l4-4 2 2-4 4zM23 22l-4-4-2 2 4 4z" fill="#b5852c" stroke="#3a2414"/><circle cx="16" cy="26" r="3" fill="#e8c460" stroke="#5a3a08"/></svg>',
  deck: '<svg viewBox="0 0 40 56" aria-hidden="true"><rect x="7" y="7" width="31" height="46" rx="4" fill="#24315a" stroke="#141c33" stroke-width="1.5"/><rect x="4" y="4" width="31" height="46" rx="4" fill="#2f3f6e" stroke="#141c33" stroke-width="1.5"/><rect x="7.5" y="7.5" width="24" height="39" rx="2.5" fill="none" stroke="#c9b26b" stroke-width="1.2"/><path d="M19.5 17l2.4 4.8 5.3.8-3.9 3.7.9 5.2-4.7-2.5-4.7 2.5.9-5.2-3.9-3.7 5.3-.8z" fill="#e8c460"/></svg>'
};

/* ---------------- helpers ---------------- */
function viewerOf() {
  if (!game || game.replay) return null;
  const active = p(); const humans = game.players.filter((q) => !q.bot); const d = game.phase === 'discard' ? discarder() : null;
  if (d && !d.bot) return d;
  if (humans.length === 1) return humans[0];
  if (active && !active.bot) return active;
  return humans[0] || null;
}
function archetypeOn() { return HearthSettings.get('showArchetypes'); }
function archetypeTag(q) {
  if (!q.bot || !q.style || !archetypeOn()) return '';
  const a = HearthArchetypes.get(q.style); if (!a) return '';
  return `<em class="style-tag" ${tipAttrs(`${a.emblem} ${a.label}`, a.blurb, a.details)}>${escH(a.label)}</em>`;
}
function costChips(c, x) {
  return R.filter((k) => c[k]).map((k) => { const ok = !x || x.r[k] >= c[k]; return `<span class="cost-chip ${k} ${ok ? 'ok' : 'short'}">${resIcon(k)}<b>${c[k]}</b></span>`; }).join('');
}
const COSTS = () => (game && game.rules ? game.rules.costs : HearthRules.get('standard').costs);
function openSettings(tab) { ui.settingsOpen = true; if (tab) ui.settingsTab = tab; render(); }
function closeSettings() { ui.settingsOpen = false; HearthKeys.capturing = null; render(); }
function toggleChronicle() { HearthSettings.set('chronicleOpen', !HearthSettings.get('chronicleOpen')); render(); }
function setMapMode(m) { HearthSettings.set('mapMode', m); render(); }
function toggleMap() { setMapMode(HearthSettings.get('mapMode') === 'flat' ? 'iso' : 'flat'); }
function setStatsTab(t) { ui.statsTab = t; render(); }
function setPlayerColor(c) {
  HearthSettings.set('playerColor', c);
  if (game && !game.replay && !game.winner) { const me = game.players.find((q) => !q.bot); if (me && !game.players.some((q) => q !== me && q.color === c)) me.color = c; }
  render();
}
function uiAction(a) {
  if (a === 'settings') { if (ui.settingsOpen) closeSettings(); else openSettings(); return; }
  if (a === 'map') { toggleMap(); return; }
  if (a === 'chronicle') { toggleChronicle(); return; }
  if (a === 'zoomIn') { Zoom.zoomIn(); return; }
  if (a === 'zoomOut') { Zoom.zoomOut(); return; }
  if (a === 'zoomFit') { Zoom.fit(); return; }
  if (!game || game.replay) return;
  const mine = humanMayAct() && !game.offer;
  if (a === 'cancel') { if (game.pick) cancelDev(); else if (tool === 'bank' || tool === 'offer') closeTrade(); else if (tool && tool !== 'robber' && tool !== 'robber-victim') { tool = null; render(); } else if (ui.settingsOpen) closeSettings(); return; }
  if (!mine) return;
  if (a === 'roll' && game.phase === 'roll') roll();
  if (a === 'end' && game.phase === 'build') next();
  if (['road', 'settlement', 'city'].includes(a) && game.phase === 'build') { tool = tool === a ? null : a; render(); }
  if (a === 'dev' && game.phase === 'build') buy();
  if ((a === 'bank' || a === 'offer') && game.phase === 'build') beginTrade(a);
}
function leaveToMenu() {
  if (game && !game.replay && !game.winner && typeof confirm === 'function' && !confirm('Leave this game? It has not finished, so it will not be saved.')) return;
  clearTimeout(botTimer); botTimer = null; game = null; tool = null; ui.settingsOpen = false; ui.statsOpen = false; ui.screen = 'main'; render();
}

/* ---------------- menus ---------------- */
function menuScreen() {
  if (ui.screen === 'history') return historyScreen() + settingsOverlay();
  if (ui.screen === 'newgame') return newGameScreen() + settingsOverlay();
  return `<section class="menu-screen main-menu"><div class="menu-card"><div class="crest"></div><h1>Harbor & Hearth</h1><p class="version">V${HEARTH_VERSION}</p>` +
    `<div class="menu-buttons"><button class="primary" onclick="ui.screen='newgame';render()">New game</button><button onclick="ui.screen='history';Saves.restoreFolder().then(render);render()">Match history</button><button onclick="openSettings('display')">Settings</button></div>` +
    `<p class="tiny">Runs directly in Chrome. No install or account required.</p>${message ? `<p class="alert">${escH(message)}</p>` : ''}</div></section>${settingsOverlay()}`;
}
function newGameScreen() {
  const names = HearthSettings.get('lastNames') || ['', '', '', ''];
  const diff = ui.difficulty || HearthSettings.get('difficulty') || 'normal';
  const opt = (id, label, desc, disabled) => `<label class="diff ${id === diff ? 'on' : ''} ${disabled ? 'disabled' : ''}" ${disabled ? tipAttrs('Hard', 'Not Implemented') : tipAttrs(label, desc)}><input type="radio" name="diff" value="${id}" ${id === diff ? 'checked' : ''} ${disabled ? 'disabled' : `onchange="ui.difficulty='${id}';HearthSettings.set('difficulty','${id}');render()"`}><span>${label}</span></label>`;
  return `<section class="menu-screen"><div class="menu-card"><header class="menu-head"><h1>New game</h1><button onclick="ui.screen='main';render()">Back</button></header>` +
    `<p class="subtitle">Enter a name only for a human seat. Every blank seat becomes a Hearthkeeper bot with its own strategy. Turn order is drawn at random.</p>` +
    `<div class="entry">${[0, 1, 2, 3].map((i) => `<label>Seat ${['one', 'two', 'three', 'four'][i]}<input data-name value="${escH(names[i] || '')}" placeholder="Human name (optional)"></label>`).join('')}</div>` +
    `<h3>Bot difficulty</h3><div class="diff-row">${opt('easy', 'Easy', 'Simpler bots with straightforward plans. They play fair and never see hidden cards.')}${opt('normal', 'Normal', 'Strategic bots, each following one of six archetypes.')}${opt('hard', 'Hard', 'Not Implemented', true)}</div>` +
    `<button class="primary big" onclick="beginGame()">Begin table</button>${message ? `<p class="alert">${escH(message)}</p>` : ''}</div></section>`;
}
function beginGame() {
  const names = [...document.querySelectorAll('[data-name]')].map((i) => i.value.trim());
  HearthSettings.set('lastNames', names);
  ui.screen = 'game'; ui.statsOpen = false; ui.statsTab = 'summary'; Zoom.reset();
  start();
}

/* ---------------- settings overlay ---------------- */
function settingsOverlay() {
  if (!ui.settingsOpen) return '';
  const s = HearthSettings.all(); const tab = ui.settingsTab;
  const inGame = game && !game.replay;
  const tabs = [['display', 'Map & display'], ['anim', 'Animations'], ['keys', 'Keyboard shortcuts']].concat(inGame ? [['game', 'Game']] : []);
  let body = '';
  if (tab === 'display') {
    body = `<h3>Map style</h3><div class="map-choice">${HearthRender.list().map((r) => `<button class="${s.mapMode === r.id ? 'on' : ''}" onclick="setMapMode('${r.id}')"><b>${r.label}</b><small>${r.name}</small></button>`).join('')}</div><p class="muted">Switching never changes the board or resets the game.</p>` +
      `<p class="muted">Pinch with two fingers on the touchpad or screen to zoom the map; scroll or drag to move around.</p>` +
      `<h3>Bots</h3><label class="check"><input type="checkbox" ${s.showArchetypes ? 'checked' : ''} onchange="HearthSettings.set('showArchetypes',this.checked);render()"> Show bot archetypes (badges and their tooltips)</label>` +
      `<h3>Your colour</h3><div class="swatches">${HearthSettings.PALETTE.map((c) => `<button class="swatch ${s.playerColor === c.color ? 'on' : ''}" style="--color:${c.color}" onclick="setPlayerColor('${c.color}')" ${tipAttrs(c.name, 'Use this colour for your seat')}></button>`).join('')}</div><p class="muted">Applies to the first human seat. Bots take other colours. Changes apply immediately when the colour is free.</p>`;
  }
  if (tab === 'anim') {
    body = `<h3>Animation speed</h3><div class="seg">${[['slow', 'Slower'], ['normal', 'Normal'], ['fast', 'Faster']].map(([v, l]) => `<button class="${s.animSpeed === v ? 'on' : ''}" onclick="HearthSettings.set('animSpeed','${v}');render()">${l}</button>`).join('')}</div>` +
      `<label class="check"><input type="checkbox" ${s.reducedMotion ? 'checked' : ''} onchange="HearthSettings.set('reducedMotion',this.checked);render()"> Reduced animations <small>(short, simple card movement; no dice tumbling or pulsing)</small></label>` +
      `<label class="check"><input type="checkbox" ${s.noDecor ? 'checked' : ''} onchange="HearthSettings.set('noDecor',this.checked);render()"> Disable decorative animations <small>(glows, shimmer and flourishes; gameplay feedback stays)</small></label>` +
      `<p class="muted">These settings only change how the game looks. They are saved for future games.</p>`;
  }
  if (tab === 'keys') {
    body = `<p class="muted">Every action starts unbound. Choose Set, then press the key you want.${window.keyNotice ? ` <b>${escH(window.keyNotice)}</b>` : ''}</p><ul class="keys">${HearthKeys.ACTIONS.map((a) => {
      const k = HearthKeys.binding(a.id); const cap = HearthKeys.capturing === a.id;
      return `<li class="${cap ? 'capturing' : ''}"><span>${a.label}</span>${cap ? '<kbd class="wait">Press a key… (Esc cancels)</kbd>' : k ? `<kbd>${escH(HearthKeys.label(k))}</kbd>` : '<span class="unbound">Unbound</span>'}<button onclick="HearthKeys.startCapture('${a.id}')">${k ? 'Change' : 'Set'}</button>${k && !cap ? `<button class="x" onclick="HearthKeys.clear('${a.id}')" aria-label="Remove shortcut for ${a.label}" ${tipAttrs('Remove', 'Unbind this shortcut')}>✕</button>` : '<span class="x-space"></span>'}</li>`;
    }).join('')}</ul>`;
  }
  if (tab === 'game') body = '<h3>This game</h3><p>Leaving now abandons the game. Only finished games are saved to Match History.</p><button class="danger" onclick="leaveToMenu()">Leave to main menu</button>';
  return `<div class="overlay" onclick="if(event.target===this)closeSettings()"><div class="settings-modal" role="dialog" aria-label="Settings"><header><h2>Settings</h2><button class="tm-x" onclick="closeSettings()" aria-label="Close">✕</button></header><nav class="st-tabs">${tabs.map(([id, l]) => `<button class="${tab === id ? 'on' : ''}" onclick="ui.settingsTab='${id}';HearthKeys.capturing=null;render()">${l}</button>`).join('')}</nav><div class="settings-body">${body}</div></div></div>`;
}

/* ---------------- game screen pieces ---------------- */
function topBar() {
  const active = p();
  const status = game.replay ? 'Replay' : game.winner != null ? `${escH(game.players.find((q) => q.id === game.winner).name)} wins` : `${escH(active.name)} · ${PHASE_TEXT[game.phase] || ''}`;
  return `<header class="topbar"><div class="brand">Harbor & Hearth <small>V${HEARTH_VERSION}</small></div><div class="turn-banner"><i style="--color:${active ? active.color : '#888'}"></i>${status}<span class="turn-no">Turn ${game.turnCount + 1}</span></div>` +
    `<div class="top-actions">${game.winner != null && !game.replay ? `<button onclick="ui.statsOpen=true;render()">Match summary</button>` : ''}<div class="seg small">${HearthRender.list().map((r) => `<button class="${HearthRender.current().id === r.id ? 'on' : ''}" onclick="setMapMode('${r.id}')" ${tipAttrs(r.name, 'Switch map style. The game is not affected.')}>${r.label}</button>`).join('')}</div>` +
    `<button class="icon" onclick="openSettings()" ${tipAttrs('Settings', 'Map, archetypes, colour, animations and keyboard shortcuts')}>⚙</button>${game.replay ? '' : `<button class="icon" onclick="leaveToMenu()" ${tipAttrs('Main menu', 'Leave this table')}>⌂</button>`}</div></header>`;
}
function leftRail() {
  const open = HearthSettings.get('chronicleOpen');
  return `<aside class="left-rail"><section class="chronicle ${open ? 'open' : 'closed'}"><button class="chron-tab" onclick="toggleChronicle()" aria-expanded="${open}"><span>📜 Chronicle</span><b>${open ? '▾' : '▸'}</b></button>${open ? `<ol class="log">${game.log.map((q) => `<li>${q}</li>`).join('')}</ol>` : ''}</section>${noticesPanel()}</aside>`;
}
const RES_USE = { wood: 'Roads and settlements', brick: 'Roads and settlements', wool: 'Settlements and scrolls', grain: 'Settlements, cities and scrolls', ore: 'Cities and scrolls' };
function bankPanel() {
  return `<section class="bank-panel"><h3>Bank</h3><div class="bank-row">${R.map((k) => `<div class="bank-card ${k} ${game.bank[k] === 0 ? 'empty' : ''}" ${tipAttrs(NAME[k], game.bank[k] === 0 ? 'None left in the bank' : `Used for: ${RES_USE[k]}`)}>${resIcon(k)}${game.bank[k] === 0 ? '<b class="out">Out</b>' : ''}</div>`).join('')}` +
    `<div class="bank-card deck" ${tipAttrs('Scroll deck', `${game.deck.length} scroll${game.deck.length === 1 ? '' : 's'} left · costs 1 wool, 1 grain, 1 ore`, 'Knights, Road Building, Year of Plenty, Monopoly and hidden victory points.')}>${IND_ART.deck}<b>${game.deck.length}</b></div></div></section>`;
}
function profile(q, i, viewer) {
  const current = i === game.turn && game.winner == null; const me = viewer === q;
  const vis = score(q); const hid = hiddenVp(q); const showHidden = (me || game.replay || game.winner != null) && hid > 0;
  const cards = sum(q.r); const devs = devCount(q); const len = roadLen(q);
  const lr = game.longest === q.id; const la = game.largest === q.id; const over = (game.rules && game.rules.discardOver) || 7;
  const reveal = game.replay && Replay.reveal;
  return `<div class="profile ${current ? 'current' : ''} ${me ? 'me' : ''} ${game.winner === q.id ? 'winner' : ''}" data-seat="${q.id}" style="--color:${q.color}">` +
    `<div class="pf-head"><i class="pf-dot"></i><b class="pf-name">${escH(q.name)}</b>${me ? '<small class="you">you</small>' : ''}${archetypeTag(q)}${current ? `<span class="pf-turn" ${tipAttrs('Current turn', `${escH(q.name)} is playing`)}>▶</span>` : ''}</div>` +
    `<div class="pf-body"><div class="ind ind-goods ${cards > over ? 'over' : ''}" ${tipAttrs('Goods', `${cards} resource card${cards === 1 ? '' : 's'} in hand`, cards > over ? `More than ${over}: loses half on a 7.` : '')}><span class="ind-art">${IND_ART.goods}</span><b class="ind-n">${cards}</b><small>Goods</small></div>` +
    `<div class="ind ind-dev" ${tipAttrs('Scrolls', `${devs} scroll${devs === 1 ? '' : 's'} held`, scrollsUsed(q))}><span class="ind-art">${IND_ART.dev}</span><b class="ind-n">${devs}</b><small>Scrolls</small></div>` +
    `<div class="ind ind-renown" ${tipAttrs('Renown', showHidden ? `${vis} visible + ${hid} hidden from victory point cards` : `${vis} visible renown`, `First to ${(game.rules && game.rules.victoryPoints) || 10} wins. Hidden victory points count automatically and are revealed at the win.`)}><span class="ind-art">${IND_ART.renown}</span><b class="ind-n">${vis}${showHidden ? `<small class="hid">(+${hid})</small>` : ''}</b><small>Renown</small></div>` +
    `<div class="pf-awards"><span class="award-badge road ${lr ? 'held' : ''}" ${tipAttrs('Longest Road', lr ? `${escH(q.name)} holds it (+2 renown). Road length ${len}.` : `Road length ${len}. Needs 5 or more and longer than everyone else.`)}>${IND_ART.road}<b>${len}</b></span><span class="award-badge army ${la ? 'held' : ''}" ${tipAttrs('Largest Army', la ? `${escH(q.name)} holds it (+2 renown) with ${q.knights} knights.` : `${q.knights} knight${q.knights === 1 ? '' : 's'} played. Needs 3 or more and more than everyone else.`)}>${IND_ART.army}<b>${q.knights}</b></span></div></div>` +
    `${reveal ? `<div class="pf-reveal">${goodsHtml(q.r)}</div>` : ''}</div>`;
}
function scrollsUsed(q) {
  const pl = (game.stats && game.stats.p[q.id] && game.stats.p[q.id].devPlayed) || {};
  const n = (k) => (k === 'knight' ? q.knights : pl[k] || 0);
  const w = (c, one, many) => `${c} ${c === 1 ? one : many}`;
  return `Used: ${w(n('knight'), 'knight', 'knights')} · ${w(n('monopoly'), 'monopoly', 'monopolies')} · ${w(n('road'), 'road building', 'road buildings')} · ${w(n('plenty'), 'year of plenty', 'years of plenty')}`;
}
function rightRail(viewer) { return `<aside class="right-rail">${bankPanel()}<div class="profiles">${game.players.map((q, i) => profile(q, i, viewer)).join('')}</div></aside>`; }

// Hand: one flat line of the cards you actually hold (one card per type, with its count).
function handCard(k, viewer) {
  const n = viewer.r[k];
  if (game.phase === 'discard' && discarder() === viewer && !viewer.bot) {
    const sel = (game.discardPick && game.discardPick[k]) || 0; const need = Math.floor(sum(viewer.r) / 2); const full = sum(game.discardPick || empty()) >= need;
    return `<div class="hand-cell discarding">${rcard(k, { n, cls: 'hand' + (sel ? ' sel' : ''), tag: sel ? `−${sel}` : '' })}<div class="discard-step"><button onclick="adjustDiscard('${k}',-1)" ${sel <= 0 ? 'disabled' : ''} aria-label="Discard fewer ${NAME[k]}">−</button><button onclick="adjustDiscard('${k}',1)" ${sel >= n || full ? 'disabled' : ''} aria-label="Discard more ${NAME[k]}">+</button></div></div>`;
  }
  return `<div class="hand-cell" ${tipAttrs(NAME[k], `${n} in hand · harbor rate ${bankRate(viewer, k)}:1`)}>${rcard(k, { n, cls: 'hand' })}</div>`;
}
function scrollHand(viewer, playable) {
  const label = { knight: 'Knight', road: 'Road Building', plenty: 'Year of Plenty', monopoly: 'Monopoly', victory: 'Victory Point' };
  const help = { knight: '', road: 'Place two free roads right away.', plenty: 'Take any two cards from the bank.', monopoly: 'Name a resource; every other player gives you all of it.', victory: 'Worth 1 renown. Counts automatically and stays hidden until you win.' };
  const groups = {};
  viewer.dev.forEach((c) => { (groups[c] = groups[c] || { ready: 0, fresh: 0 }).ready++; });
  viewer.newDev.forEach((c) => { (groups[c] = groups[c] || { ready: 0, fresh: 0 }).fresh++; });
  const hidden = (viewer.secretVp || []).length + viewer.vp;
  if (hidden) groups.victory = { ready: 0, fresh: 0, vp: hidden };
  return Object.keys(groups).map((c) => {
    const g = groups[c]; const total = g.vp || g.ready + g.fresh; const canPlay = playable && g.ready > 0 && c !== 'victory';
    const sub = c === 'victory' ? help.victory : g.fresh && !g.ready ? 'Bought this turn: playable from your next turn.' : help[c];
    return `<div class="hand-cell" ${tipAttrs(label[c], sub, canPlay ? 'Click to play. One scroll per turn.' : '')}>${dcard(c, { cls: `hand-dev ${canPlay ? 'ready' : ''} ${c === 'victory' ? 'secret' : ''} ${g.fresh && !g.ready ? 'held' : ''}`, on: canPlay ? `play('${c}')` : '', dis: !canPlay && c !== 'victory' })}<span class="dev-n">${total}</span></div>`;
  }).join('');
}
// Build and trade: small square icon buttons. Costs and details live in the tooltips.
function actionButtons(viewer, mine) {
  const c = COSTS(); const pieces = (game.rules && game.rules.pieces) || { settlement: 5, city: 4, road: 15 };
  const busy = !mine || game.phase !== 'build' || !!game.freeRoads;
  const items = [
    { id: 'bank', icon: '⚖', title: 'Bank & harbor trade', text: 'Trade 4:1 with the bank, or better at your harbors.', act: "beginTrade('bank')", ok: !busy },
    { id: 'offer', icon: '⇄', title: 'Offer a trade', text: 'Propose a deal to the other players.', act: "beginTrade('offer')", ok: !busy },
    { id: 'dev', svg: buildIcon('dev'), title: 'Buy a scroll', cost: c.dev, left: game.deck.length, text: 'Knight, Road Building, Year of Plenty, Monopoly or a hidden victory point.', act: 'buy()', ok: !busy && game.deck.length > 0 && paid(viewer, c.dev) },
    { id: 'road', svg: IND_ART.road, title: 'Road', cost: c.road, left: pieces.road - viewer.roads.length, text: 'Connects your network; counts toward Longest Road.', act: "tool=tool==='road'?null:'road';render()", ok: !busy && viewer.roads.length < pieces.road && paid(viewer, c.road), tool: true },
    { id: 'settlement', svg: buildIcon('house'), title: 'Settlement', cost: c.settlement, left: pieces.settlement - viewer.settlements.length, text: '1 renown. Collects 1 card from each neighbouring hex.', act: "tool=tool==='settlement'?null:'settlement';render()", ok: !busy && viewer.settlements.length < pieces.settlement && paid(viewer, c.settlement), tool: true },
    { id: 'city', svg: buildIcon('city'), title: 'City', cost: c.city, left: pieces.city - viewer.cities.length, text: 'Upgrades a settlement: 2 renown and 2 cards per hex.', act: "tool=tool==='city'?null:'city';render()", ok: !busy && viewer.settlements.length > 0 && viewer.cities.length < pieces.city && paid(viewer, c.city), tool: true }
  ];
  return items.map((it) => {
    const on = it.tool && tool === it.id; const costTxt = it.cost ? `Costs ${goods(it.cost)}.${paid(viewer, it.cost) ? '' : ' You need more cards.'}` : it.text;
    return `<button class="act-btn act-${it.id} ${on ? 'on' : ''} ${it.ok ? 'ready' : ''}" ${it.ok || on ? '' : 'disabled'} onclick="${it.act}" ${tipAttrs(it.title, costTxt, it.cost ? `${it.text}${it.left != null ? ` ${it.left} left.` : ''}` : '')} aria-label="${it.title}"><span class="ab-icon">${it.svg || it.icon}</span>${it.left != null ? `<b class="ab-left">${it.left}</b>` : ''}</button>`;
  }).join('');
}
function bottomBar(viewer) {
  const active = p(); const mine = viewer && viewer === active && humanMayAct();
  const playable = mine && (game.phase === 'build' || game.phase === 'roll') && viewer.devPlayedTurn !== game.turnCount && !game.offer;
  const yours = !!viewer && viewer === active && !active.bot && game.winner == null;
  let main;
  if (game.winner != null) main = '<button class="turn-btn summary" onclick="ui.statsOpen=true;render()" aria-label="Match summary">♛<small>Summary</small></button>';
  else if (mine && game.phase === 'roll') main = `<div class="turn-btn hint" ${tipAttrs('Roll the dice', 'Click the dice on the map. You may play one scroll before rolling.')}><span class="tb-arrow">⬉</span><small>Roll the dice</small></div>`;
  else if (mine && game.phase === 'build') main = `<button class="turn-btn end" onclick="next()" ${game.freeRoads ? 'disabled' : ''} ${tipAttrs('End turn', 'Pass play to the next player')}>⌛<small>End turn</small></button>`;
  else if (yours && game.rolling) main = '<div class="turn-btn hint"><span class="tb-arrow">🎲</span><small>Rolling…</small></div>';
  else main = `<div class="turn-btn waiting" ${tipAttrs(`${escH(active.name)}'s turn`, active.bot ? 'Planning their move…' : 'Waiting for them to play')}><i style="--color:${active.color}"></i><small>${active.bot ? 'Planning…' : 'Waiting'}</small></div>`;
  const turnBox = `<div class="bb-turn ${yours ? 'yours' : ''}" style="--color:${active.color}"><div class="bb-who"><i></i><b>${yours ? 'Your turn' : escH(active.name)}</b></div><small class="bb-phase">${game.winner != null ? 'Game over' : PHASE_TEXT[game.phase] || ''}</small></div>`;
  if (!viewer) return `<footer class="bottom-bar spectate"><div class="bb-full">${turnBox}<div class="bb-note">Bots only: you are watching this table.</div><div class="bb-actions">${main}</div></div></footer>`;
  const held = R.filter((k) => viewer.r[k] > 0);
  const hand = held.map((k) => handCard(k, viewer)).join('') + scrollHand(viewer, playable);
  const harbors = viewer.ports.length ? viewer.ports.map((k) => k === 'any' ? '3:1' : `2:1 ${NAME[k]}`).join(' · ') : '4:1 bank';
  return `<footer class="bottom-bar ${yours ? 'yours' : ''}" style="--color:${active.color}"><div class="bb-full">${turnBox}<div class="bb-hand" ${tipAttrs('Your hand', `${sum(viewer.r)} resource cards · trade rates: ${harbors}`)}>${hand || '<span class="empty-hand">No cards in hand</span>'}</div><div class="bb-actions">${actionButtons(viewer, mine)}${main}</div></div></footer>`;
}
// Incoming trade offers float over the top-right corner of the map; answering removes them.
function offerVisible() { return !!(game && !game.replay && game.offer && game.players.some((q) => !q.bot && q.id !== game.offer.from)); }
function tradeLane() {
  if (!offerVisible()) return '';
  const o = game.offer; const seller = game.players.find((q) => q.id === o.from); const humans = game.players.filter((q) => !q.bot && q !== seller);
  const many = humans.length > 1;
  return `<aside class="trade-overlay"><div class="offer-card" style="--color:${seller.color}"><header><i class="sw" style="--color:${seller.color}"></i><b>${escH(seller.name)}</b><span>wants to trade</span></header>` +
    `<div class="oc-row"><span class="oc-l">You get</span><span class="oc-c">${goodsHtml(o.give)}</span></div><div class="oc-row"><span class="oc-l">You give</span><span class="oc-c">${goodsHtml(o.want)}</span></div>` +
    `<div class="oc-actions">${humans.map((q) => { const ok = canPayMap(q, o.want); return `<button class="primary" onclick="acceptOffer(${q.id})" ${ok ? '' : 'disabled'} ${ok ? '' : tipAttrs('Not enough cards', `${escH(q.name)} doesn't hold these cards`)}>✓ Accept${many ? ` (${escH(q.name)})` : ''}</button>`; }).join('')}<button onclick="declineOffer()">✕ Decline</button></div></div></aside>`;
}
const PIPS = { 1: [5], 2: [3, 7], 3: [3, 5, 7], 4: [1, 3, 7, 9], 5: [1, 3, 5, 7, 9], 6: [1, 3, 4, 6, 7, 9] };
function dieFace(n, i) { return `<i class="mdie" data-die="${i}">${dieFaceInner(n)}</i>`; }
function dieFaceInner(n) { let h = ''; for (let k = 1; k <= 9; k++) h += `<b class="${(PIPS[n] || []).includes(k) ? (n === 1 ? 'on ace' : 'on') : ''}"></b>`; return h; }
// Dice sit in the map's bottom-right corner; on your roll they glow and clicking them rolls.
function diceTray(viewer) {
  const mine = !game.replay && humanMayAct() && viewer === p() && game.phase === 'roll' && !game.offer;
  const d = game.dice; const total = d ? d[0] + d[1] : null;
  const cls = ['dice-tray', mine ? 'can-roll' : '', game.rolling ? 'rolling' : '', !d ? 'blank' : '', diceLanded ? 'landed' : ''].join(' ');
  const tip = mine ? tipAttrs('Roll the dice', 'Click to roll. You may play one scroll first.') : d ? tipAttrs(`Last roll: ${total}`, `${d[0]} and ${d[1]}`) : tipAttrs('Dice', 'No roll yet');
  return `<div class="${cls}" ${mine ? 'role="button" tabindex="0" onclick="roll()" onkeydown="if(event.key===\'Enter\'||event.key===\' \')roll()"' : ''} ${tip}><div class="dt-dice">${dieFace(d ? d[0] : 0, 0)}${dieFace(d ? d[1] : 0, 1)}</div>${mine ? '<span class="dt-label">Roll</span>' : d && !game.rolling ? `<span class="dt-total ${total === 7 ? 'seven' : ''}">${total}</span>` : '<span class="dt-total dim">·</span>'}</div>`;
}
function boardControls(viewer) {
  const zoom = `<div class="zoom-ctl" role="group" aria-label="Map zoom"><button onclick="Zoom.zoomIn()" ${tipAttrs('Zoom in', 'Or pinch with two fingers on the touchpad or screen')}>＋</button><span class="z-level">${Math.round(Zoom.level() * 100)}%</span><button onclick="Zoom.zoomOut()" ${tipAttrs('Zoom out', 'Or pinch with two fingers')}>－</button><button onclick="Zoom.fit()" ${tipAttrs('Fit map', 'Show the whole island again')}>⤢</button></div>`;
  return zoom + diceTray(viewer);
}
function promptBar(viewer) {
  if (game.replay) return '';
  const x = p(); const mine = humanMayAct(); let html = '';
  const cancel = '<button onclick="tool=null;render()">Cancel</button>';
  if (game.winner != null) html = `<b>${escH(game.players.find((q) => q.id === game.winner).name)} wins the island!</b><button class="primary" onclick="ui.statsOpen=true;render()">Match summary</button>`;
  else if (game.phase === 'discard') {
    const who = discarder();
    if (who && !who.bot) { const need = Math.floor(sum(who.r) / 2); const got = sum(game.discardPick || empty()); html = `<b>${escH(who.name)}: discard ${need} cards</b><span>Use − and + under your cards (${got} of ${need}).</span><button class="primary" onclick="confirmDiscard()" ${got === need ? '' : 'disabled'}>Discard ${need}</button>`; } else if (who) html = `<span>${escH(who.name)} is discarding…</span>`;
  } else if (tool === 'robber-victim' && mine) {
    const tile = game.board.tiles.find((q) => q.id === game.robberTile); const victims = game.players.filter((q) => q !== x && sum(q.r) && tile.nodes.some((id) => q.settlements.includes(id) || q.cities.includes(id)));
    html = `<b>Choose who to rob</b>${victims.map((q) => `<button class="primary" onclick="finishRobber('${tile.id}',${q.id})"><i class="sw" style="--color:${q.color}"></i>${escH(q.name)} (${sum(q.r)})</button>`).join('')}<button onclick="finishRobber('${tile.id}',null)">Rob nobody</button>`;
  } else if (mine) {
    if (game.phase === 'setup') html = game.setupNode ? '<b>Place a road</b><span>Click a glowing edge next to your new settlement.</span>' : '<b>Place a settlement</b><span>Click a glowing junction.</span>';
    else if (game.phase === 'robber') html = '<b>Move the robber</b><span>Click a highlighted hex.</span>';
    else if (game.freeRoads) html = `<b>Road Building</b><span>Place ${game.freeRoads} free road${game.freeRoads > 1 ? 's' : ''}: click a glowing edge.</span>`;
    else if (tool === 'road') html = `<b>Build a road</b>${costChips(COSTS().road, x)}<span>Click a glowing edge.</span>${cancel}`;
    else if (tool === 'settlement') html = `<b>Build a settlement</b>${costChips(COSTS().settlement, x)}<span>Click a glowing junction.</span>${cancel}`;
    else if (tool === 'city') html = `<b>Build a city</b>${costChips(COSTS().city, x)}<span>Click one of your settlements.</span>${cancel}`;
  }
  const msg = message ? `<div class="prompt alert">${message}</div>` : '';
  return (html ? `<div class="prompt">${html}</div>` : '') + msg;
}
function gameScreen() {
  const viewer = viewerOf();
  let overlay = '';
  if (!game.replay && game.winner != null && ui.statsOpen && game.summary) {
    overlay = statsScreen(game.summary, { tab: ui.statsTab, close: 'ui.statsOpen=false;render()', showStyles: archetypeOn(), buttons: [
      game.save ? { label: 'Watch replay', on: 'watchFinishedReplay()', cls: 'primary' } : null,
      game.save ? { label: 'Export match file', on: 'exportFinished()' } : null,
      { label: 'View the board', on: 'ui.statsOpen=false;render()' }, { label: 'Main menu', on: 'leaveToMenu()' }].filter(Boolean) });
  }
  if (game.replay && HistoryUI.view === 'stats' && HistoryUI.openSave) overlay = statsScreen(HistoryUI.openSave.summary, { tab: HistoryUI.statsTab, tabCall: 'setHistoryStatsTab', close: "HistoryUI.view=null;render()", showStyles: archetypeOn(), buttons: [{ label: 'Back to replay', on: "HistoryUI.view=null;render()", cls: 'primary' }] });
  const bottom = game.replay ? `<footer class="bottom-bar replay">${Replay.controls()}</footer>` : bottomBar(viewer);
  const banner = game.replay ? replayBanner() : '';
  return `<div class="game v19 ${game.replay ? 'is-replay' : ''}">${topBar()}${leftRail()}<main class="board-area">${HearthRender.board()}<div class="prompts">${promptBar(viewer)}${banner}</div>${boardControls(viewer)}${tradeLane()}</main>${rightRail(viewer)}${bottom}${game.replay ? '' : tradeModal() + devModal()}${overlay}${settingsOverlay()}</div>`;
}
// Replay: a banner on the board says what just happened, with the dice for rolls.
const EVENT_ICON = { roll: '🎲', build: '⚒', trade: '⚖', robber: '☗', dev: '✒', award: '♛', win: '♛', turn: '↻', discard: '✂', note: '✎' };
function replayBanner() {
  if (!Replay.save) return '';
  const ev = Replay.idx ? Replay.save.replay.events[Replay.idx - 1] : null;
  const kind = ev ? ev.k : 'note';
  const dice = ''; // the dice tray on the map already shows the roll
  const actor = game.players[game.turn];
  return `<div class="prompt replay-banner k-${kind}"><span class="rb-ic">${EVENT_ICON[kind] || '✎'}</span>${actor ? `<i class="sw" style="--color:${actor.color}"></i>` : ''}${dice}<span class="rb-text">${Replay.caption()}</span></div>`;
}
function render() {
  if (typeof document === 'undefined' || !document.getElementById || !app) return;
  HearthSettings.apply();
  const keep = ['.chronicle .log', '#notice-list'].map((q) => { const el = document.querySelector(q); return el ? el.scrollTop : 0; });
  app.innerHTML = game ? gameScreen() : menuScreen();
  ['.chronicle .log', '#notice-list'].forEach((q, i) => { const el = document.querySelector(q); if (el) el.scrollTop = keep[i]; });
  if (typeof Tooltip !== 'undefined') Tooltip.refresh();
  placeToasts(); if (typeof Zoom !== 'undefined') Zoom.afterRender(); launchFx(); launchFly(); costCursor();
  diceWatch(); heraldWatch();
}
/* ---------------- dice tumbling ---------------- */
let diceLanded = false; let diceWasRolling = false; let diceSpin = 0;
function diceWatch() {
  const rolling = !!(game && game.rolling);
  if (rolling && !diceSpin) {
    const tick = () => { document.querySelectorAll('.dice-tray .mdie').forEach((el) => { el.innerHTML = dieFaceInner(1 + Math.floor(Math.random() * 6)); }); };
    tick(); diceSpin = setInterval(tick, 85);
  }
  if (!rolling && diceSpin) { clearInterval(diceSpin); diceSpin = 0; }
  if (diceWasRolling && !rolling) { diceLanded = true; setTimeout(() => { diceLanded = false; const t = document.querySelector('.dice-tray'); if (t) t.classList.remove('landed'); }, 700); const t = document.querySelector('.dice-tray'); if (t) t.classList.add('landed'); }
  diceWasRolling = rolling;
}

/* ---------------- heralds: big, short-lived announcements at the top of the map ---------------- */
const Herald = { q: [], busy: false, key: null, timer: 0 };
function heraldName(q) { const v = viewerOf(); return v && q && v.id === q.id ? 'You' : q ? q.name : 'Someone'; }
function heraldVerb(q, you, other) { const v = viewerOf(); return v && q && v.id === q.id ? you : other; }
function herald(kind, title, sub, color, icon) {
  if (typeof document === 'undefined' || !document.body || !game || game.replay) return;
  const h = { kind, title, sub: sub || '', color: color || '#c9a14a', icon, key: `${game.turnCount}|${game.turn}` };
  if (kind === 'turn') Herald.q.unshift(h); else Herald.q.push(h);
  if (Herald.q.length > 4) Herald.q.splice(4);
  if (!Herald.busy) { showHerald(); return; }
  // something new is waiting: cut a "your turn" banner short once it has been seen
  if (Herald.cur && Herald.cur.kind === 'turn') { const left = 700 - (Date.now() - Herald.cur.at); clearTimeout(Herald.timer); Herald.timer = setTimeout(hideHerald, Math.max(0, left)); }
}
const HERALD_ICON = { turn: '⚑', award: '♛', scroll: '✒', 'trade-ok': '⇄', 'trade-fail': '✕', steal: '☗' };
function hideHerald() {
  const el = document.getElementById('herald'); const m = HearthSettings.motion();
  if (el) { el.classList.remove('on'); el.classList.add('off'); }
  Herald.timer = setTimeout(showHerald, m.reduced ? 60 : 320);
}
function showHerald() {
  let h = Herald.q.shift();
  // a "your turn" banner is stale once play has moved on
  while (h && h.kind === 'turn' && game && h.key !== `${game.turnCount}|${game.turn}`) h = Herald.q.shift();
  let el = document.getElementById('herald');
  if (!h) { Herald.busy = false; Herald.cur = null; if (el) el.classList.remove('on'); return; }
  h.at = Date.now(); Herald.cur = h;
  Herald.busy = true;
  if (!el) { el = document.createElement('div'); el.id = 'herald'; el.setAttribute('role', 'status'); el.setAttribute('aria-live', 'polite'); document.body.appendChild(el); }
  const board = document.querySelector('.board-area'); const r = board ? board.getBoundingClientRect() : { left: 0, width: innerWidth, top: 50 };
  el.style.left = (r.left + r.width / 2) + 'px'; el.style.top = (r.top + 12) + 'px';
  const art = h.icon === 'road' ? IND_ART.road : h.icon === 'army' ? IND_ART.army : HERALD_ICON[h.kind] || '✦';
  el.className = `herald k-${h.kind}`; el.style.setProperty('--color', h.color);
  el.innerHTML = `<span class="hd-ic">${art}</span><div class="hd-text"><b class="hd-title">${h.title}</b>${h.sub ? `<span class="hd-sub">${h.sub}</span>` : ''}</div>`;
  void el.offsetWidth; el.classList.add('on');
  const m = HearthSettings.motion(); const hold = Math.max(1300, (h.kind === 'turn' ? 1700 : 2300) * Math.max(0.7, m.scale)) * (Herald.q.length > 1 ? 0.7 : 1);
  clearTimeout(Herald.timer);
  Herald.timer = setTimeout(hideHerald, h.kind === 'turn' && Herald.q.length ? 900 : hold);
}
// announce your turn whenever play passes to you
function heraldWatch() {
  if (!game || game.replay || game.winner != null) { Herald.key = null; return; }
  const key = `${game.turnCount}|${game.turn}`;
  if (Herald.key === key) return;
  Herald.key = key;
  const x = p(); const v = viewerOf();
  if (x && !x.bot && v && v.id === x.id) herald('turn', 'Your turn', game.phase === 'setup' ? (game.setupNode ? 'Place a road' : 'Place a settlement and a road') : 'Roll the dice to begin', x.color);
}

/* ---------------- cards moving between players, the bank and your hand ---------------- */
let pendingFly = [];
function flyAnchor(spec, k) {
  if (spec === 'bank') return document.querySelector(`.bank-card.${k}`) || document.querySelector('.bank-panel');
  const v = viewerOf();
  if (v && v.id === spec) return document.querySelector(`.bb-hand .rcard.${k}`) || document.querySelector('.bb-hand');
  return document.querySelector(`.profile[data-seat="${spec}"] .ind-goods`);
}
// call before the state change is rendered: start points are read from the current screen
function flyGoods(from, to, cards) {
  if (typeof document === 'undefined' || !document.body || !game || game.replay || !cards || !cards.length) return;
  const src = cards.map((k) => { const el = flyAnchor(from, k); if (!el) return null; const b = el.getBoundingClientRect(); return { x: b.left + b.width / 2, y: b.top + b.height / 2 }; });
  pendingFly.push({ from, to, cards, src });
}
function flyCardEl(k, color) {
  const el = document.createElement('div');
  if (k === '?') { el.className = 'fly-card back'; el.innerHTML = '<span class="fc-art">✦</span>'; }
  else { el.className = 'fly-card ' + k; el.innerHTML = `<span class="fc-art">${resIcon(k)}</span><span class="fc-name">${NAME[k]}</span>`; }
  if (color) el.style.setProperty('--owner', color);
  return el;
}
function launchFly() {
  if (!pendingFly.length) return; const list = pendingFly; pendingFly = [];
  requestAnimationFrame(() => requestAnimationFrame(() => {
    const m = HearthSettings.motion(); const dur = (m.reduced ? 450 : 900) * m.scale; const gap = (m.reduced ? 40 : 110) * m.scale; let i = 0;
    list.forEach((f) => f.cards.forEach((k, c) => {
      const s0 = f.src[c]; const target = flyAnchor(f.to, k); if (!s0 || !target) return;
      const tb = target.getBoundingClientRect(); const dx = tb.left + tb.width / 2 - s0.x; const dy = tb.top + tb.height / 2 - s0.y;
      const el = flyCardEl(k); el.style.left = (s0.x - 27) + 'px'; el.style.top = (s0.y - 37) + 'px'; document.body.appendChild(el);
      const frames = [{ transform: 'translate(0,0) scale(.7)', opacity: 0 }, { transform: 'translate(0,-10px) scale(1)', opacity: 1, offset: 0.15 }, { transform: `translate(${dx * 0.5}px,${dy * 0.5 - 30}px) scale(.9)`, opacity: 1, offset: 0.6 }, { transform: `translate(${dx}px,${dy}px) scale(.55)`, opacity: 0.25 }];
      const anim = el.animate ? el.animate(frames, { duration: dur, delay: i++ * gap, easing: 'cubic-bezier(.4,.1,.3,1)', fill: 'both' }) : null;
      const done = () => { el.remove(); const t = flyAnchor(f.to, k); if (t) { t.classList.add('got'); setTimeout(() => t.classList.remove('got'), 380); } };
      if (anim) anim.onfinish = done; else setTimeout(done, dur);
    }));
  }));
}
function placeToasts() { /* notices now live in the left rail */ }
function placeToastsOld() {
  const host = document.getElementById('toasts'); const slot = document.getElementById('toast-slot');
  if (!host) return;
  if (!slot) { host.style.display = 'none'; return; }
  const r = slot.getBoundingClientRect(); host.style.display = '';
  Object.assign(host.style, { left: r.left + 'px', top: r.top + 'px', width: r.width + 'px', height: Math.max(0, r.height) + 'px' });
}
if (typeof window !== 'undefined' && window.addEventListener) window.addEventListener('resize', () => { placeToasts(); });

/* ---------------- build-cost cursor ---------------- */
let cursorXY = null;
function costCursor() {
  const el = document.getElementById('cost-cursor');
  const show = game && !game.replay && humanMayAct() && ['road', 'settlement', 'city'].includes(tool) && !game.freeRoads && game.phase === 'build';
  if (!show) { if (el) el.classList.remove('on'); return; }
  let c = document.getElementById('cost-cursor');
  if (!c) { c = document.createElement('div'); c.id = 'cost-cursor'; document.body.appendChild(c); }
  const x = p(); const cost = COSTS()[tool]; const ok = paid(x, cost);
  c.innerHTML = `<span class="cc-title">${{ road: 'Road', settlement: 'Settlement', city: 'City' }[tool]}</span>${costChips(cost, x)}${ok ? '' : '<em>Not enough cards</em>'}`;
  c.classList.add('on');
  if (cursorXY) moveCost(cursorXY.x, cursorXY.y);
}
function moveCost(x, y) { const c = document.getElementById('cost-cursor'); if (!c) return; c.style.left = (x + 18) + 'px'; c.style.top = (y - 46) + 'px'; }
if (typeof document !== 'undefined' && document.addEventListener) {
  document.addEventListener('mousemove', (ev) => {
    cursorXY = { x: ev.clientX, y: ev.clientY };
    const c = document.getElementById('cost-cursor'); if (!c || !c.classList.contains('on')) return;
    const inBoard = ev.target.closest && ev.target.closest('.board-area');
    c.classList.toggle('away', !inBoard); moveCost(ev.clientX, ev.clientY);
  });
}

/* ---------------- resource card flights ---------------- */
function launchFx() { if (!game || !game.fx) return; const fx = game.fx; game.fx = null; requestAnimationFrame(() => requestAnimationFrame(() => spawnHarvestFx(fx))); }
function spawnHarvestFx(fx) {
  const svg = document.querySelector('.board-area svg.board');
  if (!svg || !fx || !fx.grants || !fx.grants.length) return;
  const m = HearthSettings.motion(); const box = svg.getBoundingClientRect(); const vb = svg.viewBox.baseVal;
  const sc = Math.min(box.width / vb.width, box.height / vb.height); const ox = box.left + (box.width - vb.width * sc) / 2; const oy = box.top + (box.height - vb.height * sc) / 2;
  const toScreen = (x, y) => { const [px, py] = HearthRender.project(x, y); return { x: ox + (px - vb.x) * sc, y: oy + (py - vb.y) * sc }; };
  const viewer = viewerOf();
  const dur = (m.reduced ? 520 : 1300) * m.scale; const gap = (m.reduced ? 50 : 170) * m.scale;
  let i = 0;
  fx.grants.forEach((g) => {
    for (let c = 0; c < g.amount; c++) {
      const node = g.node != null && game.board.nodes.find((z) => z.id === g.node);
      const start = node ? toScreen(g.x + (node.x - g.x) * 0.55, g.y + (node.y - g.y) * 0.55) : toScreen(g.x, g.y);
      const mineCard = !!viewer && viewer.id === g.playerId;
      const target = mineCard ? (document.querySelector(`.bb-hand .rcard.${g.resource}`) || document.querySelector('.bb-hand')) : document.querySelector(`.profile[data-seat="${g.playerId}"] .ind-goods`);
      if (!target) continue;
      const tb = target.getBoundingClientRect(); const tx = tb.left + tb.width / 2; const ty = tb.top + tb.height / 2;
      const owner = game.players.find((q) => q.id === g.playerId);
      const el = flyCardEl(g.resource, owner && owner.color); if (!mineCard) el.classList.add('theirs');
      el.style.left = (start.x - 27) + 'px'; el.style.top = (start.y - 37) + 'px';
      document.body.appendChild(el);
      const dx = tx - start.x; const dy = ty - start.y; const delay = i++ * gap;
      const frames = m.reduced
        ? [{ transform: 'translate(0,0) scale(.9)', opacity: 0 }, { transform: 'translate(0,0) scale(1)', opacity: 1, offset: 0.2 }, { transform: `translate(${dx}px,${dy}px) scale(.6)`, opacity: 0.9 }]
        : [{ transform: 'translate(0,0) scale(.4) rotate(-8deg)', opacity: 0 }, { transform: 'translate(0,-18px) scale(1.12) rotate(3deg)', opacity: 1, offset: 0.18 }, { transform: 'translate(0,-22px) scale(1.08) rotate(0deg)', opacity: 1, offset: 0.42 }, { transform: `translate(${dx * 0.55}px,${dy * 0.55 - 40}px) scale(.85) rotate(-4deg)`, opacity: 1, offset: 0.72 }, { transform: `translate(${dx}px,${dy}px) scale(.5) rotate(0deg)`, opacity: 0.2 }];
      const anim = el.animate ? el.animate(frames, { duration: dur, delay, easing: 'cubic-bezier(.4,.1,.3,1)', fill: 'both' }) : null;
      const done = () => { el.remove(); target.classList.add('got'); setTimeout(() => target.classList.remove('got'), 380); };
      if (anim) anim.onfinish = done; else setTimeout(done, dur + delay);
    }
  });
}

/* ---------------- game end ---------------- */
function onGameOver() {
  if (!game || game.over || game.replay) return;
  game.over = true;
  if (game.stats) game.stats.endedAt = Date.now();
  setTimeout(() => {
    if (!game || game.replay) return;
    Recorder.flush(game);
    game.summary = Stats.summary(game);
    try { game.save = HearthSave.buildSave(game, game.summary); } catch (err) { game.save = null; }
    if (game.save) Saves.store(game.save).then((where) => { if (game) game.saveWhere = where; }).catch(() => {});
    ui.statsOpen = true; ui.statsTab = 'summary';
    render();
  }, 1100);
}
function watchFinishedReplay() { if (!game || !game.save) return; const save = game.save; ui.statsOpen = false; ui.screen = 'replay'; HistoryUI.openSave = save; Replay.open(save); }
function exportFinished() { if (!game || !game.save) return; const save = game.save; HearthSave.encodeFile(save).then((blob) => { const a = document.createElement('a'); a.href = URL.createObjectURL(blob); a.download = HearthSave.fileName(save); document.body.appendChild(a); a.click(); setTimeout(() => { URL.revokeObjectURL(a.href); a.remove(); }, 2000); }); }
