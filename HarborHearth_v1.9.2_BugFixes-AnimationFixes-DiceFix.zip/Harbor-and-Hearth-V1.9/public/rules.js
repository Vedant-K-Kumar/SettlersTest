/* Harbor & Hearth V1.9 - rule configuration.
   One place for supply limits, deck composition, costs and piece limits so future modes,
   expansions and the map maker can swap in a different rule set without touching the engine. */
(function (root) {
  'use strict';
  const RESOURCES = ['wood', 'brick', 'wool', 'grain', 'ore'];
  const RULESETS = {
    standard: {
      id: 'standard',
      name: 'Standard (3-4 players)',
      victoryPoints: 10,
      // 19 of each resource = 95 cards. The bank can never create more than this.
      supply: { wood: 19, brick: 19, wool: 19, grain: 19, ore: 19 },
      // 25 progress (development) cards.
      deck: { knight: 14, road: 2, plenty: 2, monopoly: 2, victory: 5 },
      costs: {
        road: { wood: 1, brick: 1 },
        settlement: { wood: 1, brick: 1, wool: 1, grain: 1 },
        city: { grain: 2, ore: 3 },
        dev: { wool: 1, grain: 1, ore: 1 }
      },
      pieces: { settlement: 5, city: 4, road: 15 },
      discardOver: 7
    }
  };
  function get(id) { return RULESETS[id] || RULESETS.standard; }
  function register(ruleset) { RULESETS[ruleset.id] = ruleset; return ruleset; }
  function deckList(rules) { const out = []; Object.keys(rules.deck).forEach((k) => { for (let i = 0; i < rules.deck[k]; i++) out.push(k); }); return out; }
  function deckSize(rules) { return Object.values(rules.deck).reduce((a, b) => a + b, 0); }
  root.HEARTH_VERSION = '1.9';
  root.HearthRules = { VERSION: '1.9', RESOURCES, RULESETS, get, register, deckList, deckSize };
  if (typeof module !== 'undefined' && module.exports) module.exports = root.HearthRules;
})(typeof globalThis !== 'undefined' ? globalThis : this);
