/* Harbor & Hearth V1.9 - board renderer registry.
   A renderer turns the current board state into SVG and maps board coordinates to SVG
   coordinates (used for animations and the build-cost cursor). Renderers never change
   game state, so the map style can be switched at any time, including mid-game and in replays. */
(function (root) {
  'use strict';
  const modes = {};
  const HearthRender = {
    modes,
    register(id, def) { modes[id] = Object.assign({ id }, def); return modes[id]; },
    list() { return Object.values(modes); },
    current() {
      const want = (root.HearthSettings && root.HearthSettings.get('mapMode')) || 'iso';
      return modes[want] || modes.iso || Object.values(modes)[0];
    },
    board() { const r = HearthRender.current(); return r ? r.board() : ''; },
    project(x, y) { const r = HearthRender.current(); return r && r.project ? r.project(x, y) : [x, y]; }
  };
  root.HearthRender = HearthRender;
})(typeof globalThis !== 'undefined' ? globalThis : this);
