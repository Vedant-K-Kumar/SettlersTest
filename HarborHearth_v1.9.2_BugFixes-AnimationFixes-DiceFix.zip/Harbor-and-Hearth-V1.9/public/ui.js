/* Harbor & Hearth UI layer: resource card art, trade window, event notifications.
   Loaded before offline.js; everything here is called at runtime so it can use offline.js globals. */
let bankSel = { give: null, qty: 1, want: { wood: 0, brick: 0, wool: 0, grain: 0, ore: 0 } };

const DEV_ICON = (() => {
  const S = (body) => `<svg viewBox="0 0 48 48" aria-hidden="true">${body}</svg>`;
  return {
    knight: S('<path d="M16 40h16l-1.5-5h-13z" fill="#e7e3d4" stroke="#243036" stroke-width="1.4"/><path d="M18 35c1-8 5-13 8-18 3 3 7 4 9 3-1 5-1 9 0 15H18z" fill="#f7f4ea" stroke="#243036" stroke-width="1.4"/><path d="M24 17c2-4 6-6 8-6-1 3-1 5 1 7" fill="none" stroke="#243036" stroke-width="1.4"/><circle cx="31" cy="14" r="2.2" fill="#243036"/>'),
    road: S('<path d="M7 33h34v7H7z" fill="#8d5b34" stroke="#3a2414" stroke-width="1.4"/><path d="M9 28h30v5H9z" fill="#e2c089" stroke="#3a2414" stroke-width="1.2"/><path d="M14 31h4M22 31h4M30 31h4" stroke="#8d5b34" stroke-width="1.2"/>'),
    plenty: S('<path d="M24 7l3.2 8.2H36l-7 5.2 2.6 8.4L24 24.2 16.4 28.8 19 20.4 12 15.2h8.8z" fill="#f6d56a" stroke="#6b4a12" stroke-width="1.3"/><path d="M15 40h18" stroke="#6b4a12" stroke-width="2" stroke-linecap="round"/>'),
    monopoly: S('<circle cx="24" cy="22" r="11" fill="#f0c2b4" stroke="#5c241e" stroke-width="1.6"/><path d="M24 14v14M19 18h7.5a3.5 3.5 0 010 7H20" fill="none" stroke="#5c241e" stroke-width="2" stroke-linecap="round"/><path d="M14 38h20" stroke="#5c241e" stroke-width="1.6" stroke-linecap="round"/>'),
    victory: S('<path d="M24 6l3.4 9.2H37l-7.6 5.6 2.8 9L24 24.6 15.8 29.8l2.8-9L11 15.2h9.6z" fill="#f6d56a" stroke="#6d5016" stroke-width="1.3"/>')
  };
})();
const BUILD_ICON = {
  house: '<svg viewBox="0 0 48 48" aria-hidden="true"><path d="M8 24 L24 10 L40 24 V40 H8Z" fill="#f4e7c8" stroke="#5c3b22" stroke-width="1.6"/><rect x="20" y="28" width="8" height="12" fill="#5c3b22"/></svg>',
  city: '<svg viewBox="0 0 48 48" aria-hidden="true"><path d="M6 40V22L16 14V22L26 12V22L36 16V40Z" fill="#f4e7c8" stroke="#5c3b22" stroke-width="1.4"/><path d="M36 18h8v22h-8z" fill="#e7d3a4" stroke="#5c3b22" stroke-width="1.4"/></svg>',
  dev: '<svg viewBox="0 0 48 48" aria-hidden="true"><rect x="12" y="8" width="24" height="32" rx="2" fill="#f6e7b0" stroke="#6d5016" stroke-width="1.6"/><path d="M18 18h12M18 24h12M18 30h8" stroke="#6d5016" stroke-width="1.8" stroke-linecap="round"/></svg>'
};
function dcard(card, o = {}) {
  const title = { knight: 'Knight', road: 'Roads', plenty: 'Plenty', monopoly: 'Monopoly', victory: 'Victory' }[card] || card;
  const tag = o.on ? 'button' : 'div';
  return `<${tag} class="rcard dev dev-${card} ${o.cls || ''}"${o.on ? ` onclick="${o.on}"` : ''}${o.dis ? ' disabled' : ''}><span class="rc-art">${DEV_ICON[card] || ''}</span><span class="rc-name">${title}</span>${o.tag ? `<small class="rc-tag">${o.tag}</small>` : ''}</${tag}>`;
}
function buildIcon(kind) { return BUILD_ICON[kind] || ''; }

/* ---------- resource icons (48x48 flat illustrations) ---------- */
const ICON = (() => {
  const logEnd = (x, y) => `<circle cx="${x}" cy="${y}" r="10" fill="#8a5a30"/><circle cx="${x}" cy="${y}" r="7.2" fill="#e3ae70"/><circle cx="${x}" cy="${y}" r="4.2" fill="none" stroke="#b27a42" stroke-width="1"/><circle cx="${x}" cy="${y}" r="1.4" fill="#b27a42" stroke="none"/>`;
  const brick = (x, y, w, c) => `<rect x="${x}" y="${y}" width="${w}" height="10" rx="1.5" fill="${c}"/><path d="M${x + 1.5} ${y + 2.2}H${x + w - 1.5}" stroke="#fff" stroke-opacity=".35" stroke-width="1.4" stroke-linecap="round"/>`;
  let wheat = ''; [[24, 8, 0], [14, 13, -8], [34, 13, 8]].forEach(([tx, ty, rot]) => {
    let g = `<path d="M24 44L${tx} ${ty + 6}" stroke="#a37a22" stroke-width="1.8" fill="none" stroke-linecap="round"/>`;
    for (let i = 0; i < 4; i++) g += `<ellipse cx="${tx - 3.2}" cy="${ty + i * 5.2}" rx="2.3" ry="3.6" transform="rotate(-24 ${tx - 3.2} ${ty + i * 5.2})" fill="#f6d261"/><ellipse cx="${tx + 3.2}" cy="${ty + i * 5.2}" rx="2.3" ry="3.6" transform="rotate(24 ${tx + 3.2} ${ty + i * 5.2})" fill="#e7b844"/>`;
    wheat += g + `<ellipse cx="${tx}" cy="${ty - 3}" rx="2" ry="3.6" fill="#f6d261"/>`;
  });
  const S = b => `<svg viewBox="0 0 48 48" aria-hidden="true">${b}</svg>`;
  return {
    wood: S(`<g stroke="#4a2c14" stroke-width="1.3">${logEnd(14, 34)}${logEnd(34, 34)}${logEnd(24, 17)}</g>`),
    brick: S(`<g stroke="#5a2616" stroke-width="1.3" stroke-linejoin="round">${brick(3, 32, 20, '#cf6d44')}${brick(25, 32, 20, '#c25f3a')}${brick(3, 21, 9, '#d97a4e')}${brick(14, 21, 20, '#e0804f')}${brick(36, 21, 9, '#d97a4e')}${brick(3, 10, 20, '#c25f3a')}${brick(25, 10, 20, '#cf6d44')}</g>`),
    wool: S(`<g stroke="#9c9074" stroke-width="1.2"><path d="M15 38V43M33 38V43" stroke="#3b342d" stroke-width="3" stroke-linecap="round"/><g fill="#faf4e2"><circle cx="12" cy="24" r="8.5"/><circle cx="24" cy="15" r="10"/><circle cx="36" cy="24" r="8.5"/><circle cx="15" cy="32" r="8"/><circle cx="33" cy="32" r="8"/><circle cx="24" cy="29" r="9"/></g></g><ellipse cx="24" cy="31" rx="6.4" ry="6" fill="#3b342d"/><ellipse cx="16.5" cy="28" rx="2.6" ry="4" transform="rotate(30 16.5 28)" fill="#3b342d"/><ellipse cx="31.5" cy="28" rx="2.6" ry="4" transform="rotate(-30 31.5 28)" fill="#3b342d"/><circle cx="21.5" cy="29" r="1.3" fill="#fff"/><circle cx="26.5" cy="29" r="1.3" fill="#fff"/>`),
    grain: S(`<g stroke="#9a6f1c" stroke-width=".8">${wheat}</g><path d="M17 40Q24 36 31 40L28 44H20Z" fill="#b5812f" stroke="#6b4a15" stroke-width="1.2" stroke-linejoin="round"/>`),
    ore: S(`<g stroke="#2b3140" stroke-width="1.3" stroke-linejoin="round"><path d="M24 4L40 18L34 42H14L8 18Z" fill="#7f8fa6"/><path d="M24 4L8 18L24 24Z" fill="#c4d0df"/><path d="M24 4L40 18L24 24Z" fill="#9fb0c6"/><path d="M8 18L14 42L24 24Z" fill="#8798b0"/><path d="M40 18L34 42L24 24Z" fill="#5c6a82"/><path d="M14 42H34L24 24Z" fill="#6c7b93"/></g><path d="M18 13L22 10" stroke="#fff" stroke-width="2" stroke-linecap="round" opacity=".8"/>`)
  };
})();
const resIcon = k => ICON[k] || '';

function rcard(k, o = {}) {
  const tag = o.on ? 'button' : 'div', n = o.n;
  return `<${tag} class="rcard ${k} ${o.cls || ''} ${n === 0 ? 'zero' : ''}"${o.on ? ` onclick="${o.on}"` : ''}${o.dis ? ' disabled' : ''}><span class="rc-art">${resIcon(k)}</span><span class="rc-name">${NAME[k]}</span>${n != null ? `<span class="rc-n">${n}</span>` : ''}${o.tag ? `<small class="rc-tag">${o.tag}</small>` : ''}</${tag}>`;
}
const chip = (k, n = 1) => `<span class="chip ${k}">${resIcon(k)}<b>${n}</b></span>`;
const goodsHtml = m => R.filter(k => m[k]).map(k => chip(k, m[k])).join(' ') || '<em>nothing</em>';

/* ---------- event notifications ---------- */
const TOAST_ICON = {
  trade: '<span class="t-ic ok">&#10003;</span>', fail: '<span class="t-ic bad">&#10005;</span>', discard: '<span class="t-ic warn">7</span>',
  award: '<span class="t-ic award">&#9819;</span>',
  steal: '<span class="t-ic steal"><svg viewBox="-.2 -.35 .4 .42" width="22" height="24"><path d="M-.11 .03Q-.1-.12-.04-.2H.04Q.1-.12 .11 .03Z" fill="#eee"/><circle cy="-.27" r=".075" fill="#eee"/></svg></span>'
};
// Notices live in a scrollable box in the left rail (newest first). Each has an ✕; "Clear" empties the box.
var notices = []; let noticeSeq = 0;
function toast(kind, title, rows = [], opts = {}) {
  if (typeof game !== 'undefined' && game && game.replay) return;
  notices.unshift({ id: ++noticeSeq, kind, title, rows, big: !!opts.big, at: Date.now() });
  if (notices.length > 40) notices.length = 40;
  renderNotices(true);
}
function dismissNotice(id) { notices = notices.filter((n) => n.id !== id); renderNotices(); }
function clearNotices() { notices = []; renderNotices(); }
function noticeHtml(n) {
  const row = (r) => `<span class="n-row">${r.who ? `<b class="n-who">${r.who}</b>` : ''}${r.gain ? `<span class="n-gain">+ ${goodsHtml(r.gain)}</span>` : ''}${r.lose ? `<span class="n-lose">− ${goodsHtml(r.lose)}</span>` : ''}${r.text ? `<span class="n-text">${r.text}</span>` : ''}</span>`;
  return `<li class="notice k-${n.kind}${n.big ? ' big' : ''}" data-id="${n.id}">${TOAST_ICON[n.kind] || ''}<div class="n-body">${n.kind === 'trade' ? '' : `<strong>${n.title}</strong>`}${n.rows.map(row).join('')}</div><button class="n-x" onclick="dismissNotice(${n.id})" aria-label="Dismiss notice">&#10005;</button></li>`;
}
function noticesPanel() {
  return `<section class="notices"><header><span>Notices</span>${notices.length ? '<button onclick="clearNotices()">Clear</button>' : ''}</header><ol id="notice-list" class="notice-list">${notices.length ? notices.map(noticeHtml).join('') : '<li class="nl-empty">Trades, thefts and awards appear here.</li>'}</ol></section>`;
}
function renderNotices(fresh) {
  if (typeof document === 'undefined' || !document.getElementById) return;
  const box = document.querySelector('.notices'); if (!box) return;
  const list = document.getElementById('notice-list'); const top = list ? list.scrollTop : 0;
  box.outerHTML = noticesPanel();
  const nl = document.getElementById('notice-list'); if (nl) { nl.scrollTop = fresh ? 0 : top; if (fresh && nl.firstElementChild) nl.firstElementChild.classList.add('fresh'); }
}

/* ---------- trade window ---------- */
const bankRate = (x, k) => x.ports.includes(k) ? 2 : x.ports.includes('any') ? 3 : 4;
function bankSync() {
  const x = p(), g = bankSel.give;
  tradeSelection = { give: empty(), want: { ...bankSel.want } };
  if (g) tradeSelection.give[g] = bankRate(x, g) * bankSel.qty;
}
function bankPick(side, k) {
  if (side !== 'give') return;
  bankSel.give = bankSel.give === k ? null : k;
  bankSel.qty = 1;
  bankSel.want = empty();
  bankSync();
  render();
}
function bankRoom(x) {
  const g = bankSel.give;
  if (!g) return 1;
  const rate = bankRate(x, g);
  const fromHand = Math.floor(x.r[g] / rate);
  const fromBank = R.reduce((n, k) => n + (k === g ? 0 : game.bank[k]), 0);
  return Math.max(1, Math.min(fromHand, fromBank));
}
function bankQty(d) {
  const x = p();
  if (!bankSel.give) return;
  bankSel.qty = Math.max(1, Math.min(bankRoom(x), bankSel.qty + d));
  while (sum(bankSel.want) > bankSel.qty) {
    const k = R.find((q) => bankSel.want[q]);
    if (!k) break;
    bankSel.want[k]--;
  }
  bankSync();
  render();
}
function bankAdd(k) {
  const g = bankSel.give;
  if (!g || k === g || sum(bankSel.want) >= bankSel.qty || (bankSel.want[k] || 0) >= game.bank[k]) return;
  bankSel.want[k]++;
  bankSync();
  render();
}
function bankSub(k) {
  if (!bankSel.want[k]) return;
  bankSel.want[k]--;
  bankSync();
  render();
}
function offAdj(side, k, d) { let cap = side === 'give' ? p().r[k] : 6; tradeSelection[side][k] = Math.max(0, Math.min(cap, tradeSelection[side][k] + d)); render(); }
function closeTrade() { tool = null; render(); }

function tradeModal() {
  if (!game || !['bank', 'offer'].includes(tool)) return '';
  const x = p(), bankMode = tool === 'bank', sel = tradeSelection;
  let giveCards, getCards, why, summary = '', sub;
  if (bankMode) {
    const g = bankSel.give, q = bankSel.qty, rate = g ? bankRate(x, g) : 0, chosen = sum(bankSel.want);
    giveCards = R.map(k => `<div class="tm-cell">${rcard(k, { n: x.r[k], cls: 'big' + (g === k ? ' sel' : ''), on: `bankPick('give','${k}')`, dis: x.r[k] < bankRate(x, k), tag: `${bankRate(x, k)} : 1` })}</div>`).join('');
    getCards = R.map(k => {
      const n = bankSel.want[k] || 0, canAdd = g && k !== g && chosen < q && game.bank[k] > n;
      return `<div class="tm-cell">${rcard(k, { n, cls: 'big' + (n ? ' sel' : ''), tag: game.bank[k] ? '' : 'None left' })}<div class="tm-step"><button onclick="bankSub('${k}')" ${n <= 0 ? 'disabled' : ''} aria-label="Fewer ${NAME[k]}">&minus;</button><button onclick="bankAdd('${k}')" ${canAdd ? '' : 'disabled'} aria-label="More ${NAME[k]}">+</button></div></div>`;
    }).join('');
    why = !g ? 'Tap the resource you will give.' : chosen !== q ? `Choose ${q} card${q > 1 ? 's' : ''} to receive. Mixed resources are allowed.` : x.r[g] < rate * q ? `You need ${rate * q} ${NAME[g]}.` : R.some(k => (bankSel.want[k] || 0) > game.bank[k]) ? 'The bank has run out of that resource.' : '';
    if (g) summary = `${chip(g, rate * q)} <span class="tm-arrow">&rarr;</span> ${goodsHtml(bankSel.want)}<span class="tm-qty">Cards received <button onclick="bankQty(-1)" ${q <= 1 ? 'disabled' : ''}>&minus;</button><b>${q}</b><button onclick="bankQty(1)" ${q >= bankRoom(x) ? 'disabled' : ''}>+</button></span>`;
    sub = 'The rate on each card is what one received card costs. Four ore at a 2:1 ore harbor can come back as one brick and one wood.';
  } else {
    const cell = (side, k) => { const have = x.r[k], n = sel[side][k], cap = side === 'give' ? have : 6; return `<div class="tm-cell">${rcard(k, { n, cls: 'big' + (n ? ' sel' : '') })}<div class="tm-step"><button onclick="offAdj('${side}','${k}',-1)" ${n <= 0 ? 'disabled' : ''} aria-label="Fewer ${NAME[k]}">&minus;</button><button onclick="offAdj('${side}','${k}',1)" ${n >= cap ? 'disabled' : ''} aria-label="More ${NAME[k]}">+</button></div>${side === 'give' ? `<small class="tm-have">have ${have}</small>` : ''}</div>`; };
    giveCards = R.map(k => cell('give', k)).join(''); getCards = R.map(k => cell('want', k)).join('');
    why = !sum(sel.give) ? 'Add at least one card to give.' : !sum(sel.want) ? 'Add at least one card to ask for.' : R.some(k => sel.give[k] && sel.want[k]) ? 'You cannot give and ask for the same resource.' : '';
    if (sum(sel.give) || sum(sel.want)) summary = `${goodsHtml(sel.give)} <span class="tm-arrow">&rarr;</span> ${goodsHtml(sel.want)}`;
    sub = 'Use + and - to build the deal. A bot accepts if it can afford it and the deal helps its plan.';
  }
  return `<div class="tm-back"><div class="tm" role="dialog" aria-label="${bankMode ? 'Bank trade' : 'Player trade'}"><header><h2>${bankMode ? 'Bank trade' : 'Offer a trade'}</h2><button class="tm-x" onclick="closeTrade()" aria-label="Close">&#10005;</button></header><p class="tm-sub">${sub}</p>` +
    `<div class="tm-cols"><section><h3>You give</h3><div class="tm-row">${giveCards}</div></section><section><h3>${bankMode ? 'You receive' : 'You ask for'}</h3><div class="tm-row">${getCards}</div></section></div>` +
    `<div class="tm-sum">${summary || '<span class="tm-why">&nbsp;</span>'}</div><footer><span class="tm-why">${why}</span><button class="tm-go" onclick="${bankMode ? 'bank()' : 'submitOffer()'}" ${why ? 'disabled' : ''}>${bankMode ? 'Confirm trade' : 'Send offer'}</button><button class="tm-cancel" onclick="closeTrade()">Cancel</button></footer></div></div>`;
}

function devModal() {
  if (!game || !game.pick) return '';
  if (game.pick.card === 'plenty') {
    const chosen = game.pick.chosen, used = empty();
    chosen.forEach((k) => used[k]++);
    const cards = R.map((k) => {
      const left = game.bank[k] - used[k];
      return `<div class="tm-cell">${rcard(k, { cls: 'big' + (used[k] ? ' sel' : ''), on: `pickBank('${k}')`, dis: chosen.length >= 2 || left < 1, tag: used[k] ? `Take ${used[k]}` : game.bank[k] ? '' : 'None left' })}</div>`;
    }).join('');
    const why = chosen.length < 2 ? `Choose ${2 - chosen.length} more from the bank. The same resource twice is allowed.` : '';
    const summary = chosen.length ? goodsHtml(used) : 'Nothing chosen yet.';
    return `<div class="tm-back"><div class="tm" role="dialog" aria-label="Year of Plenty"><header><h2>Year of Plenty</h2><button class="tm-x" onclick="cancelDev()" aria-label="Close">&#10005;</button></header><p class="tm-sub">Take two cards from the bank.</p><div class="tm-row">${cards}</div><div class="tm-sum">${summary}</div><footer><span class="tm-why">${why}</span><button class="tm-go" onclick="confirmPlenty()" ${why ? 'disabled' : ''}>Take cards</button><button class="tm-cancel" onclick="unpickDev()" ${chosen.length ? '' : 'disabled'}>Undo</button><button class="tm-cancel" onclick="cancelDev()">Cancel</button></footer></div></div>`;
  }
  const cards = R.map((k) => `<div class="tm-cell">${rcard(k, { cls: 'big', on: `confirmMonopoly('${k}')`, tag: 'Take all' })}</div>`).join('');
  return `<div class="tm-back"><div class="tm" role="dialog" aria-label="Monopoly"><header><h2>Monopoly</h2><button class="tm-x" onclick="cancelDev()" aria-label="Close">&#10005;</button></header><p class="tm-sub">Name one resource. You receive every card of that resource the other players hold.</p><div class="tm-row">${cards}</div><footer><span class="tm-why">Choose one resource.</span><button class="tm-cancel" onclick="cancelDev()">Cancel</button></footer></div></div>`;
}
