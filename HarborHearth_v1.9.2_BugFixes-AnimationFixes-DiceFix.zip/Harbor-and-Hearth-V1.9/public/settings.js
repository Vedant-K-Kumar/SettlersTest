/* Harbor & Hearth V1.9 - settings, animation preferences and keyboard shortcuts.
   Settings persist in localStorage. They only change presentation and controls, never game rules. */
(function (root) {
  'use strict';
  const KEY = 'hh.settings.v1';
  const PALETTE = [
    { id: 'crimson', color: '#b73d2e', name: 'Crimson' }, { id: 'azure', color: '#236f93', name: 'Azure' },
    { id: 'saffron', color: '#d69b27', name: 'Saffron' }, { id: 'moss', color: '#5a7f43', name: 'Moss' },
    { id: 'plum', color: '#7b4b94', name: 'Plum' }, { id: 'ember', color: '#d0662a', name: 'Ember' },
    { id: 'slate', color: '#55606e', name: 'Slate' }, { id: 'ivory', color: '#e8dcc0', name: 'Ivory' }
  ];
  const DEFAULTS = {
    mapMode: 'iso', showArchetypes: true, playerColor: '#b73d2e',
    animSpeed: 'normal', reducedMotion: false, noDecor: false,
    keys: {}, chronicleOpen: true, difficulty: 'normal', lastNames: ['', '', '', '']
  };
  let data = load();
  function load() {
    try { const raw = root.localStorage && root.localStorage.getItem(KEY); return Object.assign({}, DEFAULTS, raw ? JSON.parse(raw) : {}); } catch (err) { return Object.assign({}, DEFAULTS); }
  }
  function save() { try { if (root.localStorage) root.localStorage.setItem(KEY, JSON.stringify(data)); } catch (err) { /* storage full or blocked */ } }
  function apply() {
    if (typeof document === 'undefined' || !document.body || !document.body.classList) return;
    const b = document.body.classList;
    ['anim-slow', 'anim-normal', 'anim-fast'].forEach((c) => b.remove(c));
    b.add('anim-' + data.animSpeed);
    b.toggle('reduced-motion', !!data.reducedMotion);
    b.toggle('no-decor', !!data.noDecor);
    b.toggle('hide-archetypes', !data.showArchetypes);
    document.body.style.setProperty('--anim-scale', String(animScale()));
  }
  function animScale() { return data.animSpeed === 'slow' ? 1.6 : data.animSpeed === 'fast' ? 0.55 : 1; }
  const HearthSettings = {
    PALETTE, DEFAULTS,
    get(k) { return data[k]; },
    set(k, v) { data[k] = v; save(); apply(); },
    all() { return Object.assign({}, data); },
    apply, animScale,
    // Gameplay feedback (card flights, dice) stays on unless the player picks reduced animations.
    motion() { return { scale: animScale(), reduced: !!data.reducedMotion, decor: !data.noDecor && !data.reducedMotion }; }
  };
  root.HearthSettings = HearthSettings;
  if (typeof document !== 'undefined' && document.addEventListener) {
    if (document.body) apply(); else document.addEventListener('DOMContentLoaded', apply);
  }

  /* ---------------- keyboard shortcuts ---------------- */
  // Each action: id, label, run(). All are unbound by default; players choose their own keys.
  const ACTIONS = [
    { id: 'roll', label: 'Roll the dice', run: () => root.uiAction && root.uiAction('roll') },
    { id: 'end', label: 'End turn', run: () => root.uiAction && root.uiAction('end') },
    { id: 'road', label: 'Build road', run: () => root.uiAction && root.uiAction('road') },
    { id: 'settlement', label: 'Build settlement', run: () => root.uiAction && root.uiAction('settlement') },
    { id: 'city', label: 'Build city', run: () => root.uiAction && root.uiAction('city') },
    { id: 'dev', label: 'Buy a scroll', run: () => root.uiAction && root.uiAction('dev') },
    { id: 'bank', label: 'Open bank trade', run: () => root.uiAction && root.uiAction('bank') },
    { id: 'offer', label: 'Open player trade', run: () => root.uiAction && root.uiAction('offer') },
    { id: 'cancel', label: 'Cancel current action', run: () => root.uiAction && root.uiAction('cancel') },
    { id: 'chronicle', label: 'Show or hide the Chronicle', run: () => root.uiAction && root.uiAction('chronicle') },
    { id: 'zoomIn', label: 'Zoom in on the map', run: () => root.uiAction && root.uiAction('zoomIn') },
    { id: 'zoomOut', label: 'Zoom out', run: () => root.uiAction && root.uiAction('zoomOut') },
    { id: 'zoomFit', label: 'Fit the whole map', run: () => root.uiAction && root.uiAction('zoomFit') },
    { id: 'map', label: 'Switch 2D / 2.5D map', run: () => root.uiAction && root.uiAction('map') },
    { id: 'settings', label: 'Open settings', run: () => root.uiAction && root.uiAction('settings') }
  ];
  const Keys = {
    ACTIONS,
    capturing: null,
    label(code) {
      if (!code) return '';
      return code.replace(/^Key/, '').replace(/^Digit/, '').replace(/^Numpad/, 'Num ').replace(/^Arrow/, 'Arrow ');
    },
    binding(id) { return (data.keys || {})[id] || null; },
    startCapture(id) { Keys.capturing = id; if (root.render) root.render(); },
    clear(id) { const k = Object.assign({}, data.keys); delete k[id]; HearthSettings.set('keys', k); if (root.render) root.render(); },
    assign(id, code) {
      const k = Object.assign({}, data.keys);
      let moved = null;
      Object.keys(k).forEach((other) => { if (k[other] === code && other !== id) { moved = other; delete k[other]; } });
      k[id] = code; HearthSettings.set('keys', k);
      return moved;
    }
  };
  root.HearthKeys = Keys;
  if (typeof document !== 'undefined' && document.addEventListener) {
    document.addEventListener('keydown', (ev) => {
      if (Keys.capturing) {
        ev.preventDefault();
        if (ev.code === 'Escape') { Keys.capturing = null; if (root.render) root.render(); return; }
        if (['ShiftLeft', 'ShiftRight', 'ControlLeft', 'ControlRight', 'AltLeft', 'AltRight', 'MetaLeft', 'MetaRight'].includes(ev.code)) return;
        const id = Keys.capturing; Keys.capturing = null;
        const moved = Keys.assign(id, ev.code);
        root.keyNotice = moved ? `${Keys.label(ev.code)} moved from “${ACTIONS.find((a) => a.id === moved).label}”.` : '';
        if (root.render) root.render();
        return;
      }
      const tag = (ev.target && ev.target.tagName) || '';
      if (['INPUT', 'TEXTAREA', 'SELECT'].includes(tag) || ev.ctrlKey || ev.metaKey || ev.altKey) return;
      const keys = data.keys || {};
      const id = Object.keys(keys).find((a) => keys[a] === ev.code);
      if (!id) return;
      const action = ACTIONS.find((a) => a.id === id);
      if (action) { ev.preventDefault(); action.run(); }
    });
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
