const app = document.querySelector('#app');
const R = ['wood', 'brick', 'wool', 'grain', 'ore'];
const NAME = { wood:'Wood', brick:'Brick', wool:'Wool', grain:'Grain', ore:'Ore' };
const COLORS = ['#b73d2e', '#236f93', '#d69b27', '#5a7f43'];
const TERRAINS = ['wood','wood','wood','wood','grain','grain','grain','grain','wool','wool','wool','wool','brick','brick','brick','ore','ore','ore','desert'];
const NUMBERS = [2,3,3,4,4,5,5,6,6,8,8,9,9,10,10,11,11,12];
let game = null, tool = null, message = '', botTimer = null, audio = null, tradeSelection = { give: {wood:0,brick:0,wool:0,grain:0,ore:0}, want: {wood:0,brick:0,wool:0,grain:0,ore:0} };
const BOT_DELAY = 1250;
const empty = () => ({wood:0,brick:0,wool:0,grain:0,ore:0});
const sum = x => R.reduce((n,k)=>n+(x[k]||0),0);
const goods = x => R.filter(k=>x[k]).map(k=>`${x[k]} ${NAME[k]}`).join(', ') || 'nothing';
const rand = () => { try { const a = new Uint32Array(1); globalThis.crypto.getRandomValues(a); return a[0] / 4294967296; } catch (err) { return Math.random(); } };
// Fisher-Yates. v7 used sort(()=>Math.random()-.5), which is biased: in Chrome it tends to leave items near
// their starting positions, so boards, the progress deck, and any ordering built with it were not truly random.
const shuffle = x => { const a = [...x]; for (let i = a.length - 1; i > 0; i--) { const j = Math.floor(rand() * (i + 1)); [a[i], a[j]] = [a[j], a[i]]; } return a; };
const key = (x,y) => `${Math.round(x*100)/100},${Math.round(y*100)/100}`;
const edgeKey = (a,b) => [a,b].sort().join('|');
const px = (q,r) => ({x:Math.sqrt(3)*(q+r/2),y:1.5*r});
function prepareSound(){try{audio=new (window.AudioContext||window.webkitAudioContext)();audio.resume()}catch{audio=null}}
function sound(kind){if(!audio)return;let now=audio.currentTime,notes=kind==='road'?[160,205]:kind==='settlement'?[392,523,659]:[130,165,210,260];notes.forEach((frequency,index)=>{let oscillator=audio.createOscillator(),gain=audio.createGain();oscillator.type=kind==='dice'?'square':'triangle';oscillator.frequency.setValueAtTime(frequency,now+index*.06);gain.gain.setValueAtTime(.0001,now+index*.06);gain.gain.exponentialRampToValueAtTime(kind==='dice'?.035:.06,now+index*.06+.01);gain.gain.exponentialRampToValueAtTime(.0001,now+index*.06+.11);oscillator.connect(gain).connect(audio.destination);oscillator.start(now+index*.06);oscillator.stop(now+index*.06+.13)})}
function createBoard(mapId){return HearthMaps.build(mapId||'standard',shuffle)}
function start(){
  prepareSound();
  const rules=HearthRules.get('standard');
  const names=[...document.querySelectorAll('[data-name]')].map((input,index)=>input.value.trim()||`Hearthkeeper ${index+1}`);
  const difficulty=(typeof HearthSettings!=='undefined'&&HearthSettings.get('difficulty'))||'normal';
  // colours: the first human gets the preferred colour, everyone else takes the remaining palette colours
  const pref=(typeof HearthSettings!=='undefined'&&HearthSettings.get('playerColor'))||COLORS[0];
  const palette=[pref,...COLORS.filter(c=>c!==pref),...((typeof HearthSettings!=='undefined'?HearthSettings.PALETTE.map(c=>c.color):[]).filter(c=>c!==pref&&!COLORS.includes(c)))];
  const seats=names.slice(0,4).map((name,i)=>({id:i,name,bot:name.startsWith('Hearthkeeper'),color:null,r:empty(),roads:[],settlements:[],cities:[],ports:[],dev:[],newDev:[],secretVp:[],knights:0,vp:0}));
  let pi=0;const firstHuman=seats.find(q=>!q.bot);if(firstHuman)firstHuman.color=palette[pi++];seats.forEach(q=>{if(!q.color)q.color=palette[pi++]});
  const bots=seats.filter(q=>q.bot),styles=difficulty==='easy'?[]:HearthAI.assignStyles(bots.length,rand);
  bots.forEach((q,i)=>{if(styles[i]){q.style=styles[i];q.styleLabel=HearthArchetypes.get(styles[i]).label}});
  // Turn order: unbiased shuffle of the seats. players[0] places first and takes the first roll.
  const players=shuffle(seats);
  game={board:createBoard('standard'),rules,rulesId:rules.id,difficulty,players,turn:0,phase:'setup',setup:[...players.keys(),...players.keys()].map((x,i)=>i<players.length?x:players.length*2-1-i),step:0,setupNode:null,bank:{...rules.supply},deck:shuffle(HearthRules.deckList(rules)),log:['The first settlement awaits.'],longest:null,largest:null,freeRoads:0,winner:null,offer:null,turnCount:0,discardQueue:[],discardPick:empty(),pick:null,devUsed:{road:0,plenty:0,monopoly:0},ai:{snap:{},est:{}}};
  game.turn=game.setup[0];
  Stats.init(game);Recorder.start(game);
  note(`Turn order: ${players.map(q=>q.name).join(' &rarr; ')}. ${players[0].name} places first.`);
  tool=null;maybeBot();render();
}
function p(){return game.players[game.turn]}; function n(id){return game.board.nodes.find(x=>x.id===id)}; function e(id){return game.board.edges.find(x=>x.id===id)};
function owner(node){return game.players.find(x=>x.settlements.includes(node)||x.cities.includes(node))};
function adj(node){return game.board.edges.filter(x=>x.a===node||x.b===node)}; function near(node){return adj(node).map(x=>x.a===node?x.b:x.a)};
function note(x){game.log.unshift(x);game.log=game.log.slice(0,400);if(typeof Recorder!=='undefined')Recorder.note(game,x)}; function paid(x,c){return R.every(k=>x.r[k]>=(c[k]||0))}; function take(x,c){R.forEach(k=>x.r[k]-=c[k]||0)}; function give(x,c){R.forEach(k=>x.r[k]+=c[k]||0)};
function freeNode(id){return !owner(id)&&near(id).every(x=>!owner(x))}; function canSet(x,id){return freeNode(id)&&(game.phase==='setup'?!game.setupNode:adj(id).some(z=>x.roads.includes(z.id)))};
function canRoad(x,id){let z=e(id);if(!z||game.players.some(q=>q.roads.includes(id)))return false;if(game.phase==='setup')return game.setupNode&&(z.a===game.setupNode||z.b===game.setupNode);return [z.a,z.b].some(a=>{let o=owner(a);return (!o||o===x)&&(x.settlements.includes(a)||x.cities.includes(a)||adj(a).some(q=>x.roads.includes(q.id)))});}
function score(x){return x.settlements.length+x.cities.length*2+x.vp+(game.longest===x.id?2:0)+(game.largest===x.id?2:0)};
function ports(x,id){game.board.ports.forEach(q=>{let z=e(q.edge);if((z.a===id||z.b===id)&&!x.ports.includes(q.type))x.ports.push(q.type)})}
function placeSet(id){let x=p();if(game.phase==='setup'&&game.setupNode)return say('Place the road that leaves this settlement.');if(game.phase!=='setup'&&x.settlements.length>=5)return say('All five houses are on the board. Upgrade one to a city to free a house.');if(!canSet(x,id))return say('Settlements require an empty junction, clear of neighboring settlements, and connected to your road after setup.');let c={wood:1,brick:1,wool:1,grain:1};if(game.phase!=='setup'){if(!paid(x,c))return say('A settlement costs 1 Wood, 1 Brick, 1 Wool, and 1 Grain.');take(x,c);give({r:game.bank},c);Stats.res(game,x.id,'spent',c)}x.settlements.push(id);Stats.count(game,x.id,'built','settlement');ports(x,id);game.setupNode=id;if(game.phase==='setup'&&x.settlements.length===2){n(id).tiles.forEach(tid=>{let t=game.board.tiles.find(q=>q.id===tid);if(t.terrain!=='desert'&&game.bank[t.terrain]){x.r[t.terrain]++;game.bank[t.terrain]--;Stats.res(game,x.id,'setup',t.terrain,1)}})}sound('settlement');note(`${x.name} raises a settlement.`);tool=null;awards();if(game.phase!=='setup')win(x);render();if(game.phase==='setup'&&x.bot)maybeBot()}
function placeRoad(id){let x=p();if(x.roads.length>=15)return say('All fifteen roads are on the board.');if(!canRoad(x,id))return say('Roads must join your network and may not pass through another settlement.');let c={wood:1,brick:1};if(!game.freeRoads&&game.phase!=='setup'){if(!paid(x,c))return say('A road costs 1 Wood and 1 Brick.');take(x,c);give({r:game.bank},c);Stats.res(game,x.id,'spent',c)}x.roads.push(id);Stats.count(game,x.id,'built','road');let wasFree=game.freeRoads>0;if(game.freeRoads)game.freeRoads--;sound('road');note(`${x.name} lays ${wasFree?'a free road':'a road'}.`);tool=null;if(wasFree&&game.freeRoads>0){if(x.roads.length<15&&game.board.edges.some(z=>canRoad(x,z.id))){if(!x.bot)tool='road'}else{game.freeRoads=0;note(`${x.name} has nowhere left to place a free road.`)}}let wasSetup=game.phase==='setup';if(wasSetup){game.step++;if(game.step===game.setup.length){game.phase='roll';game.turn=game.setup[0];note(`${p().name} begins the first harvest.`)}else{game.turn=game.setup[game.step];game.setupNode=null;note(`${p().name} places a settlement.`)}}else{awards();win(x)}render();if(wasSetup&&p().bot)maybeBot()}
function city(id){let x=p(),c={grain:2,ore:3};if(x.cities.length>=4)return say('All four cities are on the board.');if(!x.settlements.includes(id)||!paid(x,c))return say('A city upgrades your settlement for 2 grain and 3 ore.');take(x,c);give({r:game.bank},c);Stats.res(game,x.id,'spent',c);Stats.count(game,x.id,'built','city');x.settlements=x.settlements.filter(q=>q!==id);x.cities.push(id);note(`${x.name} builds a city.`);win(x);tool=null;render()}
function roll(){if(game.phase!=='roll'||game.rolling)return;let one=1+Math.floor(rand()*6),two=1+Math.floor(rand()*6),v=one+two;game.rolling=true;game.dice=[one,two];sound('dice');render();const wait=(typeof HearthSettings!=='undefined'&&HearthSettings.get('reducedMotion'))?300:720;setTimeout(()=>{game.last=v;game.rolling=false;Stats.roll(game,v);if(v===7){note(`${p().name} rolls 7.`);let order=game.players.map(q=>q.id);order=[...order.slice(game.turn),...order.slice(0,game.turn)];game.discardQueue=order.filter(id=>sum(game.players.find(q=>q.id===id).r)>((game.rules&&game.rules.discardOver)||7));game.discardPick=empty();if(game.discardQueue.length){game.phase='discard';note('A seven: anyone with more than seven cards discards half.');advanceDiscard()}else{game.phase='robber';tool='robber'}}else{produce(v);game.phase='build'}render();maybeBot()},wait)}
// Production with a finite bank (standard rules): if the bank cannot pay everyone owed a resource,
// nobody receives it, unless only one player is owed, who then takes whatever is left.
function produce(v){
  const roller=p(),tiles=game.board.tiles.filter(t=>t.number===v),owed={},plan=[];
  tiles.forEach(t=>{if(t.id===game.board.robber)return;game.players.forEach(x=>t.nodes.forEach(id=>{let a=x.settlements.includes(id)?1:x.cities.includes(id)?2:0;if(a){owed[t.terrain]=owed[t.terrain]||{};owed[t.terrain][x.id]=(owed[t.terrain][x.id]||0)+a;plan.push({playerId:x.id,resource:t.terrain,amount:a,x:t.center.x,y:t.center.y,node:id})}}))});
  const got={},notes=[],allowed={};
  Object.keys(owed).forEach(k=>{const ids=Object.keys(owed[k]).map(Number),need=ids.reduce((s,id)=>s+owed[k][id],0);
    if(need<=game.bank[k])ids.forEach(id=>{allowed[k+id]=owed[k][id]});
    else if(ids.length===1){allowed[k+ids[0]]=game.bank[k];notes.push(game.bank[k]?`The bank is running out of ${NAME[k]}: ${game.players.find(q=>q.id===ids[0]).name} takes the last of it.`:`There is no ${NAME[k]} left in the bank.`)}
    else notes.push(`There is not enough ${NAME[k]} left in the bank for everyone, so no one receives ${NAME[k]}.`)});
  const grants=[];
  plan.forEach(g=>{let left=allowed[g.resource+g.playerId]||0,n=Math.min(left,g.amount);if(n<=0)return;allowed[g.resource+g.playerId]-=n;const x=game.players.find(q=>q.id===g.playerId);x.r[g.resource]+=n;game.bank[g.resource]-=n;got[x.id]=got[x.id]||empty();got[x.id][g.resource]+=n;Stats.res(game,x.id,'production',g.resource,n);grants.push({...g,amount:n})});
  const blocked=tiles.find(t=>t.id===game.board.robber&&t.nodes.some(id=>owner(id)));
  const parts=game.players.filter(q=>got[q.id]).map(q=>`<b>${q.name}</b> ${goodsHtml(got[q.id])}`);
  note(`${roller.name} rolls ${v}. ${parts.length?parts.join('; '):'No one collects.'}${blocked?` The robber blocks the ${NAME[blocked.terrain]||blocked.terrain} hex.`:''}`);
  notes.forEach(t=>{note(t);toast('fail','Bank shortage',[{text:t}])});
  game.fx={tiles:tiles.map(t=>t.id),grants};if(typeof Recorder!=='undefined')Recorder.fx(game,grants,tiles.map(t=>t.id));
}
function discarder(){return game.players.find(x=>x.id===(game.discardQueue||[])[0])}
function advanceDiscard(){if(!game||game.phase!=='discard')return;while(game.discardQueue.length){let x=discarder();if(!x||!x.bot)return;let amount=Math.floor(sum(x.r)/2),pick=botDiscard(x,amount);R.forEach(k=>{x.r[k]-=pick[k];game.bank[k]+=pick[k]});Stats.res(game,x.id,'discarded',pick);note(`${x.name} discards ${goodsHtml(pick)}.`);game.discardQueue.shift()}game.phase='robber';tool='robber';game.discardPick=empty()}
function adjustDiscard(k,d){let x=discarder();if(!x||x.bot||game.phase!=='discard')return;if(!game.discardPick)game.discardPick=empty();let need=Math.floor(sum(x.r)/2),next=(game.discardPick[k]||0)+d;if(next<0||next>x.r[k])return;if(sum(game.discardPick)-(game.discardPick[k]||0)+next>need)return;game.discardPick[k]=next;render()}
function confirmDiscard(){let x=discarder();if(!x||x.bot)return;let need=Math.floor(sum(x.r)/2);if(sum(game.discardPick)!==need||!canPayMap(x,game.discardPick))return say(`Discard exactly ${need} cards you hold.`);R.forEach(k=>{x.r[k]-=game.discardPick[k];game.bank[k]+=game.discardPick[k]});Stats.res(game,x.id,'discarded',game.discardPick);note(`${x.name} discards ${goodsHtml(game.discardPick)}.`);game.discardQueue.shift();game.discardPick=empty();advanceDiscard();render();maybeBot()}
function finishRobber(tileId,victimId){let actor=p(),victim=game.players.find(x=>x.id===victimId);game.board.robber=tileId;Stats.count(game,actor.id,'robberMoves');if(victim&&victim!==actor){trackSync();let cards=R.flatMap(k=>Array(victim.r[k]).fill(k)),taken=cards[Math.floor(rand()*cards.length)];if(taken){const v=viewerSeat(),seen=v===actor.id||v===victim.id;flyG(victim.id,actor.id,[seen?taken:'?']);if(seen)hx('steal',v===actor.id?`You steal ${NAME[taken]}`:`${actor.name} steals your ${NAME[taken]}`,v===actor.id?`from ${victim.name}`:'The robber strikes',actor.color);victim.r[taken]--;actor.r[taken]++;trackSteal(actor,victim,taken);Stats.res(game,actor.id,'stolenIn',taken,1);Stats.res(game,victim.id,'stolenOut',taken,1);Stats.count(game,actor.id,'steals');Stats.count(game,victim.id,'robbed');note(`${actor.name} robs ${victim.name}.`);toast('steal','Robber strikes!',[{who:actor.name,text:`Took a card from ${victim.name}.`}])}}else note(`${actor.name} moves the guard without a theft.`);game.phase=game.afterRobber||'build';game.afterRobber=null;tool=null;game.robberTile=null;render();maybeBot()}
function robber(id){if(game.phase!=='robber'||id===game.board.robber)return;let t=game.board.tiles.find(x=>x.id===id),victims=game.players.filter(x=>x!==p()&&sum(x.r)&&t.nodes.some(a=>x.settlements.includes(a)||x.cities.includes(a)));if(!p().bot&&victims.length){game.robberTile=id;tool='robber-victim';render();return}let victim=victims.sort((a,b)=>sum(b.r)-sum(a.r))[0];finishRobber(id,victim?victim.id:null)}
function buy(){let x=p(),c=(game.rules&&game.rules.costs.dev)||{wool:1,grain:1,ore:1};if(game.phase!=='build')return say('Buy a scroll after you roll.');if(!paid(x,c)||!game.deck.length)return say(game.deck.length?'A scroll costs wool, grain, and ore.':'The scroll deck is empty.');take(x,c);give({r:game.bank},c);Stats.res(game,x.id,'spent',c);let card=game.deck.pop();Stats.count(game,x.id,'devBought',card);if(card==='victory'){x.secretVp.push(card);if(!x.bot)toast('award','Victory point!',[{who:x.name,text:'It counts toward your renown right away and stays hidden from the others until you win.'}])}else x.newDev.push(card);note(`${x.name} buys a scroll.`);win(x);render()}
function revealVp(){let x=p();if(!x||x.bot)return;let i=x.newDev.indexOf('victory');if(i>=0)x.newDev.splice(i,1);else if(x.secretVp&&x.secretVp.length)x.secretVp.pop();else return;x.vp++;note(`${x.name} reveals a victory point.`);win(x);render()}
function beginTrade(kind){if(game.pick)return;tool=kind;tradeSelection={give:empty(),want:empty()};bankSel={give:null,qty:1,want:empty()};render()}
function chooseTrade(side,resource){if(!['bank','offer'].includes(tool))return;let ceiling=side==='give'?p().r[resource]:4;tradeSelection[side][resource]=tradeSelection[side][resource]>=ceiling?0:tradeSelection[side][resource]+1;render()}
function bank(){let x=p(),g=bankSel.give,q=bankSel.qty,want=bankSel.want,rate=bankRate(x,g);if(!g||sum(want)!==q||want[g]||x.r[g]<rate*q||R.some(k=>(want[k]||0)>game.bank[k]))return say('Choose a resource to give and exactly that many different or matching cards to receive.');flyG(x.id,'bank',Array(Math.min(rate*q,8)).fill(g));flyG('bank',x.id,cardList(want));hx('trade-ok','Trade successful',`${vb(x,'You give','Gives')} ${chip(g,rate*q)} for ${goodsHtml(want)}`,'#3f6d40');x.r[g]-=rate*q;game.bank[g]+=rate*q;Stats.res(game,x.id,'bankOut',g,rate*q);Stats.res(game,x.id,'bankIn',want);Stats.count(game,x.id,'bankTrades');R.forEach(k=>{x.r[k]+=want[k]||0;game.bank[k]-=want[k]||0});note(`${x.name} trades ${chip(g,rate*q)} for ${goodsHtml(want)} at the bank.`);toast('trade','Harbor trade',[{who:x.name,gain:want,lose:{[g]:rate*q}}]);tool=null;render()}
function canPayMap(player, map){return R.every(k=>player.r[k]>=(map[k]||0))}
function acceptOffer(playerId){let offer=game.offer,buyer=game.players.find(x=>x.id===playerId),seller=game.players.find(x=>x.id===offer?.from);if(!offer||!buyer||!seller)return;if(!canPayMap(buyer,offer.want)||!canPayMap(seller,offer.give))return toast('fail','Trade failed',[{who:seller.name+' & '+buyer.name,text:'One side no longer has the cards for this deal.'}]);flyG(seller.id,buyer.id,cardList(offer.give));flyG(buyer.id,seller.id,cardList(offer.want));if(!seller.bot||!buyer.bot){const v=viewerSeat(),me=v===seller.id?seller:v===buyer.id?buyer:null,other=me===seller?buyer:seller;hx('trade-ok','Trade successful',me?`You give ${goodsHtml(me===seller?offer.give:offer.want)} and get ${goodsHtml(me===seller?offer.want:offer.give)} from ${other.name}`:`${seller.name} and ${buyer.name} make a deal`,'#3f6d40')}R.forEach(k=>{seller.r[k]-=offer.give[k]||0;buyer.r[k]+=offer.give[k]||0;buyer.r[k]-=offer.want[k]||0;seller.r[k]+=offer.want[k]||0});Stats.res(game,seller.id,'tradeOut',offer.give);Stats.res(game,seller.id,'tradeIn',offer.want);Stats.res(game,buyer.id,'tradeOut',offer.want);Stats.res(game,buyer.id,'tradeIn',offer.give);Stats.count(game,seller.id,'trades');Stats.count(game,buyer.id,'trades');note(`${buyer.name} accepts ${seller.name}'s trade: ${goodsHtml(offer.give)} for ${goodsHtml(offer.want)}.`);toast('trade','Trade',[{who:`${seller.name} ⇄ ${buyer.name}`,gain:offer.want,lose:offer.give}]);game.offer=null;render();maybeBot()}
function declineOffer(){if(!game.offer)return;let offer=game.offer,seller=game.players.find(x=>x.id===offer.from);note(`${seller.name}'s trade offer goes unanswered.`);toast('fail','Offer declined',[{who:seller.name,text:`${goodsHtml(offer.give)} for ${goodsHtml(offer.want)} was not accepted.`}]);hx('trade-fail','Trade declined',`${seller.name}'s offer was turned down`,'#8d251d');if(seller.bot)seller.tradeDeclinedTurn=game.turnCount;game.offer=null;render();maybeBot()}
function submitOffer(){let give={...tradeSelection.give},want={...tradeSelection.want},seller=p();if(!sum(give)||!sum(want)||!canPayMap(seller,give)||R.some(k=>give[k]&&want[k]))return say('Choose cards to give and different cards to ask for, and only offer cards you hold.');game.offer={from:seller.id,give,want};let best=null;game.players.forEach(b=>{if(!b.bot||b===seller||!canPayMap(b,want))return;let s=HearthAI.acceptTrade(aiState(b),{give,want},game.players.indexOf(seller));if(s>0&&(!best||s>best.s))best={b,s}});if(best){tool=null;tradeSelection={give:empty(),want:empty()};acceptOffer(best.b.id)}else{note(`${seller.name}'s trade is declined: no bot can afford it or wants it.`);toast('fail','No deal',[{who:seller.name,text:`${goodsHtml(give)} for ${goodsHtml(want)}: no bot could afford it or saw value in it.`}]);hx('trade-fail','Trade not accepted','No one took your offer','#8d251d');game.offer=null;tool=null;render()}}
function next(){if(game.freeRoads&&game.phase==='build'&&(p().roads.length>=15||!game.board.edges.some(z=>canRoad(p(),z.id))))game.freeRoads=0;if(game.phase!=='build'||game.freeRoads)return say(game.freeRoads?'Place the remaining free roads.':'Roll before ending your turn.');let x=p();x.newDev.forEach(card=>{if(card==='victory')x.secretVp.push(card);else x.dev.push(card)});x.newDev=[];tool=null;game.turn=(game.turn+1)%game.players.length;game.turnCount++;game.phase='roll';note(`${p().name}'s turn begins.`);render();maybeBot()}
function play(card,choice){
  let x=p();
  if(!x.dev.includes(card)||card==='victory'||['setup','discard','robber','done'].includes(game.phase))return;
  // v7 only stopped bots from playing several progress cards in one turn; the rule now applies to everyone.
  if(x.devPlayedTurn===game.turnCount)return say('Only one scroll may be played each turn.');
  if(!x.bot&&card==='plenty'){game.pick={card:'plenty',chosen:[]};tool=null;render();return}
  if(!x.bot&&card==='monopoly'){game.pick={card:'monopoly',chosen:[]};tool=null;render();return}
  x.dev.splice(x.dev.indexOf(card),1);
  x.devPlayedTurn=game.turnCount;Stats.count(game,x.id,'devPlayed',card);
  if(card==='knight'){
    x.knights++;game.afterRobber=game.phase==='roll'?'roll':'build';game.phase='robber';tool='robber';note(`${x.name} sends the guard.`);hx('scroll',`${nm(x)} ${vb(x,'play','plays')} a Knight`,'The robber moves',x.color);awards();
  }
  if(card==='road'){game.devUsed.road++;const legal=game.board.edges.some(z=>canRoad(x,z.id));game.freeRoads=legal?Math.max(0,Math.min(2,15-x.roads.length)):0;note(`${x.name} plays Road Building.`);hx('scroll',`${nm(x)} ${vb(x,'play','plays')} Road Building`,'Two free roads',x.color);if(game.freeRoads&&!x.bot)tool='road';if(!legal)say('There is no legal place for a free road.')}
  if(card==='plenty'){
    game.devUsed.plenty++;
    let picks=Array.isArray(choice)&&choice.length===2?choice:(HearthAI.plentyPick(aiState(x))||['grain','ore']),got=empty();
    picks.forEach(k=>{if(R.includes(k)&&game.bank[k]>0){x.r[k]++;game.bank[k]--;got[k]++}});Stats.res(game,x.id,'plenty',got);plentyFx(x,got);
    note(`${x.name} takes ${goodsHtml(got)} from the bank.`);
  }
  if(card==='monopoly'){
    game.devUsed.monopoly++;
    let k=R.includes(choice)?choice:(HearthAI.monopolyPick(aiState(x))||'ore'),got=0;
    monoFx(x,k);game.players.forEach(q=>{if(q!==x){got+=q.r[k];if(q.r[k])Stats.res(game,q.id,'monoOut',k,q.r[k]);q.r[k]=0}});Stats.res(game,x.id,'monoIn',k,got);x.r[k]+=got;note(`${x.name} claims every ${NAME[k]} (${got}).`);
  }
  awards();win(x);render();
}
function cancelDev(){game.pick=null;render()}
function pickBank(k){if(!game.pick||game.pick.card!=='plenty'||game.pick.chosen.length>=2)return;let used=empty();game.pick.chosen.forEach(q=>used[q]++);if(game.bank[k]-used[k]<1)return say('The bank has no more of that card.');game.pick.chosen.push(k);render()}
function unpickDev(){if(game.pick&&game.pick.chosen.length){game.pick.chosen.pop();render()}}
function confirmPlenty(){let x=p();if(!game.pick||game.pick.card!=='plenty'||!x.dev.includes('plenty'))return;if(x.devPlayedTurn===game.turnCount)return say('Only one scroll may be played each turn.');let chosen=game.pick.chosen;if(chosen.length!==2)return say('Choose two cards from the bank.');let need=empty();chosen.forEach(k=>need[k]++);if(R.some(k=>game.bank[k]<need[k]))return say('The bank does not have those cards.');x.dev.splice(x.dev.indexOf('plenty'),1);x.devPlayedTurn=game.turnCount;game.devUsed.plenty++;Stats.count(game,x.id,'devPlayed','plenty');plentyFx(x,need);R.forEach(k=>{x.r[k]+=need[k];game.bank[k]-=need[k]});note(`${x.name} takes ${goodsHtml(need)} from the bank.`);game.pick=null;awards();win(x);render()}
function confirmMonopoly(k){let x=p();if(!game.pick||game.pick.card!=='monopoly'||!x.dev.includes('monopoly')||!R.includes(k))return;if(x.devPlayedTurn===game.turnCount)return say('Only one scroll may be played each turn.');x.dev.splice(x.dev.indexOf('monopoly'),1);x.devPlayedTurn=game.turnCount;game.devUsed.monopoly++;Stats.count(game,x.id,'devPlayed','monopoly');let got=0;monoFx(x,k);game.players.forEach(q=>{if(q!==x){got+=q.r[k];if(q.r[k])Stats.res(game,q.id,'monoOut',k,q.r[k]);q.r[k]=0}});Stats.res(game,x.id,'monoIn',k,got);x.r[k]+=got;note(`${x.name} claims every ${NAME[k]} (${got}).`);game.pick=null;awards();win(x);render()}
function roadLen(x){let best=0,owned=new Set(x.roads);function walk(node,used){let o=owner(node);if(o&&o!==x&&used.size)return used.size;let r=used.size;adj(node).forEach(z=>{if(owned.has(z.id)&&!used.has(z.id)){let u=new Set(used);u.add(z.id);r=Math.max(r,walk(z.a===node?z.b:z.a,u))}});return r}x.roads.forEach(id=>{let z=e(id);best=Math.max(best,walk(z.a,new Set),walk(z.b,new Set))});return best}
function awards(){
  if(!game.players.length)return;
  const prevL=game.longest,prevA=game.largest;
  let roads=game.players.map(x=>({id:x.id,length:roadLen(x)})),top=Math.max(...roads.map(x=>x.length)),leaders=roads.filter(x=>x.length===top);
  if(top<5)game.longest=null;
  else if(leaders.some(x=>x.id===game.longest)){} // The incumbent keeps the award on a tie.
  else if(leaders.length===1)game.longest=leaders[0].id;
  else game.longest=null;
  let armies=game.players.map(x=>({id:x.id,knights:x.knights})),maxArmy=Math.max(...armies.map(x=>x.knights)),armyLeaders=armies.filter(x=>x.knights===maxArmy);
  if(maxArmy<3)game.largest=null;
  else if(armyLeaders.some(x=>x.id===game.largest)){} // The incumbent keeps the award on a tie.
  else if(armyLeaders.length===1)game.largest=armyLeaders[0].id;
  else game.largest=null;
  if(game.longest!==prevL)announceAward('Longest Road',game.longest,prevL);
  if(game.largest!==prevA)announceAward('Largest Army',game.largest,prevA);
}
function announceAward(label,now,before){if(game.replay)return;const nw=game.players.find(q=>q.id===now),old=game.players.find(q=>q.id===before);let text=nw&&old?`${nw.name} takes the ${label} from ${old.name}!`:nw?`${nw.name} claims the ${label}!`:`${old?old.name:'Someone'} loses the ${label}. No one holds it now.`;note(`<b>${text}</b>`);hx('award',label,nw&&old?`${nm(nw)} ${vb(nw,'take','takes')} it from ${old.name} · +2 renown`:nw?`${nm(nw)} ${vb(nw,'claim','claims')} it · +2 renown`:`${old?nm(old):'Someone'} ${old?vb(old,'lose','loses'):'loses'} it`,(nw||old||{}).color,label==='Longest Road'?'road':'army');toast('award',label,[{who:(nw||old||{}).name||'',text:nw?`+2 renown for ${nw.name}.`:'The award returns to the table.'}],{big:true})}
function hiddenVp(x){return (x.secretVp||[]).length+x.newDev.filter(card=>card==='victory').length}
function totalVp(x){return score(x)+hiddenVp(x)}
function win(x){awards();const target=(game.rules&&game.rules.victoryPoints)||10;if(game.winner!=null||x!==p())return;if(totalVp(x)>=target){let revealed=hiddenVp(x);if(revealed){x.newDev=x.newDev.filter(card=>card!=='victory');x.secretVp=[];x.vp+=revealed;note(`${x.name} reveals ${revealed} hidden victory point${revealed>1?'s':''}.`)}game.winner=x.id;game.phase='done';tool=null;note(`<b>${x.name} wins the island!</b>`);if(typeof onGameOver==='function')onGameOver()}}
/* ---------- strategic bots (Normal): the brain lives in ai.js (HearthAI); this layer adapts and executes ---------- */
function trackPlayers(){return game.players.map(q=>({id:q.id,hand:q.r}))}
function trackSync(){if(!game.ai)game.ai={snap:{},est:{}};HearthAI.Track.sync(game.ai,trackPlayers())}
function trackSteal(thief,victim,res){HearthAI.Track.steal(game.ai,trackPlayers(),thief.id,victim.id,res)}
function devPoolFor(x){
  const mine={};[...x.dev,...x.newDev,...(x.secretVp||[])].forEach(c=>{mine[c]=(mine[c]||0)+1});
  const used=game.devUsed||{road:0,plenty:0,monopoly:0};
  return HearthAI.devPool({knightsPlayed:game.players.reduce((t,q)=>t+q.knights,0),roadPlayed:used.road,plentyPlayed:used.plenty,monopolyPlayed:used.monopoly,victoryShown:game.players.reduce((t,q)=>t+q.vp,0),mine});
}
function seatIndex(id){return id==null?null:game.players.findIndex(q=>q.id===id)}
// What a bot is allowed to know: its own hand, public board state, card counts, and its card-tracking
// estimate of every opponent hand (built only from public events plus its own thefts).
function aiState(x){
  trackSync();
  const est=HearthAI.Track.view(game.ai,x.id),flags=x.aiTurn&&x.aiTurn.turn===game.turnCount?x.aiTurn:{};
  return {board:game.board,bank:{...game.bank},meIndex:game.players.indexOf(x),longest:seatIndex(game.longest),largest:seatIndex(game.largest),phase:game.phase,freeRoads:game.freeRoads||0,deckCount:game.deck.length,devPlayed:x.devPlayedTurn===game.turnCount,setupOrder:game.setup,setupStep:game.step,setupNode:game.setupNode,flags,devPool:devPoolFor(x),
    players:game.players.map(q=>({id:q.id,bot:q.bot,style:q.style,r:q===x?{...q.r}:{...empty(),...(est[q.id]||{})},cards:sum(q.r),roads:[...q.roads],settlements:[...q.settlements],cities:[...q.cities],ports:[...q.ports],knights:q.knights,vp:score(q),devHidden:q===x?0:devCount(q),dev:q===x?[...q.dev]:[],newDev:q===x?[...q.newDev]:[],hiddenVp:q===x?hiddenVp(q):0}))};
}
function botDiscard(x,amount){
  let pick=null;try{pick=HearthAI.discard(aiState(x),amount)}catch(err){pick=null}
  if(!pick||sum(pick)!==amount||R.some(k=>(pick[k]||0)>x.r[k]||(pick[k]||0)<0)){pick=empty();let left=amount;while(left){let k=R.filter(q=>x.r[q]>pick[q]).sort((a,b)=>(x.r[b]-pick[b])-(x.r[a]-pick[a]))[0];pick[k]++;left--}}
  return {...empty(),...pick};
}
function botFlags(x){if(!x.aiTurn||x.aiTurn.turn!==game.turnCount)x.aiTurn={turn:game.turnCount,bankTrades:0,proposals:0,steps:0,humanAsked:false};return x.aiTurn}
function botBank(x,giveK,getK){
  const rate=bankRate(x,giveK);
  if(!R.includes(giveK)||!R.includes(getK)||giveK===getK||x.r[giveK]<rate||game.bank[getK]<1)return false;
  flyG(x.id,'bank',Array(Math.min(rate,4)).fill(giveK));flyG('bank',x.id,[getK]);
  x.r[giveK]-=rate;game.bank[giveK]+=rate;Stats.res(game,x.id,'bankOut',giveK,rate);Stats.res(game,x.id,'bankIn',getK,1);Stats.count(game,x.id,'bankTrades');x.r[getK]++;game.bank[getK]--;
  note(`${x.name} trades ${chip(giveK,rate)} for ${chip(getK,1)} at the harbor.`);toast('trade','Harbor trade',[{who:x.name,gain:{[getK]:1},lose:{[giveK]:rate}}]);
  return true;
}
function swapGoods(a,b,give,want){R.forEach(k=>{a.r[k]-=give[k]||0;b.r[k]+=give[k]||0;b.r[k]-=want[k]||0;a.r[k]+=want[k]||0});Stats.res(game,a.id,'tradeOut',give);Stats.res(game,a.id,'tradeIn',want);Stats.res(game,b.id,'tradeOut',want);Stats.res(game,b.id,'tradeIn',give);Stats.count(game,a.id,'trades');Stats.count(game,b.id,'trades')}
// Returns true when the bot is now waiting on a human's answer.
function botPropose(x,offers,f){
  const me=game.players.indexOf(x);
  for(const o of offers){
    let best=null;
    game.players.forEach(b=>{if(b===x||!b.bot||!canPayMap(b,o.want)||score(b)>=8)return;const s=HearthAI.acceptTrade(aiState(b),o,me);if(s>0&&(!best||s>best.s))best={b,s}});
    if(best&&canPayMap(x,o.give)){
      flyG(x.id,best.b.id,cardList(o.give));flyG(best.b.id,x.id,cardList(o.want));
      swapGoods(x,best.b,o.give,o.want);
      note(`${best.b.name} accepts ${x.name}'s trade: ${goodsHtml(o.give)} for ${goodsHtml(o.want)}.`);
      toast('trade','Trade',[{who:`${x.name} ⇄ ${best.b.name}`,gain:o.want,lose:o.give}]);
      return false;
    }
  }
  if(f.humanAsked)return false;
  const est=HearthAI.Track.view(game.ai,x.id),humans=game.players.filter(q=>!q.bot&&score(q)<8&&sum(q.r)>0);
  for(const o of offers){
    const k=R.find(r=>o.want[r]);
    if(humans.some(h=>((est[h.id]||{})[k]||0)>=0.75)){
      f.humanAsked=true;game.offer={from:x.id,give:o.give,want:o.want};x.tradeRequestedTurn=game.turnCount;
      note(`${x.name} requests ${goodsHtml(o.want)} for ${goodsHtml(o.give)}.`);render();return true;
    }
  }
  return false;
}
function continueBot(){if(game&&game.winner==null&&p().bot&&!game.offer&&!botTimer)botTimer=setTimeout(()=>{botTimer=null;maybeBot()},BOT_DELAY)}
function maybeBot(){
  if(game&&!game.replay&&game.difficulty==='easy'&&typeof E_maybeBot==='function')return E_maybeBot();
  if(!game||game.winner!=null||!p().bot||game.offer||botTimer)return;
  botTimer=setTimeout(()=>{
    botTimer=null;let x=p();if(!x||!x.bot||game.winner!=null||game.offer)return;
    try{botStep(x)}catch(err){if(typeof console!=='undefined')console.error(err);note(`${x.name} pauses to think.`);if(game.phase==='build'&&game.winner==null){game.freeRoads=0;next()}}
  },BOT_DELAY);
}
function botStep(x){
  if(game.phase==='setup'){
    if(!game.setupNode){
      let node=HearthAI.setupSettlement(aiState(x));
      if(!node||!canSet(x,node))node=(game.board.nodes.find(q=>canSet(x,q.id))||{}).id;
      placeSet(node);
    }else{
      let edge=HearthAI.setupRoad(aiState(x));
      if(!edge||!canRoad(x,edge))edge=(game.board.edges.find(q=>canRoad(x,q.id))||{}).id;
      placeRoad(edge);
    }
    return;
  }
  if(game.phase==='discard'){advanceDiscard();if(game.phase==='discard'){render();return}}
  if(game.phase==='roll'){
    const a=HearthAI.decide(aiState(x));
    if(a.type==='play'&&a.card==='knight'&&x.dev.includes('knight')&&x.devPlayedTurn!==game.turnCount){play('knight');continueBot();return}
    roll();return;
  }
  if(game.phase==='robber'){
    const r=HearthAI.robber(aiState(x));
    if(r&&r.tile!==game.board.robber){const v=r.victim==null?null:game.players[r.victim];finishRobber(r.tile,v&&sum(v.r)?v.id:null)}
    else{const t=game.board.tiles.find(q=>q.id!==game.board.robber&&q.terrain==='desert')||game.board.tiles.find(q=>q.id!==game.board.robber);finishRobber(t.id,null)}
    return;
  }
  if(game.phase!=='build')return;
  const f=botFlags(x);
  if(++f.steps>45){game.freeRoads=0;next();return}
  const a=HearthAI.decide(aiState(x));
  x.lastPlan=a.why||a.type;
  switch(a.type){
    case 'road':placeRoad(a.edge);break;
    case 'settlement':placeSet(a.node);break;
    case 'city':city(a.node);break;
    case 'buyDev':buy();break;
    case 'play':play(a.card,a.pick);break;
    case 'bank':if(botBank(x,a.give,a.get))f.bankTrades++;else f.bankTrades=99;break;
    case 'propose':f.proposals++;if(botPropose(x,a.offers,f))return;break;
    case 'skipFree':game.freeRoads=0;break;
    default:next();return;
  }
  if(game.winner==null)continueBot();
}



function humanMayAct(){return game&&!game.replay&&game.winner==null&&!game.rolling&&p()&&!p().bot}
function clickNode(id){if(!humanMayAct())return;if(tool==='city')city(id);else if(tool==='settlement'||(game.phase==='setup'&&!game.setupNode))placeSet(id)}
function clickRoad(id){if(!humanMayAct())return;if(tool==='road'||game.phase==='setup')placeRoad(id)}
function clickTile(id){if(!humanMayAct())return;if(tool==='robber')robber(id)}
function devCount(q){return q.dev.length+q.newDev.length+(q.secretVp||[]).length}
function say(x){message=x;render();setTimeout(()=>{if(message===x){message='';render()}},3500)}render();

// presentation hooks (no-ops when the table UI is not loaded, e.g. in headless tests)
function hx(...a){try{if(typeof herald==='function')herald(...a)}catch(err){}}
function flyG(...a){try{if(typeof flyGoods==='function')flyGoods(...a)}catch(err){}}
function nm(q){return typeof heraldName==='function'?heraldName(q):q.name}
function vb(q,you,other){return typeof heraldVerb==='function'?heraldVerb(q,you,other):other}
function viewerSeat(){const v=typeof viewerOf==='function'?viewerOf():null;return v?v.id:null}
function cardList(m){return R.flatMap(k=>Array((m&&m[k])||0).fill(k))}
function plentyFx(x,got){flyG('bank',x.id,cardList(got));hx('scroll',`${nm(x)} ${vb(x,'play','plays')} Year of Plenty`,`${vb(x,'Take','Takes')} ${goodsHtml(got)} from the bank`,x.color)}
function monoFx(x,k){let total=0,mine=0;const v=viewerSeat();game.players.forEach(q=>{if(q!==x&&q.r[k]){total+=q.r[k];if(q.id===v)mine=q.r[k];flyG(q.id,x.id,Array(Math.min(q.r[k],8)).fill(k))}});hx('scroll',`${nm(x)} ${vb(x,'play','plays')} Monopoly`,`${vb(x,'Take','Takes')} every ${NAME[k]}: ${total} card${total===1?'':'s'}${mine?` (${mine} of yours)`:''}`,x.color)}
