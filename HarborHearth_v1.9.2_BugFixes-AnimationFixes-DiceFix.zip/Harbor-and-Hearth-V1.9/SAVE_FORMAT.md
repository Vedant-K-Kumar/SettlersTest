# Harbor & Hearth saved-match format (`.hhmatch`)

A `.hhmatch` file is **gzip-compressed JSON**. Run `gunzip` on it, or rename it to `.gz` and extract it, to read the JSON. The game also opens plain, uncompressed `.json` files in the same format.

## Moving matches to a new version

- **Save folder (Chrome/Edge):** in Match History, choose a save folder. Every finished match is also written there as a `.hhmatch` file. In a new version, choose the same folder (or a copy of it) and press **Rescan folder**.
- **Import/Export:** **Export** downloads a single `.hhmatch` file. **Import files** in any version (V1.9 or later) adds it to Match History.
- Matches are also kept in the browser's storage. Chrome shares that storage between local HTML files, so a new version opened from a different folder usually sees them too.

## Top level

| field | meaning |
| --- | --- |
| `format` | always `"harbor-hearth-match"` |
| `formatVersion` | integer, currently `1`. Newer versions upgrade older files on load. Old files are never rewritten. |
| `app`, `appVersion` | the game and version that saved the match (e.g. `"1.9"`) |
| `id`, `savedAt` | unique id; save time in milliseconds since 1970 |
| `meta` | summary for lists: start and end times, `durationMs`, `turns`, `winner`, players, difficulty, `mapId`, `rulesId` |
| `rules` | the rule set used: supply limits, deck, costs, piece limits, victory points |
| `board` | full map: `tiles` (`id`, `q`, `r`, `terrain`, `number`, `center`, `nodes`), `nodes` (`id`, `x`, `y`, `tiles`), `edges` (`id`, `a`, `b`, `tiles`), `ports` (`edge`, `type`) |
| `players` | seat order: `seat`, `id`, `name`, `color`, `bot`, `style` (archetype id or null), `styleLabel` |
| `replay` | `initial` state plus the `events` list (see below) |
| `chronicle` | every Chronicle line, oldest first, as plain text |
| `summary` | the end-of-game statistics and awards object shown on the summary screen |

## Replay data

The state is a flat object. Seat-based keys start with `p<seat>.`:

- `robber`: tile id
- `bank`: counts for `[wood, brick, wool, grain, ore]`
- `deck`: cards left
- `lr` / `la`: player id holding Longest Road / Largest Army
- `dice`: `[a, b]`
- `turn`: seat index; `tc`: turn count; `ph`: phase; `win`: winner id
- `pN.r`: hand `[wood, brick, wool, grain, ore]`
- `pN.ro`: road edge ids; `pN.s`: settlement node ids; `pN.c`: city node ids
- `pN.d`: progress cards held (including hidden victory points)
- `pN.k`: knights played; `pN.v`: revealed victory points; `pN.h`: hidden victory points; `pN.pt`: harbors

Each event is `{ t, k, tx, d, fx? }`:

- `t`: milliseconds since the match started
- `k`: kind: `roll`, `build`, `trade`, `robber`, `dev`, `award`, `turn`, `discard`, `win` or `note`
- `tx`: the Chronicle text for the event
- `d`: only the state keys that changed
- `fx`: production animation data: `{ tiles, g: [[seat, resource, amount, x, y], ...] }`

To rebuild the table after event *n*, start from `initial` and apply each `d` in order. The replay never re-runs the rules engine, so it shows exactly what happened, even if a later version changes the rules.
