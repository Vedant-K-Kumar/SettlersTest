@echo off
REM Harbor ^& Hearth - optional hosted (multiplayer) mode for Windows.
REM Offline play needs none of this: just double-click Play-Harbor-and-Hearth.html.
cd /d "%~dp0"
where node >nul 2>nul
if errorlevel 1 (
  echo Node.js 18 or newer is required for hosted mode. Install it from https://nodejs.org and run this file again.
  echo For offline play, just open Play-Harbor-and-Hearth.html in Chrome or Edge.
  pause
  exit /b 1
)
start "" http://localhost:8080
node server.js
pause
