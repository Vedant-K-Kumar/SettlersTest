// Cross-platform zip builder (Windows, ChromeOS Linux, macOS). No dependencies: uses Node's zlib.
// Usage: npm run bundle   ->   Harbor-and-Hearth.zip beside package.json
const fs = require('fs');
const path = require('path');
const zlib = require('zlib');

const root = path.join(__dirname, '..');
const include = ['README.md', 'package.json', 'server.js', 'Play-Harbor-and-Hearth.html', 'Start-Hosted-Server.cmd', 'SAVE_FORMAT.md', 'CHANGELOG-V1.9.md', 'public', 'scripts'];
const skip = /(^|[\\/])(\.DS_Store|__MACOSX|Thumbs\.db|desktop\.ini|node_modules|.*\.zip)$/i;

function walk(rel, out) {
  const abs = path.join(root, rel);
  if (!fs.existsSync(abs) || skip.test(rel)) return;
  const stat = fs.statSync(abs);
  if (stat.isDirectory()) fs.readdirSync(abs).sort().forEach((name) => walk(path.join(rel, name), out));
  else out.push({ rel: rel.split(path.sep).join('/'), abs, stat });
}

const CRC = new Uint32Array(256).map((_, n) => { let c = n; for (let k = 0; k < 8; k++) c = c & 1 ? 0xedb88320 ^ (c >>> 1) : c >>> 1; return c >>> 0; });
function crc32(buf) { let c = 0xffffffff; for (let i = 0; i < buf.length; i++) c = CRC[(c ^ buf[i]) & 255] ^ (c >>> 8); return (c ^ 0xffffffff) >>> 0; }
function dosTime(d) { return { time: (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1), date: ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate() }; }

const files = []; include.forEach((rel) => walk(rel, files));
const folder = 'Harbor-and-Hearth-V1.9/';
const locals = []; const centrals = []; let offset = 0;
files.forEach((f) => {
  const data = fs.readFileSync(f.abs); const packed = zlib.deflateRawSync(data, { level: 9 });
  const name = Buffer.from(folder + f.rel, 'utf8'); const { time, date } = dosTime(f.stat.mtime); const crc = crc32(data);
  const local = Buffer.alloc(30); local.writeUInt32LE(0x04034b50, 0); local.writeUInt16LE(20, 4); local.writeUInt16LE(0x0800, 6); local.writeUInt16LE(8, 8);
  local.writeUInt16LE(time, 10); local.writeUInt16LE(date, 12); local.writeUInt32LE(crc, 14); local.writeUInt32LE(packed.length, 18); local.writeUInt32LE(data.length, 22); local.writeUInt16LE(name.length, 26);
  locals.push(local, name, packed);
  const central = Buffer.alloc(46); central.writeUInt32LE(0x02014b50, 0); central.writeUInt16LE(20, 4); central.writeUInt16LE(20, 6); central.writeUInt16LE(0x0800, 8); central.writeUInt16LE(8, 10);
  central.writeUInt16LE(time, 12); central.writeUInt16LE(date, 14); central.writeUInt32LE(crc, 16); central.writeUInt32LE(packed.length, 20); central.writeUInt32LE(data.length, 24); central.writeUInt16LE(name.length, 28); central.writeUInt32LE(offset, 42);
  centrals.push(central, name);
  offset += local.length + name.length + packed.length;
});
const centralSize = centrals.reduce((n, b) => n + b.length, 0);
const end = Buffer.alloc(22); end.writeUInt32LE(0x06054b50, 0); end.writeUInt16LE(files.length, 8); end.writeUInt16LE(files.length, 10); end.writeUInt32LE(centralSize, 12); end.writeUInt32LE(offset, 16);
const target = path.join(root, 'Harbor-and-Hearth.zip');
fs.writeFileSync(target, Buffer.concat([...locals, ...centrals, end]));
console.log(`Created ${target} with ${files.length} files.`);
