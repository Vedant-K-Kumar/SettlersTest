# Harbor & Hearth (V1.9)

An original, self-hosted browser game inspired by classic island-settlement games. It contains the base-game rules: setup placement, production, the robber, building, development cards, domestic and maritime trade, ports, largest army, longest road, and ten-point victory.

## Play offline (Chromebook, Windows, Mac, Linux)

1. Extract the zip.
2. Open `Play-Harbor-and-Hearth.html` in Chrome (Edge and Firefox also work).
3. Type a name for each human seat. Every blank seat becomes a Hearthkeeper bot.

No install, account, or internet connection is needed. On Windows, double-click the HTML file, or right-click it and choose *Open with > Google Chrome / Microsoft Edge*.

See `CHANGELOG-V1.9.md` for everything new in V1.9 (new interface, 2D map, settings, statistics, saved games and replays) and `SAVE_FORMAT.md` for the match file format.

## Bot difficulty

Choose **Easy** (the repaired V1.7 bots) or **Normal** (the strategic bots below) when starting a game. **Hard** is planned for V2.0.

## The Normal bots

Each bot is given its own archetype at the start of the game, shown as a badge beside its name. Hover over the badge for a one-line description.

| Archetype | Plan |
| --- | --- |
| **Magnate** | Ore-and-grain engine, early cities, strong production |
| **Warlord** | Knights, aggressive robber play, Largest Army |
| **Scholar** | Development cards, hidden victory points, well-timed progress cards |
| **Roadrunner** | Wood and brick, Longest Road, fast lines into contested land |
| **Pioneer** | Rapid expansion, resource diversity, claiming key junctions |
| **Merchant** | 2:1 harbors, trade leverage, converting surplus |

How they play:

- **Openings.** They value spots by dice probability, look ahead through the snake draft, and pair spots to fit their archetype.
- **Planning.** Each turn they pick a goal by comparing what it's worth with how many turns it will take to afford, given their production and harbor rates. They save toward that goal, trade for it, and still take an opportunistic build when it won't delay the plan.
- **Adapting.** As a bot gets close to winning, its archetype bias softens (a Roadrunner will still build cities to finish), but its core priorities stay.
- **Reading the table.** Bots weigh each opponent's visible points plus likely hidden points. They rob and block the leader, cut a leader's Longest Road with settlements, and won't trade with anyone close to winning.
- **Finding the win.** Every turn they check whether some mix of trades, builds, Longest Road, Largest Army, or Year of Plenty wins the game right now.
- **Playing fair.** Bots never see hidden hands. Each one counts cards from public events only (production, builds, trades, discards). A robber theft stays uncertain for everyone except the thief and the victim.
- **Trading.** Bots trade with each other and with you. They accept your offers only when the deal helps their plan.

## Fixes in V1.8

- **Turn order is now random.** v7 never randomized seating, so seat one always placed first and rolled first. Its card shuffle (`sort(() => Math.random() - .5)`) was also biased. v8 uses an unbiased Fisher-Yates shuffle with the browser's crypto random source, for seating, the board, and the progress deck. The drawn order is announced in the Chronicle, the player list follows it, and the first player in setup takes the first roll.
- **One progress card per turn now applies to everyone.** v7 only enforced it for bots.
- **The robber steals a random card,** not a random resource type.
- **Piece limits are enforced:** 5 houses, 4 cities, 15 roads.
- **Discards are shown in the Chronicle,** as in the tabletop rules.
- **Hosted mode:** an action no longer fails when another player's tab is briefly disconnected. Hosted bots also answer trade offers now.

## Optional hosted multiplayer

Needs Node.js 18 or newer.

- **Windows:** double-click `Start-Hosted-Server.cmd`. It starts the server and opens `http://localhost:8080`.
- **Chromebook (Linux) / Mac:** open a terminal in this folder and run `npm start`, then open `http://localhost:8080`.

Use **Create table** and add bots from the lobby, or share the host's local network address followed by `:8080` with people on the same Wi-Fi. Hosted bots use the same strategy engine as offline play.

## Make a zip

Run `npm run bundle`. It works on Windows, ChromeOS Linux, and macOS, with no extra tools needed. It creates `Harbor-and-Hearth.zip` beside the project files.

## Files

- `Play-Harbor-and-Hearth.html`: offline game entry point
- `public/ai.js`: bot strategy engine, shared by offline and hosted play
- `public/offline.js`: offline rules engine and table
- `public/ui.js`, `public/iso.js`, `public/style.css`: interface and board art
- `server.js`, `public/app.js`, `public/index.html`: optional hosted mode

The game is original software and does not include artwork, branding, or content from any commercial board game.
