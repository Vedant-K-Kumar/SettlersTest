/* Harbor & Hearth V1.9 - clean 2D board.
   Flat, solid-colour hexes with one small symbol each; number tokens, harbors, robber,
   roads and buildings drawn simply. Reads the same board data as the 2.5D renderer. */
const FLAT = {
  color: { brick: '#b4533a', grain: '#e9b824', wool: '#a6d36a', wood: '#2f6b3a', ore: '#a3abb1', desert: '#e7d3a1' },
  edge: { brick: '#7c3423', grain: '#a87d10', wool: '#6f9a3c', wood: '#1c4425', ore: '#6c757b', desert: '#b49a62' },
  ink: { brick: '#fbe1d6', grain: '#7a5508', wool: '#f4ffe6', wood: '#cfe8c8', ore: '#f2f4f5', desert: '#9c7f45' }
};
function flatSymbol(t, x, y) {
  const c = FLAT.ink[t];
  const g = (body) => `<g transform="translate(${x} ${y}) scale(.3)" fill="${c}" stroke="none" pointer-events="none">${body}</g>`;
  switch (t) {
    case 'wood': return g('<path d="M0-.9L.55 0H.25L.7 .6H-.7L-.25 0H-.55Z"/><rect x="-.1" y=".6" width=".2" height=".35"/>');
    case 'brick': return g('<rect x="-.85" y="-.55" width=".8" height=".45" rx=".05"/><rect x=".05" y="-.55" width=".8" height=".45" rx=".05"/><rect x="-.45" y="0" width=".9" height=".45" rx=".05"/><rect x="-.85" y=".55" width=".35" height="0" />');
    case 'wool': return g('<circle cx="-.35" cy="0" r=".35"/><circle cx=".05" cy="-.2" r=".4"/><circle cx=".4" cy=".05" r=".33"/><circle cx="0" cy=".2" r=".38"/><rect x="-.35" y=".45" width=".12" height=".35"/><rect x=".22" y=".45" width=".12" height=".35"/>');
    case 'grain': return g('<rect x="-.05" y="-.4" width=".1" height="1.3"/><ellipse cx="-.22" cy="-.35" rx=".14" ry=".26" transform="rotate(-25 -.22 -.35)"/><ellipse cx=".22" cy="-.35" rx=".14" ry=".26" transform="rotate(25 .22 -.35)"/><ellipse cx="-.22" cy=".05" rx=".14" ry=".26" transform="rotate(-25 -.22 .05)"/><ellipse cx=".22" cy=".05" rx=".14" ry=".26" transform="rotate(25 .22 .05)"/><ellipse cx="0" cy="-.75" rx=".13" ry=".25"/>');
    case 'ore': return g('<path d="M-.95 .7L-.35-.45L-.05 .05L.3-.75L.95 .7Z"/>');
    case 'desert': return g('<path d="M-.9 .6Q-.45 .1 0 .45Q.45 .1 .9 .6Z"/><circle cx=".45" cy="-.45" r=".25"/>');
    default: return '';
  }
}
function flatToken(n, x, y, flashing) {
  const hot = n === 6 || n === 8; const pips = 6 - Math.abs(7 - n); let dots = '';
  for (let i = 0; i < pips; i++) dots += `<circle cx="${((i - (pips - 1) / 2) * .07).toFixed(3)}" cy=".17" r=".022" fill="${hot ? '#b3261a' : '#3a2a1c'}"/>`;
  return `<g transform="translate(${x} ${y})" pointer-events="none">${flashing ? '<circle class="flat-flash-ring" r=".44" fill="none" stroke="#fff6c9" stroke-width=".06"/>' : ''}<circle r=".34" fill="#fbf6ea" stroke="#3a2a1c" stroke-width=".03"/><text class="flat-num ${hot ? 'hot' : ''}" y=".08" font-size="${n >= 10 ? .27 : .31}">${n}</text>${dots}</g>`;
}
function flatHouse(col) { return `<path d="M-.17 .12V-.06L0-.2L.17-.06V.12Z" fill="${col}" stroke="#1d140c" stroke-width=".035" stroke-linejoin="round"/>`; }
function flatCity(col) { return `<path d="M-.26 .15V-.04L-.12-.16L.02-.04V.0H.26V.15Z" fill="${col}" stroke="#1d140c" stroke-width=".035" stroke-linejoin="round"/><rect x=".08" y="-.08" width=".1" height=".08" fill="${col}" stroke="#1d140c" stroke-width=".03"/>`; }
function board2d() {
  const b = game.board; const player = p();
  const xs = b.nodes.map((z) => z.x); const ys = b.nodes.map((z) => z.y);
  const x0 = Math.min(...xs) - 1.5; const y0 = Math.min(...ys) - 1.4; const W = Math.max(...xs) + 1.5 - x0; const H = Math.max(...ys) + 1.4 - y0;
  const flashSet = new Set((game.fx && game.fx.tiles) || []);
  const corner = (c, s) => { const a = []; for (let i = 0; i < 6; i++) { const z = (60 * i - 30) * Math.PI / 180; a.push(`${(c.x + Math.cos(z) * s).toFixed(3)},${(c.y + Math.sin(z) * s).toFixed(3)}`); } return a.join(' '); };
  const sea = `<rect x="${x0}" y="${y0}" width="${W}" height="${H}" rx=".8" fill="#2f7896"/><rect x="${x0 + .07}" y="${y0 + .07}" width="${W - .14}" height="${H - .14}" rx=".72" fill="none" stroke="#9fd0df" stroke-opacity=".5" stroke-width=".03"/>`;
  const tiles = b.tiles.map((t) => {
    const target = tool === 'robber' && t.id !== b.robber && player && !player.bot && !game.replay;
    const flashing = flashSet.has(t.id);
    return `<g class="f-tile-g ${flashing ? 'hex-flash' : ''}" onclick="clickTile('${t.id}')">` +
      `<polygon class="f-tile ${target ? 'target' : ''} ${flashing ? 'flash' : ''}" points="${corner(t.center, .97)}" fill="${FLAT.color[t.terrain]}" stroke="${FLAT.edge[t.terrain]}" stroke-width=".05" stroke-linejoin="round"/>` +
      flatSymbol(t.terrain, t.center.x, t.center.y - (t.number ? .45 : .05)) +
      (t.number ? flatToken(t.number, t.center.x, t.center.y + .18, flashing) : '') +
      (b.robber === t.id ? `<g transform="translate(${t.center.x - .5} ${t.center.y + .05})" pointer-events="none"><ellipse cy=".2" rx=".16" ry=".05" fill="rgba(0,0,0,.35)"/><path d="M-.12 .2Q-.13 0-.05-.12H.05Q.13 0 .12 .2Z" fill="#26211c" stroke="#0c0a08" stroke-width=".02"/><circle cy="-.2" r=".09" fill="#26211c" stroke="#0c0a08" stroke-width=".02"/></g>` : '') + '</g>';
  }).join('');
  const harbors = b.ports.map((q) => {
    const z = e(q.edge); const a = n(z.a); const d = n(z.b); const mx = (a.x + d.x) / 2; const my = (a.y + d.y) / 2; const len = Math.hypot(mx, my) || 1;
    const hx = mx + mx / len * .72; const hy = my + my / len * .72;
    const fill = q.type === 'any' ? '#f6eedb' : FLAT.color[q.type]; const label = q.type === 'any' ? '3:1' : '2:1';
    return `<g pointer-events="all" data-tip="${q.type === 'any' ? 'Harbor: trade any 3 identical cards for 1' : `Harbor: trade 2 ${NAME[q.type]} for 1`}"><path d="M${a.x} ${a.y}L${hx} ${hy}L${d.x} ${d.y}" fill="none" stroke="#e9dcc0" stroke-width=".05" stroke-dasharray=".08 .06"/><circle cx="${hx}" cy="${hy}" r=".3" fill="${fill}" stroke="#2a1d12" stroke-width=".035"/><text class="flat-port" x="${hx}" y="${hy + .07}" font-size=".19">${label}</text></g>`;
  }).join('');
  const roads = []; const claimed = [];
  b.edges.forEach((z) => {
    const a = n(z.a); const d = n(z.b); const o = game.players.find((x) => x.roads.includes(z.id));
    if (o) claimed.push(`<line x1="${a.x}" y1="${a.y}" x2="${d.x}" y2="${d.y}" stroke="#1d140c" stroke-width=".2" stroke-linecap="round"/><line x1="${a.x}" y1="${a.y}" x2="${d.x}" y2="${d.y}" stroke="${o.color}" stroke-width=".13" stroke-linecap="round"/>`);
    else {
      const target = !game.replay && (tool === 'road' || game.phase === 'setup') && player && !player.bot && canRoad(player, z.id);
      roads.push(`<g onclick="clickRoad('${z.id}')"><line class="${target ? 'f-road-target' : 'f-edge'}" x1="${a.x}" y1="${a.y}" x2="${d.x}" y2="${d.y}"/></g>`);
    }
  });
  const nodes = b.nodes.map((z) => {
    const o = owner(z.id);
    if (o) {
      const isCity = o.cities.includes(z.id); const target = !game.replay && tool === 'city' && o === player && !isCity && player && !player.bot;
      return `<g class="f-piece ${target ? 'target' : ''}" transform="translate(${z.x} ${z.y})" onclick="clickNode('${z.id}')">${target ? '<circle class="f-ring" r=".3"/>' : ''}${isCity ? flatCity(o.color) : flatHouse(o.color)}</g>`;
    }
    const target = !game.replay && (tool === 'settlement' || game.phase === 'setup') && player && !player.bot && canSet(player, z.id);
    return `<g onclick="clickNode('${z.id}')"><circle class="f-node ${target ? 'target' : ''}" cx="${z.x}" cy="${z.y}" r="${target ? .14 : .05}"/><circle cx="${z.x}" cy="${z.y}" r=".2" fill="transparent"/></g>`;
  }).join('');
  return `<svg class="board board-flat" viewBox="${x0} ${y0} ${W} ${H}" preserveAspectRatio="xMidYMid meet">${sea}${tiles}${harbors}${roads.join('')}${claimed.join('')}${nodes}</svg>`;
}
HearthRender.register('flat', { label: '2D', name: 'Clean 2D map', board: board2d, project: (x, y) => [x, y] });
