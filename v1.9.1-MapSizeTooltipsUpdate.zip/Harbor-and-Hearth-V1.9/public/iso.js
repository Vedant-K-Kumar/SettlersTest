/* Harbor & Hearth: 2.5D isometric board.
   Ground is squashed vertically (ISO.K); tiles have thickness (ISO.H);
   scenery stands upright on the squashed ground. */
const ISO = { K: .8, H: .2 };
const iso = (x, y) => [+x.toFixed(3), +(y * ISO.K).toFixed(3)];
const pts = a => a.map(q => q.join(',')).join(' ');
function shade(h, f) { let n = parseInt(h.slice(1), 16), t = f < 0 ? 0 : 255, k = Math.abs(f); return '#' + [n >> 16, n >> 8 & 255, n & 255].map(v => Math.round(v + (t - v) * k).toString(16).padStart(2, '0')).join(''); }
function hexPts(c, s = 1, dy = 0) { let a = []; for (let i = 0; i < 6; i++) { let z = (60 * i - 30) * Math.PI / 180, q = iso(c.x + Math.cos(z) * s, c.y + Math.sin(z) * s); a.push([q[0], +(q[1] + dy).toFixed(3)]); } return a; }

const TOP = { wood: ['#6ea25a', '#2f5a34'], brick: ['#e09162', '#8d3e28'], wool: ['#c5dc86', '#6f9444'], grain: ['#f6d56a', '#c48d2c'], ore: ['#b7bdb8', '#5e6664'], desert: ['#f3ddaa', '#c49a58'] };
const SIDE = { wood: '#1e3a26', brick: '#5c2418', wool: '#445830', grain: '#7a5618', ore: '#343a39', desert: '#7d6236' };
const OUT = 'stroke="#22150c" stroke-opacity=".65" stroke-width=".014" stroke-linejoin="round"';

function isoBox(x, y, w, d, h, c) {
  return `<polygon points="${x - w},${y} ${x},${y + d} ${x},${y + d - h} ${x - w},${y - h}" fill="${c[1]}"/>` +
    `<polygon points="${x},${y + d} ${x + w},${y} ${x + w},${y - h} ${x},${y + d - h}" fill="${c[2]}"/>` +
    `<polygon points="${x - w},${y - h} ${x},${y - h - d} ${x + w},${y - h} ${x},${y + d - h}" fill="${c[0]}"/>`;
}
function isoRoof(x, y, w, d, h, rh, col) {
  let ty = y - h, ay = ty - rh, f = (a, b) => `${x + a[0]},${ty + a[1]} ${x + b[0]},${ty + b[1]} ${x},${ay}`;
  return `<polygon points="${f([-w, 0], [0, -d])}" fill="${shade(col, .22)}"/><polygon points="${f([0, -d], [w, 0])}" fill="${shade(col, -.12)}"/>` +
    `<polygon points="${f([-w, 0], [0, d])}" fill="${shade(col, .05)}"/><polygon points="${f([0, d], [w, 0])}" fill="${shade(col, -.34)}"/>`;
}
const WALL = ['#fbf6ea', '#e7d7b4', '#b89a6a'];
function house(col) {
  return `<g ${OUT}><ellipse cy=".06" rx=".26" ry=".09" fill="rgba(0,0,0,.32)" stroke="none"/>` +
    `${isoBox(0, .04, .16, .09, .17, WALL)}` +
    `${isoBox(.12, -.01, .035, .02, .3, ['#8d5a48', '#6b3e30', '#4a291e'])}` +
    `<rect x="-.04" y="-.02" width=".07" height=".1" fill="#4e3424" stroke="none"/>` +
    `${isoRoof(0, .04, .2, .11, .17, .22, col)}</g>`;
}
function cityPiece(col) {
  return `<g ${OUT}><ellipse cy=".07" rx=".36" ry=".12" fill="rgba(0,0,0,.32)" stroke="none"/>` +
    `${isoBox(-.12, -.02, .1, .055, .38, WALL)}${isoRoof(-.12, -.02, .12, .07, .38, .2, col)}` +
    `${isoBox(.1, .06, .17, .09, .2, WALL)}${isoRoof(.1, .06, .19, .11, .2, .18, col)}` +
    `${isoBox(-.04, -.08, .025, .015, .52, ['#8d5a48', '#6b3e30', '#4a291e'])}` +
    `<polygon points="-.12,-.58 -.04,-.7 .04,-.58" fill="${col}" stroke="#1a120c" stroke-width=".012"/></g>`;
}

function pine(x, y, s) {
  let t = '';
  for (let k = 0; k < 3; k++) {
    let by = -.08 - k * .14, hw = .2 - k * .045;
    t += `<polygon points="0,${by - .28} ${-hw},${by} 0,${by + .05}" fill="${k % 2 ? '#3f8a45' : '#57a356'}"/>` +
      `<polygon points="0,${by - .28} 0,${by + .05} ${hw},${by}" fill="${k % 2 ? '#245232' : '#2f6b3c'}"/>`;
  }
  return `<g transform="translate(${x} ${y}) scale(${s})" stroke="#17301c" stroke-width=".018" stroke-linejoin="round">` +
    `<ellipse cy=".04" rx=".18" ry=".06" fill="rgba(0,0,0,.28)" stroke="none"/>` +
    `<rect x="-.035" y="-.12" width=".07" height=".16" fill="#6b4426"/>` +
    `<rect x="-.02" y="-.12" width=".02" height=".16" fill="#8d6840" stroke="none"/>${t}</g>`;
}
function mount(x, y, s, w, h) {
  let ax = .04;
  return `<g transform="translate(${x} ${y}) scale(${s})" stroke="#262c2b" stroke-width=".018" stroke-linejoin="round">` +
    `<ellipse cy=".06" rx="${w + .06}" ry=".07" fill="rgba(0,0,0,.28)" stroke="none"/>` +
    `<polygon points="${-w},0 ${ax},${-h} 0,.08" fill="#a7adaa"/><polygon points="${ax},${-h} ${w},0 0,.08" fill="#5a6260"/>` +
    `<polygon points="${ax - w * .15},0 ${ax},${-h * .35} ${ax + w * .2},0" fill="#6d6560" opacity=".35" stroke="none"/>` +
    `<polygon points="${ax},${-h} ${ax - w * .42},${-h * .58} ${ax - .03},${-h * .66} ${ax + .05},${-h * .5} ${ax + w * .36},${-h * .6}" fill="#f8f6ef"/></g>`;
}
function brickStack(x, y, s) {
  const c = ['#f0a56e', '#d06a3e', '#8f3d28'], b = (bx, by) => isoBox(bx, by, .09, .048, .06, c);
  return `<g transform="translate(${x} ${y}) scale(${s})" ${OUT}>` +
    `<ellipse cy=".05" rx=".34" ry=".09" fill="rgba(0,0,0,.25)" stroke="none"/>` +
    `${b(-.18, .05)}${b(0, .05)}${b(.18, .05)}${b(-.09, -.01)}${b(.09, -.01)}${b(0, -.07)}</g>`;
}
function kiln(x, y, s) {
  return `<g transform="translate(${x} ${y}) scale(${s})" ${OUT}>` +
    `<ellipse cy=".08" rx=".22" ry=".07" fill="rgba(0,0,0,.28)" stroke="none"/>` +
    `<path d="M-.16 .08 C-.18 -.08 -.08 -.16 0 -.16 C.08 -.16 .18 -.08 .16 .08 Z" fill="#a84832"/>` +
    `<path d="M-.16 .08 C-.18 -.08 -.08 -.16 0 -.16 C-.02 -.04 -.08 .02 -.16 .08 Z" fill="#7c3024"/>` +
    `<rect x="-.04" y="-.02" width=".08" height=".1" fill="#2a1814"/>` +
    `<circle cx=".02" cy="-.22" r=".035" fill="#f7f4ee" stroke="none" opacity=".8"/>` +
    `<circle cx=".06" cy="-.3" r=".045" fill="#f7f4ee" stroke="none" opacity=".65"/>` +
    `<circle cx="0" cy="-.38" r=".03" fill="#f7f4ee" stroke="none" opacity=".45"/></g>`;
}
function sheep(x, y, s, f) {
  const wl = (cx, cy, r) => `<circle cx="${cx}" cy="${cy}" r="${r}"/>`;
  return `<g transform="translate(${x} ${y}) scale(${f * s} ${s})" stroke="#8a7f64" stroke-width=".012">` +
    `<ellipse cy=".04" rx=".18" ry=".055" fill="rgba(0,0,0,.25)" stroke="none"/>` +
    `<g fill="#3d362f" stroke="none"><rect x="-.08" y="-.02" width=".03" height=".08"/><rect x=".05" y="-.02" width=".03" height=".08"/></g>` +
    `<g fill="#fbf6ea">${wl(-.08, -.1, .085)}${wl(0, -.15, .1)}${wl(.08, -.1, .085)}${wl(0, -.06, .11)}</g>` +
    `<ellipse cx=".15" cy="-.08" rx=".055" ry=".05" fill="#3d342c" stroke="none"/>` +
    `<ellipse cx=".13" cy="-.13" rx=".02" ry=".03" fill="#3d342c" stroke="none"/>` +
    `<circle cx=".135" cy="-.085" r=".008" fill="#f4efe4" stroke="none"/></g>`;
}
function stalk(x, y, lean) {
  const dx = lean || 0;
  return `<path d="M${x} ${y}q${dx + .01} -.1 ${dx} -.2" stroke="#8a621c" stroke-width=".02" fill="none"/>` +
    `<ellipse cx="${x + dx}" cy="${y - .22}" rx=".03" ry=".075" fill="#f8dc6a" stroke="#a37a22" stroke-width=".01" transform="rotate(${dx * 80} ${x + dx} ${y - .22})"/>` +
    `<ellipse cx="${x + dx - .02}" cy="${y - .16}" rx=".02" ry=".04" fill="#e7c24e" stroke="none"/>` +
    `<ellipse cx="${x + dx + .02}" cy="${y - .15}" rx=".02" ry=".04" fill="#f3d56a" stroke="none"/>`;
}
function mill(x, y, s) {
  return `<g transform="translate(${x} ${y}) scale(${s})" stroke-linejoin="round">` +
    `<ellipse cy=".08" rx=".18" ry=".055" fill="rgba(0,0,0,.28)" stroke="none"/>` +
    `<polygon points="-.09,.07 -.07,-.2 .07,-.2 .09,.07" fill="#f6edd4" stroke="#6a4a28" stroke-width=".014"/>` +
    `<polygon points="-.11,-.2 .11,-.2 .06,-.3 -.06,-.3" fill="#8d3530" stroke="#4a201c" stroke-width=".014"/>` +
    `<polygon points="-.18,-.16 0,-.28 -.015,-.02" fill="#f7f3e6" stroke="#5c4630" stroke-width=".012"/>` +
    `<polygon points=".18,-.16 0,-.28 .015,-.02" fill="#e4d5b4" stroke="#5c4630" stroke-width=".012"/>` +
    `<rect x="-.025" y="-.02" width=".05" height=".09" fill="#5c3b22" stroke="none"/></g>`;
}
function cactus(x, y) {
  return `<g transform="translate(${x} ${y})">` +
    `<ellipse cy=".04" rx=".14" ry=".045" fill="rgba(0,0,0,.25)"/>` +
    `<path d="M-.05 -.08 H-.14 V-.22" fill="none" stroke="#245332" stroke-width=".07" stroke-linecap="round"/>` +
    `<path d="M.05 -.12 H.13 V-.26" fill="none" stroke="#245332" stroke-width=".07" stroke-linecap="round"/>` +
    `<rect x="-.05" y="-.34" width=".1" height=".38" rx=".05" fill="#2c6840"/>` +
    `<path d="M-.03 -.08 H-.1 V-.2" fill="none" stroke="#6eab6a" stroke-width=".035" stroke-linecap="round"/>` +
    `<rect x="-.028" y="-.32" width=".045" height=".34" rx=".02" fill="#4e9460" opacity=".85"/></g>`;
}
function mineMouth(x, y, s) {
  return `<g transform="translate(${x} ${y}) scale(${s})">` +
    `<ellipse cy=".06" rx=".22" ry=".06" fill="rgba(0,0,0,.3)" stroke="none"/>` +
    `<path d="M-.18 .06 L-.02 -.2 L.18 .06 Z" fill="#3a342e" stroke="#1a1714" stroke-width=".016"/>` +
    `<path d="M-.1 .06 L0 -.08 L.1 .06 Z" fill="#120e0c"/>` +
    `<path d="M-.14 .02 H-.02 M.02 .02 H.14" stroke="#a67c48" stroke-width=".02"/>` +
    `<rect x="-.015" y="-.16" width=".03" height=".14" fill="#6b4a2c"/></g>`;
}
function fence(y) {
  let posts = '';
  for (let i = 0; i < 5; i++) {
    const x = -.32 + i * .16;
    posts += `<rect x="${x}" y="${y - .08}" width=".02" height=".1" fill="#8d6a3c"/>`;
    if (i) posts += `<path d="M${x - .14} ${y - .05} H${x}" stroke="#a67c48" stroke-width=".016"/>`;
  }
  return posts;
}

const ART = {
  wood: () => {
    const trees = [[-.48, .02, .55], [-.28, -.22, .62], [-.08, -.02, .5], [.14, -.24, .7], [.34, -.06, .58], [.5, .04, .48], [-.4, .16, .42]];
    return `<ellipse cy=".08" rx=".55" ry=".16" fill="#23402a" opacity=".28"/>` +
      `<path d="M-.42 .16 Q-.1 .02 .08 .14 T.46 .08" fill="none" stroke="#6b5130" stroke-width=".045" stroke-linecap="round"/>` +
      `<path d="M-.42 .16 Q-.1 .02 .08 .14 T.46 .08" fill="none" stroke="#c4a36a" stroke-width=".016" stroke-linecap="round"/>` +
      trees.sort((a, b) => a[1] - b[1]).map(a => pine(...a)).join('') +
      `<g transform="translate(-.05 .2)"><ellipse cy=".02" rx=".1" ry=".03" fill="rgba(0,0,0,.25)"/><rect x="-.08" y="-.02" width=".16" height=".045" rx=".01" fill="#6b4428" transform="rotate(-18)"/></g>` +
      `<circle cx=".22" cy=".16" r=".018" fill="#c4554a"/><circle cx=".25" cy=".175" r=".014" fill="#e7d2a4"/>`;
  },
  ore: () => mount(.22, -.16, 1, .24, .46) + mount(-.28, -.02, 1.05, .3, .56) + mount(.42, .04, .72, .16, .28) +
    mineMouth(-.02, .16, .85) +
    `<g stroke="#2a241c" stroke-width=".012"><polygon points=".28,.14 .34,.08 .4,.16" fill="#d9d3c4"/><polygon points=".34,.18 .4,.12 .46,.2" fill="#b7c0c6"/><polygon points="-.46,.12 -.4,.06 -.34,.14" fill="#9aa3a8"/></g>`,
  brick: () => `<ellipse cy=".02" rx=".52" ry=".24" fill="#7a3b28" opacity=".45"/>` +
    `<path d="M-.46 .14 Q-.2 -.02 .02 .1 Q.24 -.04 .48 .12" fill="#c46a42" opacity=".55"/>` +
    `<path d="M-.3 .08 Q-.05 -.08 .2 .06" fill="none" stroke="#6e3424" stroke-width=".03" opacity=".45"/>` +
    kiln(-.34, -.02, .85) + brickStack(.16, -.14, .78) + brickStack(-.02, .12, .95) +
    `<g fill="#e7a06a" stroke="#6a3020" stroke-width=".012"><rect x=".34" y=".08" width=".08" height=".045" rx=".01" transform="rotate(18 .38 .1)"/><rect x=".4" y=".14" width=".07" height=".04" rx=".01" transform="rotate(-12 .43 .16)"/></g>`,
  wool: () => `<ellipse cy=".02" rx=".52" ry=".22" fill="#7ea85a" opacity=".35"/>` +
    fence(.18) +
    `<g fill="#dfe8b8"><circle cx="-.2" cy=".02" r=".02"/><circle cx=".05" cy="-.02" r=".016"/><circle cx=".3" cy=".06" r=".018"/><circle cx="-.05" cy=".14" r=".015"/></g>` +
    `<g fill="#e7b4c8"><circle cx="-.32" cy=".08" r=".012"/><circle cx=".18" cy=".12" r=".012"/><circle cx=".08" cy="-.18" r=".011"/></g>` +
    sheep(-.08, -.22, .82, 1) + sheep(.3, -.08, .9, -1) + sheep(-.34, .02, .95, 1),
  grain: () => {
    let t = '';
    for (let r = 0; r < 4; r++) for (let i = 0; i < 5; i++) t += stalk(-.46 + i * .14 + (r % 2) * .05, -.18 + r * .1, ((i + r) % 3 - 1) * .04);
    return `<ellipse cy=".04" rx=".5" ry=".2" fill="#d7b44a" opacity=".28"/>` + t + mill(.38, .02, .95);
  },
  desert: () => `<path d="M-.55 .14 Q-.32 -.16 -.02 .06 Q.22 -.1 .55 .12 Z" fill="#f0d59a" stroke="#b68a48" stroke-width=".018"/>` +
    `<path d="M-.55 .14 Q-.3 -.02 .05 .12 Q.28 .02 .55 .14" fill="#e4c07a" opacity=".9"/>` +
    `<path d="M-.55 .16 Q-.2 .02 .1 .16 Q.32 .06 .55 .16" fill="#c99655" opacity=".55"/>` +
    cactus(.28, -.04) +
    `<g transform="translate(-.22 .02)" stroke="#5c5148" stroke-width=".014" fill="#cfc6b4"><rect x="-.03" y="-.16" width=".06" height=".18"/><rect x="-.09" y="-.18" width=".18" height=".04"/><path d="M-.08 .02 H.1" stroke="#8a8174"/></g>` +
    `<g transform="translate(.02 .16)" fill="none" stroke="#6e624e" stroke-width=".016" stroke-linecap="round"><path d="M-.06 .02 Q0 -.04 .05 .02"/><circle cx="-.07" cy=".01" r=".018" fill="#d9d0bc"/><circle cx=".06" cy=".02" r=".016" fill="#d9d0bc"/></g>` +
    `<polygon points="-.42,.1 -.36,.04 -.3,.02 -.28,.08" fill="#b7aa96" stroke="#4a443b" stroke-width=".012"/>`
};

function pawn(x, y) {
  return `<g transform="translate(${x} ${y})"><ellipse cy=".05" rx=".16" ry=".06" fill="rgba(0,0,0,.4)"/>` +
    `<path d="M-.1 .05 Q-.12 -.08 -.04 -.2 H.05 Q.12 -.1 .1 .05 Z" fill="#2a241e" stroke="#0e0c0a" stroke-width=".016"/>` +
    `<path d="M-.08 -.16 Q0 -.28 .06 -.18 Q.02 -.12 -.02 -.14 Q-.06 -.1 -.08 -.16 Z" fill="#1a1614" stroke="#0e0c0a" stroke-width=".012"/>` +
    `<circle cx=".09" cy=".0" r=".045" fill="#6b3a28" stroke="#1a120e" stroke-width=".012"/>` +
    `<path d="M-.02 -.22 Q.01 -.3 .04 -.24" fill="none" stroke="#c9b89a" stroke-width=".012" stroke-linecap="round"/></g>`;
}
function tokenSvg(n, x, y, flashing) {
  const hot = n === 6 || n === 8;
  const pips = 6 - Math.abs(7 - n);
  let dots = '';
  for (let i = 0; i < pips; i++) dots += `<circle cx="${((i - (pips - 1) / 2) * .062).toFixed(3)}" cy=".155" r=".016" fill="${hot ? '#8e1c14' : '#2a1c12'}"/>`;
  const size = n >= 10 ? .34 : .42;
  return `<g transform="translate(${x} ${y})">` +
    `${flashing ? '<ellipse class="flash-ring" rx=".5" ry=".32" fill="none" stroke="#fff4c4" stroke-width=".055"/>' : ''}` +
    `<ellipse cy=".055" rx=".42" ry=".25" fill="rgba(20,12,6,.45)"/>` +
    `<ellipse rx=".4" ry=".24" fill="#fffaf2" stroke="#2c1c12" stroke-width=".03"/>` +
    `<ellipse rx=".33" ry=".19" fill="none" stroke="${hot ? '#9c2218' : '#c4963e'}" stroke-width=".022"/>` +
    `<text class="iso-num ${hot ? 'hot' : ''}" y=".075" font-size="${size}">${n}</text>${dots}</g>`;
}

function board() {
  const b = game.board, player = p(), H = ISO.H, K = ISO.K;
  const tiles = [...b.tiles].sort((u, v) => u.center.y - v.center.y || u.center.x - v.center.x);
  const xs = b.nodes.map(z => z.x), ys = b.nodes.map(z => z.y * K);
  const x0 = Math.min(...xs) - 1.55, y0 = Math.min(...ys) - 1.25, W = Math.max(...xs) + 1.55 - x0, Ht = Math.max(...ys) + 1.45 - y0;
  const flashSet = new Set((game.fx && game.fx.tiles) || []);
  const defs = `<defs>${Object.entries(TOP).map(([k, [a, c]]) => `<linearGradient id="gt-${k}" x1="0" y1="0" x2=".2" y2="1"><stop offset="0" stop-color="${shade(a, .12)}"/><stop offset=".45" stop-color="${a}"/><stop offset="1" stop-color="${c}"/></linearGradient>`).join('')}` +
    `<pattern id="grain" width=".16" height=".16" patternUnits="userSpaceOnUse"><circle cx=".04" cy=".05" r=".012" fill="rgba(255,255,255,.18)"/><circle cx=".12" cy=".12" r=".008" fill="rgba(0,0,0,.18)"/></pattern>` +
    `<radialGradient id="sea" cx=".45" cy=".4" r=".8"><stop offset="0" stop-color="#3aa3ad"/><stop offset=".42" stop-color="#1c6f80"/><stop offset=".78" stop-color="#123f52"/><stop offset="1" stop-color="#071e2b"/></radialGradient>` +
    `<linearGradient id="pawn" x1="0" x2="1"><stop offset="0" stop-color="#5a5a66"/><stop offset="1" stop-color="#17171c"/></linearGradient>` +
    `<filter id="tokenShadow" x="-30%" y="-30%" width="160%" height="160%"><feDropShadow dx="0" dy=".02" stdDeviation=".015" flood-color="#1a1008" flood-opacity=".45"/></filter></defs>`;
  const sea = `<rect x="${x0}" y="${y0}" width="${W}" height="${Ht}" rx="1.15" fill="url(#sea)"/>` +
    `<rect x="${x0 + .08}" y="${y0 + .08}" width="${W - .16}" height="${Ht - .16}" rx="1.05" fill="none" stroke="#e8c98a" stroke-width=".045"/>` +
    `<rect x="${x0 + .16}" y="${y0 + .16}" width="${W - .32}" height="${Ht - .32}" rx=".95" fill="none" stroke="#f8e7c0" stroke-opacity=".35" stroke-width=".018"/>`;
  const waves = `<g fill="none" stroke="rgba(210,244,236,.22)" stroke-width=".03" stroke-linecap="round">` +
    `<path d="M${x0 + .8} ${y0 + .55} q.35 .12 .7 0 t.7 0 t.7 0"/><path d="M${x0 + W - 3.2} ${y0 + Ht - .7} q.4 .14 .8 0 t.8 0 t.8 0"/>` +
    `<path d="M${x0 + .6} ${y0 + Ht * .72} q.3 .1 .6 0 t.6 0"/></g>`;
  const shallows = `<g opacity=".35" fill="#9ee0d4" stroke="#b7efe4" stroke-width=".22" stroke-linejoin="round">${tiles.map(t => `<polygon points="${pts(hexPts(t.center, 1.28))}"/>`).join('')}</g>`;
  const sand = `<g fill="#6e542f" stroke="#6e542f" stroke-width=".02" stroke-linejoin="round">${tiles.map(t => `<polygon points="${pts(hexPts(t.center, 1.08, .16))}"/>`).join('')}</g>` +
    `<g fill="#f3e2bc" stroke="#e6d2a4" stroke-width=".02" stroke-linejoin="round">${tiles.map(t => `<polygon points="${pts(hexPts(t.center, 1.08))}"/>`).join('')}</g>`;

  const tileSvg = tiles.map(t => {
    const top = hexPts(t.center, 1), V = hexPts(t.center, 1, H), s = SIDE[t.terrain], [cx, cy] = iso(t.center.x, t.center.y);
    const target = tool === 'robber' && t.id !== b.robber && player && !player.bot;
    const flashing = flashSet.has(t.id);
    return `<g class="${flashing ? 'hex-flash' : ''}" onclick="clickTile('${t.id}')">` +
      `<polygon points="${pts(V)}" fill="${s}"/>` +
      `<polygon points="${pts([top[1], top[2], V[2], V[1]])}" fill="${shade(s, -.22)}"/>` +
      `<polygon points="${pts([top[2], top[3], V[3], V[2]])}" fill="${shade(s, .14)}"/>` +
      `<polygon points="${pts([top[3], top[4], V[4], V[3]])}" fill="${shade(s, -.08)}"/>` +
      `<polygon class="iso-top ${target ? 'target' : ''} ${flashing ? 'flash' : ''}" points="${pts(top)}" fill="url(#gt-${t.terrain})"/>` +
      `<polygon points="${pts(hexPts(t.center, .94))}" fill="url(#grain)" opacity=".55" pointer-events="none"/>` +
      `<polygon points="${pts(hexPts(t.center, .9))}" fill="none" stroke="#fff" stroke-opacity=".2" stroke-width=".02" pointer-events="none"/>` +
      `<polygon points="${pts(hexPts(t.center, .98))}" fill="none" stroke="rgba(0,0,0,.18)" stroke-width=".02" pointer-events="none"/>` +
      `<g transform="translate(${cx} ${cy})" pointer-events="none"><g transform="translate(0 -.1) scale(.86)">${ART[t.terrain]()}</g>${t.number ? tokenSvg(t.number, 0, .46, flashing) : ''}${b.robber === t.id ? pawn(-.46, -.12) : ''}</g></g>`;
  }).join('');

  const harbors = `<g pointer-events="none">${b.ports.map(q => {
    const z = e(q.edge), a = n(z.a), d = n(z.b), mx = (a.x + d.x) / 2, my = (a.y + d.y) / 2, len = Math.hypot(mx, my) || 1;
    const [hx, hy] = iso(mx + mx / len * .78, my + my / len * .78), [ax, ay] = iso(a.x, a.y), [dx, dy] = iso(d.x, d.y);
    const nm = q.type === 'any' ? 'Any' : NAME[q.type], ratio = q.type === 'any' ? '3:1' : '2:1', ring = q.type === 'any' ? '#6b4424' : TOP[q.type][1];
    return `<g stroke-linecap="round"><path d="M${ax} ${ay + .05}L${hx} ${hy + .05}M${dx} ${dy + .05}L${hx} ${hy + .05}" stroke="#2a1a0d" stroke-opacity=".4" stroke-width=".09" fill="none"/>` +
      `<path d="M${ax} ${ay}L${hx} ${hy}M${dx} ${dy}L${hx} ${hy}" stroke="#c49255" stroke-width=".055" fill="none"/><path d="M${ax} ${ay - .02}L${hx} ${hy - .02}M${dx} ${dy - .02}L${hx} ${hy - .02}" stroke="#f0d7a4" stroke-width=".016" fill="none"/>` +
      `<ellipse cx="${hx}" cy="${hy + .055}" rx=".42" ry=".28" fill="#2a1a0e"/>` +
      `<ellipse cx="${hx}" cy="${hy}" rx=".42" ry=".28" fill="#f8efd4" stroke="${ring}" stroke-width=".05"/>` +
      `<ellipse cx="${hx}" cy="${hy}" rx=".34" ry=".21" fill="none" stroke="#e2c48a" stroke-width=".015"/>` +
      `<text class="iso-port" x="${hx}" y="${hy - .03}" font-size=".13">${nm}</text><text class="iso-port" x="${hx}" y="${hy + .13}" font-size=".18" font-weight="700">${ratio}</text></g>`;
  }).join('')}</g>`;

  const road = [], claimed = [];
  b.edges.forEach(z => {
    const a = n(z.a), d = n(z.b), [x1, y1] = iso(a.x, a.y), [x2, y2] = iso(d.x, d.y), o = game.players.find(x => x.roads.includes(z.id));
    const target = !o && (tool === 'road' || game.phase === 'setup') && player && !player.bot && canRoad(player, z.id);
    const ln = (dy, st, w) => `<line x1="${x1}" y1="${y1 + dy}" x2="${x2}" y2="${y2 + dy}" stroke="${st}" stroke-width="${w}" stroke-linecap="round"/>`;
    if (o) claimed.push([(y1 + y2) / 2, `<g>${ln(.055, 'rgba(24,14,8,.45)', .18)}${ln(0, shade(o.color, -.38), .16)}${ln(-.025, o.color, .11)}${ln(-.045, shade(o.color, .4), .028)}</g>`]);
    else road.push(`<g onclick="clickRoad('${z.id}')">${target ? `<line class="iso-road-target" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"/>` : `<line class="iso-edge" x1="${x1}" y1="${y1}" x2="${x2}" y2="${y2}"/>`}</g>`);
  });

  const nodes = [...b.nodes].sort((u, v) => u.y - v.y).map(z => {
    const o = owner(z.id), [x, y] = iso(z.x, z.y);
    if (o) {
      const city = o.cities.includes(z.id), target = tool === 'city' && o === player && !city && player && !player.bot;
      return `<g class="iso-piece ${target ? 'target' : ''}" transform="translate(${x} ${y})" onclick="clickNode('${z.id}')">${city ? cityPiece(o.color) : house(o.color)}${target ? '<ellipse class="iso-ring" cy=".05" rx=".32" ry=".14"/>' : ''}</g>`;
    }
    const target = (tool === 'settlement' || game.phase === 'setup') && player && !player.bot && canSet(player, z.id);
    return `<g onclick="clickNode('${z.id}')"><ellipse class="iso-node ${target ? 'target' : ''}" cx="${x}" cy="${y}" rx="${target ? .16 : .055}" ry="${target ? .1 : .035}"/><ellipse cx="${x}" cy="${y}" rx=".2" ry=".12" fill="transparent"/></g>`;
  }).join('');

  return `<svg class="board board-iso" viewBox="${x0} ${y0} ${W} ${Ht}" preserveAspectRatio="xMidYMid meet">${defs}${sea}${waves}${shallows}${sand}${tileSvg}${harbors}${road.join('')}${claimed.sort((u, v) => u[0] - v[0]).map(q => q[1]).join('')}${nodes}</svg>`;
}

HearthRender.register('iso', { label: '2.5D', name: 'Illustrated 2.5D map', board, project: (x, y) => iso(x, y) });
