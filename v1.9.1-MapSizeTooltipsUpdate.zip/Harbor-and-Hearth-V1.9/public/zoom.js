/* Harbor & Hearth V1.9 - smooth, sharp map zoom and pan.
   Touchpad: two-finger pinch zooms (Chrome reports it as ctrl+wheel), two-finger scroll pans.
   Touchscreen: pinch to zoom, drag with one or two fingers to pan. Mouse: wheel+ctrl zooms, drag pans.
   Only the board zooms; the rest of the interface keeps its size.
   Smoothness + quality: while a gesture or animation is running the board moves as a GPU layer
   (CSS transform); ~0.1s after it settles the zoom is "committed" by rewriting the SVG viewBox, so
   the vector map is redrawn crisply at the new scale. */
(function (root) {
  'use strict';
  if (typeof document === 'undefined' || !document.addEventListener) { root.Zoom = { afterRender() {}, reset() {}, zoomIn() {}, zoomOut() {}, fit() {} }; return; }
  const MIN = 1; const MAX = 4.5;
  const st = { c: { s: 1, u: 0.5, v: 0.5 }, d: { s: 1, u: 0.5, v: 0.5 }, t: { s: 1, u: 0.5, v: 0.5 }, raf: 0, commitTimer: 0, gesture: false };
  const clampS = (s) => Math.max(MIN, Math.min(MAX, s));
  function clampUV(s, u, v) { const m = 1 / (2 * s); return [Math.min(1 - m, Math.max(m, u)), Math.min(1 - m, Math.max(m, v))]; }
  function svgEl() { return document.querySelector('.board-area > svg.board'); }
  function base(el) { if (!el.dataset.base) el.dataset.base = el.getAttribute('viewBox'); return el.dataset.base.split(/[\s,]+/).map(Number); }
  // the board's box widened to the container's aspect ratio, so screen <-> board mapping is linear
  function fit(el) {
    const [bx, by, bw, bh] = base(el); const r = el.getBoundingClientRect(); const A = (r.width || 1) / (r.height || 1);
    let w = bw; let h = bh; if (bw / bh > A) h = bw / A; else w = bh * A;
    return { x: bx - (w - bw) / 2, y: by - (h - bh) / 2, w, h, r };
  }
  function view(f, z) { const w = f.w / z.s; const h = f.h / z.s; return { x: f.x + z.u * f.w - w / 2, y: f.y + z.v * f.h - h / 2, w, h }; }
  function commitView(el) {
    const f = fit(el); const v = view(f, st.c);
    el.setAttribute('viewBox', `${v.x} ${v.y} ${v.w} ${v.h}`);
    el.classList.toggle('zoomed', st.c.s > 1.01);
    if (root.Zoom) root.Zoom.updateButtons();
  }
  // show the displayed state d using a transform relative to the committed viewBox c
  function showTransform(el) {
    const f = fit(el); const a = view(f, st.c); const b = view(f, st.d); const W = f.r.width; const H = f.r.height;
    const k = a.w / b.w; const tx = (a.x - b.x) / b.w * W; const ty = (a.y - b.y) / b.h * H;
    if (Math.abs(k - 1) < 1e-4 && Math.abs(tx) < 0.2 && Math.abs(ty) < 0.2) { el.style.transform = ''; el.style.willChange = ''; return; }
    el.style.transformOrigin = '0 0'; el.style.willChange = 'transform';
    el.style.transform = `translate(${tx}px, ${ty}px) scale(${k})`;
  }
  function close(a, b) { return Math.abs(a.s - b.s) < 0.002 && Math.abs(a.u - b.u) < 0.0005 && Math.abs(a.v - b.v) < 0.0005; }
  function scheduleCommit() {
    clearTimeout(st.commitTimer);
    st.commitTimer = setTimeout(() => {
      if (st.gesture || st.raf) { scheduleCommit(); return; }
      const el = svgEl(); st.c = Object.assign({}, st.d); if (!el) return;
      el.style.transform = ''; el.style.willChange = ''; commitView(el);
    }, 110);
  }
  function loop() {
    st.raf = 0;
    const m = root.HearthSettings ? root.HearthSettings.motion() : { reduced: false, scale: 1 };
    const k = m.reduced ? 1 : Math.min(1, 0.26 / Math.max(0.4, m.scale));
    st.d.s += (st.t.s - st.d.s) * k; st.d.u += (st.t.u - st.d.u) * k; st.d.v += (st.t.v - st.d.v) * k;
    if (close(st.d, st.t)) st.d = Object.assign({}, st.t);
    const el = svgEl(); if (el) showTransform(el);
    if (!close(st.d, st.t)) st.raf = requestAnimationFrame(loop);
    scheduleCommit();
  }
  function setTarget(s, u, v, instant) {
    s = clampS(s); [u, v] = clampUV(s, u, v); st.t = { s, u, v };
    if (instant) { st.d = Object.assign({}, st.t); const el = svgEl(); if (el) showTransform(el); scheduleCommit(); return; }
    if (!st.raf) st.raf = requestAnimationFrame(loop);
  }
  function zoomAt(factor, cx, cy, instant) {
    const el = svgEl(); if (!el) return;
    const f = fit(el); const fx = (cx - f.r.left) / f.r.width; const fy = (cy - f.r.top) / f.r.height;
    const z0 = st.t; const v0 = view(f, z0); const bx = v0.x + fx * v0.w; const by = v0.y + fy * v0.h;
    const s1 = clampS(z0.s * factor); const w1 = f.w / s1; const h1 = f.h / s1;
    setTarget(s1, (bx - fx * w1 + w1 / 2 - f.x) / f.w, (by - fy * h1 + h1 / 2 - f.y) / f.h, instant);
  }
  function panBy(dx, dy, instant) {
    const el = svgEl(); if (!el) return; const r = el.getBoundingClientRect();
    setTarget(st.t.s, st.t.u - dx / r.width / st.t.s, st.t.v - dy / r.height / st.t.s, instant);
  }
  const inBoard = (ev) => ev.target && ev.target.closest && ev.target.closest('.board-area');

  /* touchpad pinch (ctrl+wheel) and two-finger scroll */
  document.addEventListener('wheel', (ev) => {
    if (!inBoard(ev) || !svgEl()) return;
    if (ev.ctrlKey) { ev.preventDefault(); zoomAt(Math.exp(-ev.deltaY * (ev.deltaMode === 1 ? 0.05 : 0.0105)), ev.clientX, ev.clientY, false); return; }
    if (st.t.s > 1.001) { ev.preventDefault(); const mul = ev.deltaMode === 1 ? 16 : 1; panBy(-ev.deltaX * mul, -ev.deltaY * mul, true); }
  }, { passive: false });

  /* touchscreen + mouse: pinch, drag to pan */
  const pts = new Map(); let start = null; let prev = null; let dragged = false; let lastEnd = 0;
  const mid = () => { const a = [...pts.values()]; return { x: (a[0].x + a[1].x) / 2, y: (a[0].y + a[1].y) / 2, d: Math.hypot(a[0].x - a[1].x, a[0].y - a[1].y) }; };
  document.addEventListener('pointerdown', (ev) => {
    if (!inBoard(ev) || (ev.pointerType === 'mouse' && ev.button !== 0)) return;
    pts.set(ev.pointerId, { x: ev.clientX, y: ev.clientY });
    if (pts.size === 1) { start = { x: ev.clientX, y: ev.clientY }; prev = start; dragged = false; }
    if (pts.size === 2) { prev = mid(); st.gesture = true; }
  });
  document.addEventListener('pointermove', (ev) => {
    if (!pts.has(ev.pointerId)) return;
    pts.set(ev.pointerId, { x: ev.clientX, y: ev.clientY });
    if (pts.size >= 2) {
      const m = mid(); if (prev && prev.d) { zoomAt(m.d / prev.d, m.x, m.y, true); panBy(m.x - prev.x, m.y - prev.y, true); }
      prev = m; dragged = true; ev.preventDefault(); return;
    }
    if (st.t.s <= 1.001) return;
    if (!dragged && Math.hypot(ev.clientX - start.x, ev.clientY - start.y) < 8) return;
    if (!dragged) { dragged = true; st.gesture = true; prev = { x: ev.clientX, y: ev.clientY }; document.body.classList.add('panning'); return; }
    panBy(ev.clientX - prev.x, ev.clientY - prev.y, true); prev = { x: ev.clientX, y: ev.clientY };
  });
  const end = (ev) => {
    if (!pts.has(ev.pointerId)) return;
    pts.delete(ev.pointerId);
    if (pts.size === 1) { const p = [...pts.values()][0]; prev = { x: p.x, y: p.y }; start = prev; }
    if (pts.size === 0) { if (dragged) lastEnd = Date.now(); st.gesture = false; document.body.classList.remove('panning'); scheduleCommit(); }
  };
  document.addEventListener('pointerup', end); document.addEventListener('pointercancel', end);
  // a drag or pinch must not also count as clicking a junction or road
  document.addEventListener('click', (ev) => { if (inBoard(ev) && dragged && Date.now() - lastEnd < 400) { ev.stopPropagation(); ev.preventDefault(); dragged = false; } }, true);

  let ro = null;
  root.Zoom = {
    zoomIn() { const el = svgEl(); if (!el) return; const r = el.getBoundingClientRect(); zoomAt(1.5, r.left + r.width / 2, r.top + r.height / 2); },
    zoomOut() { const el = svgEl(); if (!el) return; const r = el.getBoundingClientRect(); zoomAt(1 / 1.5, r.left + r.width / 2, r.top + r.height / 2); },
    fit() { setTarget(1, 0.5, 0.5); },
    reset() { st.c = { s: 1, u: 0.5, v: 0.5 }; st.d = Object.assign({}, st.c); st.t = Object.assign({}, st.c); },
    level() { return st.t.s; },
    updateButtons() { const b = document.querySelector('.zoom-ctl .z-level'); if (b) b.textContent = Math.round(st.t.s * 100) + '%'; },
    // the board is re-created by every render: restore the view on the new SVG
    afterRender() {
      const el = svgEl(); if (!el) return;
      commitView(el); if (!close(st.c, st.d)) showTransform(el);
      if (typeof ResizeObserver !== 'undefined') {
        if (ro) ro.disconnect();
        ro = new ResizeObserver(() => { const s = svgEl(); if (s) { commitView(s); if (!close(st.c, st.d)) showTransform(s); } });
        ro.observe(el.parentElement);
      }
    }
  };
})(typeof globalThis !== 'undefined' ? globalThis : this);
